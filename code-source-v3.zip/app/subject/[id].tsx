import { useCallback, useMemo, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
} from 'react-native';
import { useFocusEffect, useLocalSearchParams, useRouter, Stack } from 'expo-router';
import {
  getSubjectById,
  updateSubject,
  deleteSubject,
} from '../../src/db/queries/subjects';
import { getCardsBySubject, deleteCard } from '../../src/db/queries/cards';
import { Flashcard, Subject } from '../../src/types/models';
import { BOX_LABELS } from '../../src/constants/leitner';

const COLOR_PALETTE = [
  '#4F46E5', '#0EA5E9', '#10B981', '#F59E0B',
  '#EF4444', '#8B5CF6', '#EC4899', '#14B8A6',
];

export default function SubjectCardsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const subjectId = Number(id);
  const router = useRouter();

  const [subject, setSubject] = useState<Subject | null>(null);
  const [cards, setCards] = useState<Flashcard[]>([]);
  const [search, setSearch] = useState('');

  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editName, setEditName] = useState('');
  const [editColor, setEditColor] = useState(COLOR_PALETTE[0]);

  const load = useCallback(async () => {
    const [s, c] = await Promise.all([
      getSubjectById(subjectId),
      getCardsBySubject(subjectId),
    ]);
    setSubject(s);
    setCards(c);
  }, [subjectId]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const filteredCards = useMemo(() => {
    if (!search.trim()) return cards;
    const q = search.trim().toLowerCase();
    return cards.filter(
      (c) =>
        c.question.toLowerCase().includes(q) || c.answer.toLowerCase().includes(q)
    );
  }, [cards, search]);

  const handleDeleteCard = (card: Flashcard) => {
    Alert.alert(
      'Supprimer cette carte ?',
      card.question.length > 60 ? card.question.slice(0, 60) + '…' : card.question,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: async () => {
            await deleteCard(card.id);
            load();
          },
        },
      ]
    );
  };

  const openEditModal = () => {
    if (!subject) return;
    setEditName(subject.name);
    setEditColor(subject.color);
    setEditModalVisible(true);
  };

  const handleSaveSubject = async () => {
    if (!editName.trim()) {
      Alert.alert('Nom requis', 'Le nom de la matière ne peut pas être vide.');
      return;
    }
    await updateSubject(subjectId, editName, editColor);
    setEditModalVisible(false);
    load();
  };

  const handleDeleteSubject = () => {
    Alert.alert(
      'Supprimer cette matière ?',
      `Toutes ses cartes (${cards.length}) seront définitivement supprimées aussi.`,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Tout supprimer',
          style: 'destructive',
          onPress: async () => {
            await deleteSubject(subjectId);
            setEditModalVisible(false);
            router.back();
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: subject?.name ?? 'Cartes',
          headerRight: () => (
            <TouchableOpacity onPress={openEditModal} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Text style={{ fontSize: 20 }}>✏️</Text>
            </TouchableOpacity>
          ),
        }}
      />

      <View style={styles.searchBox}>
        <TextInput
          style={styles.searchInput}
          placeholder="Rechercher une carte…"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      <FlatList
        data={filteredCards}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 16, paddingTop: 0, paddingBottom: 100 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.cardRow}
            onPress={() => router.push(`/card/${item.id}`)}
          >
            <View style={styles.cardTextBlock}>
              <Text style={styles.question} numberOfLines={2}>
                {item.question}
              </Text>
              <Text style={styles.boxTag}>{BOX_LABELS[item.box]}</Text>
            </View>
            <TouchableOpacity
              style={styles.deleteButton}
              onPress={() => handleDeleteCard(item)}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <Text style={styles.deleteButtonText}>🗑️</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <Text style={styles.empty}>
            {search
              ? 'Aucune carte ne correspond à ta recherche.'
              : 'Aucune carte dans cette matière pour le moment.'}
          </Text>
        }
      />

      <TouchableOpacity
        style={styles.fab}
        onPress={() =>
          router.push({ pathname: '/card/create', params: { subjectId: String(subjectId) } })
        }
      >
        <Text style={styles.fabText}>+ Nouvelle carte</Text>
      </TouchableOpacity>

      <Modal visible={editModalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Modifier la matière</Text>
            <TextInput
              style={styles.modalInput}
              value={editName}
              onChangeText={setEditName}
            />
            <Text style={styles.modalLabel}>Couleur</Text>
            <View style={styles.colorRow}>
              {COLOR_PALETTE.map((c) => (
                <TouchableOpacity
                  key={c}
                  style={[
                    styles.colorSwatch,
                    { backgroundColor: c },
                    editColor === c && styles.colorSwatchSelected,
                  ]}
                  onPress={() => setEditColor(c)}
                />
              ))}
            </View>

            <TouchableOpacity style={styles.dangerButton} onPress={handleDeleteSubject}>
              <Text style={styles.dangerButtonText}>🗑️ Supprimer la matière et ses cartes</Text>
            </TouchableOpacity>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setEditModalVisible(false)}
              >
                <Text style={styles.modalCancelText}>Annuler</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalSaveButton} onPress={handleSaveSubject}>
                <Text style={styles.modalSaveText}>Enregistrer</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  searchBox: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8 },
  searchInput: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 14,
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 14,
    marginBottom: 10,
    elevation: 1,
  },
  cardTextBlock: { flex: 1, marginRight: 10 },
  question: { fontSize: 15, color: '#111827', marginBottom: 4 },
  boxTag: { fontSize: 12, color: '#4F46E5', fontWeight: '600' },
  deleteButton: { padding: 8, borderRadius: 8, backgroundColor: '#FEE2E2' },
  deleteButtonText: { fontSize: 16 },
  empty: { textAlign: 'center', marginTop: 40, color: '#6B7280' },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    left: 24,
    backgroundColor: '#4F46E5',
    paddingVertical: 14,
    borderRadius: 30,
    elevation: 3,
    alignItems: 'center',
  },
  fabText: { color: '#fff', fontWeight: '600' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalBox: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 24,
  },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#111827', marginBottom: 16 },
  modalInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 10,
    padding: 12,
    fontSize: 15,
    marginBottom: 16,
  },
  modalLabel: { fontSize: 13, fontWeight: '600', color: '#374151', marginBottom: 10 },
  colorRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 20 },
  colorSwatch: { width: 36, height: 36, borderRadius: 18, marginRight: 10, marginBottom: 10 },
  colorSwatchSelected: { borderWidth: 3, borderColor: '#111827' },
  dangerButton: {
    backgroundColor: '#FEE2E2',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
    marginBottom: 16,
  },
  dangerButtonText: { color: '#B91C1C', fontWeight: '600', fontSize: 13 },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end' },
  modalCancelButton: { paddingVertical: 12, paddingHorizontal: 16 },
  modalCancelText: { color: '#6B7280', fontWeight: '600' },
  modalSaveButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 20,
  },
  modalSaveText: { color: '#fff', fontWeight: '700' },
});
