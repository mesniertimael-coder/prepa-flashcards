import { useCallback, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useFocusEffect } from 'expo-router';
import { getDueCards } from '../../src/db/queries/cards';
import { applyReviewResult } from '../../src/db/queries/leitner';
import { Flashcard } from '../../src/types/models';
import { BOX_LABELS } from '../../src/constants/leitner';

interface SessionStats {
  success: number;
  fail: number;
  total: number;
}

export default function RevisionScreen() {
  const [loading, setLoading] = useState(true);
  const [queue, setQueue] = useState<Flashcard[]>([]);
  const [showAnswer, setShowAnswer] = useState(false);
  const [sessionStats, setSessionStats] = useState<SessionStats>({
    success: 0,
    fail: 0,
    total: 0,
  });
  const [finished, setFinished] = useState(false);

  const loadDueCards = useCallback(async () => {
    setLoading(true);
    const cards = await getDueCards();
    setQueue(cards);
    setSessionStats({ success: 0, fail: 0, total: cards.length });
    setFinished(cards.length === 0);
    setShowAnswer(false);
    setLoading(false);
  }, []);

  // Recharge les cartes à réviser à chaque fois qu'on arrive sur l'onglet
  useFocusEffect(
    useCallback(() => {
      loadDueCards();
    }, [loadDueCards])
  );

  const currentCard = queue[0];

  const handleAnswer = async (wasSuccess: boolean) => {
    if (!currentCard) return;

    await applyReviewResult(currentCard.id, wasSuccess);

    setSessionStats((s) => ({
      ...s,
      success: s.success + (wasSuccess ? 1 : 0),
      fail: s.fail + (wasSuccess ? 0 : 1),
    }));

    const remaining = queue.slice(1);
    setQueue(remaining);
    setShowAnswer(false);
    if (remaining.length === 0) setFinished(true);
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  if (finished) {
    const { success, fail, total } = sessionStats;
    return (
      <View style={styles.center}>
        <Text style={styles.finishedTitle}>
          {total === 0 ? "Rien à réviser aujourd'hui 🎉" : 'Session terminée 🎉'}
        </Text>
        {total > 0 && (
          <Text style={styles.finishedStats}>
            {success} réussie{success > 1 ? 's' : ''} · {fail} échouée
            {fail > 1 ? 's' : ''} sur {total}
          </Text>
        )}
        <TouchableOpacity style={styles.reloadButton} onPress={loadDueCards}>
          <Text style={styles.reloadButtonText}>Actualiser</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const progress = sessionStats.total - queue.length + 1;

  return (
    <View style={styles.container}>
      <Text style={styles.progress}>
        Carte {progress} / {sessionStats.total}
      </Text>
      <Text style={styles.boxTag}>{BOX_LABELS[currentCard.box]}</Text>

      <View style={styles.card}>
        <Text style={styles.cardLabel}>Question</Text>
        <Text style={styles.cardText}>{currentCard.question}</Text>

        {showAnswer && (
          <>
            <View style={styles.divider} />
            <Text style={styles.cardLabel}>Réponse</Text>
            <Text style={styles.cardText}>{currentCard.answer}</Text>
          </>
        )}
      </View>

      {!showAnswer ? (
        <TouchableOpacity
          style={styles.revealButton}
          onPress={() => setShowAnswer(true)}
        >
          <Text style={styles.revealButtonText}>Afficher la réponse</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.answerButtons}>
          <TouchableOpacity
            style={[styles.answerButton, styles.failButton]}
            onPress={() => handleAnswer(false)}
          >
            <Text style={styles.answerButtonText}>❌ Échoué</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.answerButton, styles.successButton]}
            onPress={() => handleAnswer(true)}
          >
            <Text style={styles.answerButtonText}>✅ Réussi</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB', padding: 20 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  progress: { textAlign: 'center', color: '#6B7280', fontSize: 13, marginBottom: 4 },
  boxTag: {
    textAlign: 'center',
    color: '#4F46E5',
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 16,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    minHeight: 220,
    justifyContent: 'center',
    elevation: 2,
    marginBottom: 24,
  },
  cardLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#9CA3AF',
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  cardText: { fontSize: 18, color: '#111827', lineHeight: 26 },
  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 20 },
  revealButton: {
    backgroundColor: '#111827',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  revealButtonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  answerButtons: { flexDirection: 'row', marginHorizontal: -6 },
  answerButton: {
    flex: 1,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginHorizontal: 6,
  },
  failButton: { backgroundColor: '#FEE2E2' },
  successButton: { backgroundColor: '#D1FAE5' },
  answerButtonText: { fontWeight: '700', fontSize: 15, color: '#111827' },
  finishedTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 12,
    textAlign: 'center',
  },
  finishedStats: { fontSize: 15, color: '#6B7280', marginBottom: 24 },
  reloadButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  reloadButtonText: { color: '#fff', fontWeight: '600' },
});
