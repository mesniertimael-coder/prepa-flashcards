import { useEffect, useState, useCallback } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { getAllSubjects } from '../../src/db/queries/subjects';
import { Subject } from '../../src/types/models';

export default function SubjectsScreen() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const router = useRouter();

  const load = useCallback(async () => {
    const data = await getAllSubjects();
    setSubjects(data);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={subjects}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 16 }}
        renderItem={({ item }) => (
          <View style={[styles.card, { borderLeftColor: item.color }]}>
            <Text style={styles.cardTitle}>{item.name}</Text>
          </View>
        )}
        ListEmptyComponent={
          <Text style={styles.empty}>Aucune matière pour le moment.</Text>
        }
      />

      <View style={styles.fabRow}>
        <TouchableOpacity
          style={[styles.fab, styles.fabSecondary]}
          onPress={() => router.push('/card/ocr-capture')}
        >
          <Text style={styles.fabText}>📷 Scanner</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.fab}
          onPress={() => router.push('/card/create')}
        >
          <Text style={styles.fabText}>+ Créer</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 16,
    marginBottom: 10,
    borderLeftWidth: 5,
    elevation: 1,
  },
  cardTitle: { fontSize: 16, fontWeight: '600', color: '#111827' },
  empty: { textAlign: 'center', marginTop: 40, color: '#6B7280' },
  fabRow: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    left: 24,
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  fab: {
    backgroundColor: '#4F46E5',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 30,
    elevation: 3,
    marginLeft: 10,
  },
  fabSecondary: {
    backgroundColor: '#0EA5E9',
  },
  fabText: { color: '#fff', fontWeight: '600' },
});
