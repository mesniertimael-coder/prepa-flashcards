# Prepa Flashcards

Application 100% gratuite et locale de révision par flashcards avec système
de Leitner (5 boîtes), OCR pour scanner tes cours, base SQLite locale.

## Installation

```bash
npm install
npx expo install expo-sqlite expo-camera expo-image-manipulator expo-file-system expo-dev-client
npm install @react-native-ml-kit/text-recognition
```

### ⚠️ Important : l'app ne fonctionne plus avec Expo Go seul

Depuis l'ajout de l'OCR (Google ML Kit), le projet contient du code natif.
**Expo Go ne suffit plus** — il faut générer un client de développement une fois :

```bash
# Génère les dossiers natifs ios/ et android/
npx expo prebuild

# Lance sur un appareil/émulateur connecté (build local, gratuit)
npx expo run:android
# ou
npx expo run:ios
```

Ensuite, au quotidien, tu peux relancer simplement avec :

```bash
npx expo start --dev-client
```

(Nécessite Android Studio pour Android, ou Xcode pour iOS — 100% gratuit,
aucun service payant, tout tourne en local sur ta machine.)

## État d'avancement

- [x] Étape 1 — Init projet, schéma SQLite, CRUD matières/cartes
- [x] Étape 2 — Formulaire manuel + écran OCR (expo-camera + Google ML Kit)
- [x] Étape 3 — Algorithme Leitner + écran de session de révision

## Algorithme de Leitner (5 boîtes)

| Boîte | Intervalle avant re-révision |
|-------|-------------------------------|
| 1     | J+1                           |
| 2     | J+2                           |
| 3     | J+5                           |
| 4     | J+10                          |
| 5     | J+30                          |

- **Succès** → la carte monte à la boîte N+1 (plafonnée à la boîte 5).
- **Échec** → la carte retombe immédiatement en boîte 1.
- Chaque révision est journalisée dans `review_logs` (historique consultable).
- L'onglet **Révision** ne propose que les cartes dont `next_review_date` est
  aujourd'hui ou dépassée, triées par boîte (les plus urgentes en premier).

## Tester le flux complet

1. Crée quelques cartes (manuellement ou via scan).
2. Va dans l'onglet **Révision** : les cartes fraîchement créées sont en
   boîte 1, donc réviser dès aujourd'hui.
3. Réponds "Réussi"/"Échoué" — la carte disparaît de la session et sa
   prochaine date de révision est recalculée.
4. Onglet **Stats** : vérifie la répartition des cartes par boîte.

## Structure

```
app/                  # Écrans (expo-router)
  (tabs)/             # Onglets : Matières, Révision, Stats
  card/               # Création de carte (manuel + OCR)
src/
  db/                 # database.ts (init SQLite) + queries/ (CRUD)
  services/           # ocr.ts (à venir)
  types/              # models.ts
  constants/          # leitner.ts (intervalles J+1/2/5/10/30)
```
