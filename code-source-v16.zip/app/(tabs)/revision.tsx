import { useCallback, useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  FlatList,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { getDueCards } from '../../src/db/queries/cards';
import { getAllSubjects } from '../../src/db/queries/subjects';
import { applyReviewResult } from '../../src/db/queries/leitner';
import { Flashcard, Subject } from '../../src/types/models';
import { BOX_LABELS } from '../../src/constants/leitner';
import MathText from '../../src/components/MathText';
import { shuffleArray } from '../../src/utils/shuffle';
import { getSetting } from '../../src/db/queries/settings';

interface SessionStats {
  success: number;
  fail: number;
  total: number;
}

// Item unique pour la liste de filtres horizontale : soit le chip "Toutes",
// soit un chip matière.
interface FilterItem {
  key: string;
  subjectId: number | null;
  label: string;
  count: number;
  color?: string;
}

export default function RevisionScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [dueCountsBySubject, setDueCountsBySubject] = useState<Record<number, number>>({});
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);
  const [queue, setQueue] = useState<Flashcard[]>([]);
  const [showAnswer, setShowAnswer] = useState(false);
  const [sessionStats, setSessionStats] = useState<SessionStats>({
    success: 0,
    fail: 0,
    total: 0,
  });
  const [finished, setFinished] = useState(false);

  const loadDueCards = useCallback(async (subjectId: number | null) => {
    setLoading(true);
    const allSubjects = await getAllSubjects();
    setSubjects(allSubjects);

    // Compte les cartes dues par matière pour afficher un badge sur chaque filtre
    const allDue = await getDueCards();
    const counts: Record<number, number> = {};
    for (const c of allDue) {
      counts[c.subjectId] = (counts[c.subjectId] ?? 0) + 1;
    }
    setDueCountsBySubject(counts);

    const cards = subjectId
      ? allDue.filter((c) => c.subjectId === subjectId)
      : allDue;

    const randomSetting = await getSetting('random_review_order');
    const isRandom = randomSetting !== 'false'; // activé par défaut
    const finalCards = isRandom ? shuffleArray(cards) : cards;

    setQueue(finalCards);
    setSessionStats({ success: 0, fail: 0, total: finalCards.length });
    setFinished(finalCards.length === 0);
    setShowAnswer(false);
    setLoading(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadDueCards(selectedSubjectId);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedSubjectId])
  );

  const currentCard = queue[0];
  const totalDue = Object.values(dueCountsBySubject).reduce((a, b) => a + b, 0);

  const filterListRef = useRef<FlatList<FilterItem>>(null);

  const filterData: FilterItem[] = [
    { key: 'all', subjectId: null, label: 'Toutes', count: totalDue },
    ...subjects.map((s) => ({
      key: String(s.id),
      subjectId: s.id,
      label: s.name,
      count: dueCountsBySubject[s.id] ?? 0,
      color: s.color,
    })),
  ];

  // Si le nombre de matières change (ajout/suppression), on revient au début
  // de la liste : sur certaines versions de React Native, la zone de scroll
  // d'un ScrollView/FlatList horizontal ne recalcule pas toujours
  // correctement sa largeur totale quand le contenu change dynamiquement,
  // ce qui peut laisser l'utilisateur "coincé" sans pouvoir revenir
  // entièrement à gauche. On force donc explicitement un retour au début
  // dès que la liste de matières est mise à jour.
  useEffect(() => {
    filterListRef.current?.scrollToOffset({ offset: 0, animated: false });
  }, [subjects.length]);

  const handleAnswer = async (wasSuccess: boolean) => {
    if (!currentCard) return;

    await applyReviewResult(currentCard.id, wasSuccess);

    setSessionStats((s) => ({
      ...s,
      success: s.success + (wasSuccess ? 1 : 0),
      fail: s.fail + (wasSuccess ? 0 : 1),
    }));

    const remaining = queue.slice(1);
    setQueue(remaining);
    setShowAnswer(false);
    if (remaining.length === 0) setFinished(true);
  };

  const SubjectFilter = (
    <View style={styles.filterWrapper}>
      <FlatList
        ref={filterListRef}
        horizontal
        data={filterData}
        keyExtractor={(item) => item.key}
        showsHorizontalScrollIndicator={false}
        // removeClippedSubviews=false : sur Android, le clipping automatique
        // des vues hors-écran peut, sur une liste courte comme celle-ci,
        // rendre les premiers chips non cliquables/inatteignables tant que
        // la liste n'a pas été entièrement remesurée. On désactive ce
        // comportement pour fiabiliser le défilement complet.
        removeClippedSubviews={false}
        directionalLockEnabled
        bounces
        alwaysBounceHorizontal
        style={styles.scrollRow}
        contentContainerStyle={styles.filterRow}
        renderItem={({ item }) => {
          const isActive = selectedSubjectId === item.subjectId;
          return (
            <TouchableOpacity
              style={[
                styles.filterChip,
                item.color ? { borderColor: item.color } : null,
                isActive &&
                  (item.color
                    ? { backgroundColor: item.color, borderColor: item.color }
                    : styles.filterChipActive),
              ]}
              onPress={() => setSelectedSubjectId(item.subjectId)}
            >
              <Text style={[styles.filterChipText, isActive && styles.filterChipTextActive]}>
                {item.label}
                {item.count > 0 ? ` (${item.count})` : ''}
              </Text>
            </TouchableOpacity>
          );
        }}
      />
      <TouchableOpacity
        style={styles.trainLink}
        onPress={() =>
          router.push(
            selectedSubjectId
              ? `/card/train?subjectId=${selectedSubjectId}`
              : '/card/train'
          )
        }
      >
        <Text style={styles.trainLinkText}>
          🎯 Mode entraînement libre (illimité, sans effet sur les boîtes)
        </Text>
      </TouchableOpacity>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  if (finished) {
    const { success, fail, total } = sessionStats;
    return (
      <View style={styles.container}>
        {SubjectFilter}
        <View style={styles.center}>
          <Text style={styles.finishedTitle}>
            {total === 0 ? "Rien à réviser ici aujourd'hui 🎉" : 'Session terminée 🎉'}
          </Text>
          {total > 0 && (
            <Text style={styles.finishedStats}>
              {success} réussie{success > 1 ? 's' : ''} · {fail} échouée
              {fail > 1 ? 's' : ''} sur {total}
            </Text>
          )}
          <TouchableOpacity
            style={styles.reloadButton}
            onPress={() => loadDueCards(selectedSubjectId)}
          >
            <Text style={styles.reloadButtonText}>Actualiser</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const progress = sessionStats.total - queue.length + 1;

  return (
    <View style={styles.container}>
      {SubjectFilter}

      <ScrollView
        style={styles.sessionScroll}
        contentContainerStyle={styles.sessionArea}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={styles.progress}>
          Carte {progress} / {sessionStats.total}
        </Text>
        <Text style={styles.boxTag}>{BOX_LABELS[currentCard.box]}</Text>

        <View style={styles.card}>
          <Text style={styles.cardLabel}>Question</Text>
          <MathText content={currentCard.question} fontSize={18} />

          {showAnswer && (
            <>
              <View style={styles.divider} />
              <Text style={styles.cardLabel}>Réponse</Text>
              <MathText content={currentCard.answer} fontSize={18} />
            </>
          )}
        </View>

        {!showAnswer ? (
          <TouchableOpacity
            style={styles.revealButton}
            onPress={() => setShowAnswer(true)}
          >
            <Text style={styles.revealButtonText}>Afficher la réponse</Text>
          </TouchableOpacity>
        ) : (
          <View style={styles.answerButtons}>
            <TouchableOpacity
              style={[styles.answerButton, styles.failButton]}
              onPress={() => handleAnswer(false)}
            >
              <Text style={styles.answerButtonText}>❌ Échoué</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.answerButton, styles.successButton]}
              onPress={() => handleAnswer(true)}
            >
              <Text style={styles.answerButtonText}>✅ Réussi</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  sessionScroll: { flex: 1 },
  sessionArea: { padding: 20, paddingBottom: 40, flexGrow: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  filterWrapper: { paddingBottom: 4 },
  scrollRow: { height: 56, justifyContent: 'center' },
  trainLink: { paddingHorizontal: 16, paddingTop: 6, paddingBottom: 2 },
  trainLinkText: { fontSize: 12, color: '#4F46E5', fontWeight: '600' },
  filterRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
  },
  filterChip: {
    borderWidth: 1.5,
    borderColor: '#D1D5DB',
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginRight: 8,
    alignSelf: 'center',
  },
  filterChipActive: { backgroundColor: '#111827', borderColor: '#111827' },
  filterChipText: { fontSize: 13, color: '#374151', fontWeight: '500' },
  filterChipTextActive: { color: '#fff' },
  progress: { textAlign: 'center', color: '#6B7280', fontSize: 13, marginBottom: 4 },
  boxTag: {
    textAlign: 'center',
    color: '#4F46E5',
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 16,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    minHeight: 180,
    justifyContent: 'center',
    elevation: 2,
    marginBottom: 24,
  },
  cardLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#9CA3AF',
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  cardText: { fontSize: 18, color: '#111827', lineHeight: 26 },
  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 20 },
  revealButton: {
    backgroundColor: '#111827',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  revealButtonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  answerButtons: { flexDirection: 'row', marginHorizontal: -6 },
  answerButton: {
    flex: 1,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginHorizontal: 6,
  },
  failButton: { backgroundColor: '#FEE2E2' },
  successButton: { backgroundColor: '#D1FAE5' },
  answerButtonText: { fontWeight: '700', fontSize: 15, color: '#111827' },
  finishedTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 12,
    textAlign: 'center',
  },
  finishedStats: { fontSize: 15, color: '#6B7280', marginBottom: 24 },
  reloadButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  reloadButtonText: { color: '#fff', fontWeight: '600' },
});
