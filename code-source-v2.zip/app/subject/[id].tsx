import { useCallback, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useFocusEffect, useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { getSubjectById } from '../../src/db/queries/subjects';
import { getCardsBySubject, deleteCard } from '../../src/db/queries/cards';
import { Flashcard, Subject } from '../../src/types/models';
import { BOX_LABELS } from '../../src/constants/leitner';

export default function SubjectCardsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const subjectId = Number(id);
  const router = useRouter();

  const [subject, setSubject] = useState<Subject | null>(null);
  const [cards, setCards] = useState<Flashcard[]>([]);

  const load = useCallback(async () => {
    const [s, c] = await Promise.all([
      getSubjectById(subjectId),
      getCardsBySubject(subjectId),
    ]);
    setSubject(s);
    setCards(c);
  }, [subjectId]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleDelete = (card: Flashcard) => {
    Alert.alert(
      'Supprimer cette carte ?',
      card.question.length > 60
        ? card.question.slice(0, 60) + '…'
        : card.question,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: async () => {
            await deleteCard(card.id);
            load();
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: subject?.name ?? 'Cartes' }} />

      <FlatList
        data={cards}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 16, paddingBottom: 100 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.cardRow}
            onPress={() => router.push(`/card/${item.id}`)}
          >
            <View style={styles.cardTextBlock}>
              <Text style={styles.question} numberOfLines={2}>
                {item.question}
              </Text>
              <Text style={styles.boxTag}>{BOX_LABELS[item.box]}</Text>
            </View>
            <TouchableOpacity
              style={styles.deleteButton}
              onPress={() => handleDelete(item)}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <Text style={styles.deleteButtonText}>🗑️</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <Text style={styles.empty}>Aucune carte dans cette matière pour le moment.</Text>
        }
      />

      <TouchableOpacity
        style={styles.fab}
        onPress={() =>
          router.push({ pathname: '/card/create', params: { subjectId: String(subjectId) } })
        }
      >
        <Text style={styles.fabText}>+ Nouvelle carte</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 14,
    marginBottom: 10,
    elevation: 1,
  },
  cardTextBlock: { flex: 1, marginRight: 10 },
  question: { fontSize: 15, color: '#111827', marginBottom: 4 },
  boxTag: { fontSize: 12, color: '#4F46E5', fontWeight: '600' },
  deleteButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#FEE2E2',
  },
  deleteButtonText: { fontSize: 16 },
  empty: { textAlign: 'center', marginTop: 40, color: '#6B7280' },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    left: 24,
    backgroundColor: '#4F46E5',
    paddingVertical: 14,
    borderRadius: 30,
    elevation: 3,
    alignItems: 'center',
  },
  fabText: { color: '#fff', fontWeight: '600' },
});
