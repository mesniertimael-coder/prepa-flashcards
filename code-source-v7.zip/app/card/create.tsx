import { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { getAllSubjects } from '../../src/db/queries/subjects';
import { createCard } from '../../src/db/queries/cards';
import { Subject } from '../../src/types/models';
import MathText from '../../src/components/MathText';

export default function CreateCardScreen() {
  const params = useLocalSearchParams<{
    initialText?: string;
    sourceImageUri?: string;
    subjectId?: string;
  }>();
  const router = useRouter();

  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [saving, setSaving] = useState(false);

  const extractedText = params.initialText ?? '';

  useEffect(() => {
    getAllSubjects().then((data) => {
      setSubjects(data);
      if (params.subjectId) {
        setSelectedSubjectId(Number(params.subjectId));
      } else if (data.length > 0) {
        setSelectedSubjectId(data[0].id);
      }
    });
  }, []);

  const handleSave = async () => {
    if (!selectedSubjectId) {
      Alert.alert('Matière requise', 'Choisis une matière pour la carte.');
      return;
    }
    if (!question.trim() || !answer.trim()) {
      Alert.alert('Champs manquants', 'Renseigne la question et la réponse.');
      return;
    }

    try {
      setSaving(true);
      await createCard({
        subjectId: selectedSubjectId,
        question,
        answer,
        sourceImageUri: params.sourceImageUri ?? null,
      });
      router.back();
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', "La carte n'a pas pu être enregistrée.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Stack.Screen options={{ title: 'Nouvelle carte', headerShown: true }} />
      <Text style={styles.label}>Matière</Text>
      <View style={styles.chipRow}>
        {subjects.map((s) => (
          <TouchableOpacity
            key={s.id}
            style={[
              styles.chip,
              { borderColor: s.color },
              selectedSubjectId === s.id && { backgroundColor: s.color },
            ]}
            onPress={() => setSelectedSubjectId(s.id)}
          >
            <Text
              style={[
                styles.chipText,
                selectedSubjectId === s.id && { color: '#fff' },
              ]}
            >
              {s.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {extractedText.length > 0 && (
        <View style={styles.extractedBox}>
          <Text style={styles.extractedLabel}>Texte extrait de la photo</Text>
          <ScrollView style={styles.extractedScroll} nestedScrollEnabled>
            <Text style={styles.extractedText}>{extractedText}</Text>
          </ScrollView>
          <View style={styles.extractedActions}>
            <TouchableOpacity
              style={styles.smallButton}
              onPress={() =>
                setQuestion((q) => (q ? `${q}\n${extractedText}` : extractedText))
              }
            >
              <Text style={styles.smallButtonText}>→ Question</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.smallButton}
              onPress={() =>
                setAnswer((a) => (a ? `${a}\n${extractedText}` : extractedText))
              }
            >
              <Text style={styles.smallButtonText}>→ Réponse</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <Text style={styles.label}>Question</Text>
      <Text style={styles.latexHint}>
        Astuce : entoure les formules de $ pour un rendu mathématique, ex : $x^2 + y^2 = 1$
      </Text>
      <TextInput
        style={styles.input}
        multiline
        value={question}
        onChangeText={setQuestion}
        placeholder="Ex : Quelle est la dérivée de $\sin(x)$ ?"
      />
      {question.includes('$') && (
        <View style={styles.previewBox}>
          <Text style={styles.previewLabel}>Aperçu</Text>
          <MathText content={question} fontSize={15} />
        </View>
      )}

      <Text style={styles.label}>Réponse</Text>
      <TextInput
        style={styles.input}
        multiline
        value={answer}
        onChangeText={setAnswer}
        placeholder="Ex : $\cos(x)$"
      />
      {answer.includes('$') && (
        <View style={styles.previewBox}>
          <Text style={styles.previewLabel}>Aperçu</Text>
          <MathText content={answer} fontSize={15} />
        </View>
      )}

      <TouchableOpacity
        style={[styles.saveButton, saving && { opacity: 0.6 }]}
        onPress={handleSave}
        disabled={saving}
      >
        <Text style={styles.saveButtonText}>
          {saving ? 'Enregistrement…' : 'Enregistrer la carte'}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8, marginTop: 16 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap' },
  chip: {
    borderWidth: 1.5,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginRight: 8,
    marginBottom: 8,
  },
  chipText: { fontSize: 13, color: '#374151', fontWeight: '500' },
  latexHint: { fontSize: 11, color: '#9CA3AF', marginBottom: 6 },
  previewBox: {
    backgroundColor: '#F9FAFB',
    borderRadius: 8,
    padding: 10,
    marginTop: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  previewLabel: { fontSize: 11, fontWeight: '700', color: '#9CA3AF', marginBottom: 4 },
  extractedBox: { backgroundColor: '#F3F4F6', borderRadius: 10, padding: 12, marginTop: 16 },
  extractedLabel: { fontSize: 12, fontWeight: '700', color: '#6B7280', marginBottom: 6 },
  extractedScroll: { maxHeight: 100 },
  extractedText: { fontSize: 13, color: '#111827' },
  extractedActions: { flexDirection: 'row', marginTop: 8 },
  smallButton: {
    backgroundColor: '#E0E7FF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    marginRight: 8,
  },
  smallButtonText: { fontSize: 12, color: '#4338CA', fontWeight: '600' },
  input: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 10,
    padding: 12,
    fontSize: 15,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  saveButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 40,
  },
  saveButtonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
