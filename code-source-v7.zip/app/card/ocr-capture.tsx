import { useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImageManipulator from 'expo-image-manipulator';
import { useRouter, Stack } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { recognizeTextFromImage } from '../../src/services/ocr';

type Phase = 'camera' | 'processing';

export default function OcrCaptureScreen() {
  const [permission, requestPermission] = useCameraPermissions();
  const [phase, setPhase] = useState<Phase>('camera');
  const cameraRef = useRef<CameraView>(null);
  const router = useRouter();

  if (!permission) {
    return (
      <View style={styles.center}>
        <ActivityIndicator />
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={styles.center}>
        <Text style={styles.permissionText}>
          L'accès à l'appareil photo est nécessaire pour scanner tes cours.
        </Text>
        <TouchableOpacity style={styles.permissionButton} onPress={requestPermission}>
          <Text style={styles.permissionButtonText}>Autoriser la caméra</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const handleCapture = async () => {
    if (!cameraRef.current) return;

    try {
      setPhase('processing');
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.8 });
      if (!photo?.uri) throw new Error('Capture échouée');

      // Redimensionnement : accélère l'OCR et allège le fichier stocké.
      const manipulated = await ImageManipulator.manipulateAsync(
        photo.uri,
        [{ resize: { width: 1400 } }],
        { compress: 0.8, format: ImageManipulator.SaveFormat.JPEG }
      );

      const { text } = await recognizeTextFromImage(manipulated.uri);

      if (!text) {
        Alert.alert(
          'Aucun texte détecté',
          'Réessaie avec un meilleur éclairage ou un cadrage plus net, sans reflet.',
          [{ text: 'OK', onPress: () => setPhase('camera') }]
        );
        return;
      }

      router.replace({
        pathname: '/card/ocr-split',
        params: { rawText: text, sourceImageUri: manipulated.uri },
      });
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', "L'analyse du texte a échoué. Réessaie.");
      setPhase('camera');
    }
  };

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: 'Scanner un cours',
          headerShown: true,
          headerStyle: { backgroundColor: '#000' },
          headerTintColor: '#fff',
        }}
      />
      <CameraView ref={cameraRef} style={styles.camera} facing="back" />

      {phase === 'processing' && (
        <View style={styles.overlay}>
          <ActivityIndicator size="large" color="#fff" />
          <Text style={styles.overlayText}>Extraction du texte…</Text>
        </View>
      )}

      {phase === 'camera' && (
        <View style={styles.controls}>
          <TouchableOpacity style={styles.shutterButton} onPress={handleCapture}>
            <Ionicons name="camera" size={32} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.hint}>Cadre une page bien éclairée, sans reflet</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  camera: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  permissionText: { textAlign: 'center', marginBottom: 16, color: '#111827' },
  permissionButton: {
    backgroundColor: '#4F46E5',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  permissionButtonText: { color: '#fff', fontWeight: '600' },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlayText: { color: '#fff', marginTop: 12, fontSize: 15 },
  controls: {
    position: 'absolute',
    bottom: 40,
    width: '100%',
    alignItems: 'center',
  },
  shutterButton: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#4F46E5',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  hint: { color: '#fff', fontSize: 13 },
});
