import { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { getAllSubjects, getSubjectCardCount } from '../../src/db/queries/subjects';
import { exportSharedDeck } from '../../src/services/shareCards';
import { Subject } from '../../src/types/models';

interface SubjectWithCount extends Subject {
  cardCount: number;
}

export default function ShareExportScreen() {
  const { subjectId: preselectId } = useLocalSearchParams<{ subjectId?: string }>();
  const router = useRouter();

  const [subjects, setSubjects] = useState<SubjectWithCount[]>([]);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(true);
  const [sharing, setSharing] = useState(false);

  useEffect(() => {
    (async () => {
      const data = await getAllSubjects();
      const withCounts = await Promise.all(
        data.map(async (s) => ({ ...s, cardCount: await getSubjectCardCount(s.id) }))
      );
      setSubjects(withCounts);
      if (preselectId) {
        setSelected(new Set([Number(preselectId)]));
      }
      setLoading(false);
    })();
  }, [preselectId]);

  const toggle = (id: number) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const totalCards = subjects
    .filter((s) => selected.has(s.id))
    .reduce((sum, s) => sum + s.cardCount, 0);

  const handleShare = async () => {
    if (selected.size === 0) {
      Alert.alert('Aucune matière sélectionnée', 'Coche au moins une matière à partager.');
      return;
    }
    try {
      setSharing(true);
      const toShare = subjects.filter((s) => selected.has(s.id));
      await exportSharedDeck(toShare);
      router.back();
    } catch (err: any) {
      Alert.alert('Erreur', err?.message ?? "Le partage a échoué.");
    } finally {
      setSharing(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: 'Partager des cartes', headerShown: true }} />

      <Text style={styles.intro}>
        Choisis les matières à inclure dans le fichier partagé. La progression
        de révision ne sera pas incluse : la personne qui reçoit repart de zéro.
      </Text>

      <ScrollView contentContainerStyle={{ paddingBottom: 20 }}>
        {subjects.map((s) => {
          const isChecked = selected.has(s.id);
          return (
            <TouchableOpacity
              key={s.id}
              style={styles.row}
              onPress={() => toggle(s.id)}
              disabled={s.cardCount === 0}
            >
              <View style={[styles.checkbox, isChecked && styles.checkboxChecked]}>
                {isChecked && <Text style={styles.checkboxMark}>✓</Text>}
              </View>
              <View style={[styles.dot, { backgroundColor: s.color }]} />
              <Text style={[styles.rowLabel, s.cardCount === 0 && styles.rowLabelDisabled]}>
                {s.name}
              </Text>
              <Text style={styles.rowCount}>{s.cardCount}</Text>
            </TouchableOpacity>
          );
        })}
        {subjects.length === 0 && (
          <Text style={styles.empty}>Aucune matière pour le moment.</Text>
        )}
      </ScrollView>

      <TouchableOpacity
        style={[styles.shareButton, (sharing || totalCards === 0) && { opacity: 0.6 }]}
        onPress={handleShare}
        disabled={sharing || totalCards === 0}
      >
        <Text style={styles.shareButtonText}>
          {sharing
            ? 'Préparation du fichier…'
            : `📤 Partager ${totalCards} carte${totalCards !== 1 ? 's' : ''}`}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  intro: { fontSize: 13, color: '#6B7280', lineHeight: 19, marginBottom: 16 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#D1D5DB',
    marginRight: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxChecked: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  checkboxMark: { color: '#fff', fontSize: 13, fontWeight: '700' },
  dot: { width: 10, height: 10, borderRadius: 5, marginRight: 10 },
  rowLabel: { flex: 1, fontSize: 15, color: '#111827' },
  rowLabelDisabled: { color: '#D1D5DB' },
  rowCount: { fontSize: 13, color: '#6B7280', fontWeight: '600' },
  empty: { textAlign: 'center', color: '#6B7280', marginTop: 20 },
  shareButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  shareButtonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
