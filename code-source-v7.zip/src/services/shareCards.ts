import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { getCardsBySubject } from '../db/queries/cards';
import { Subject } from '../types/models';

export interface SharedCard {
  question: string;
  answer: string;
}

export interface SharedGroup {
  subjectName: string;
  subjectColor: string;
  cards: SharedCard[];
}

export interface SharedDeckFile {
  type: 'flashcards_share';
  version: 1;
  exportedAt: string;
  groups: SharedGroup[];
}

/**
 * Génère un fichier de partage contenant uniquement les cartes (question/
 * réponse) des matières sélectionnées, groupées par matière d'origine.
 * Ne contient volontairement pas la progression Leitner : la personne qui
 * reçoit commence ses propres cartes à zéro.
 */
export async function exportSharedDeck(subjects: Subject[]): Promise<void> {
  const groups: SharedGroup[] = [];

  for (const subject of subjects) {
    const cards = await getCardsBySubject(subject.id);
    if (cards.length === 0) continue;
    groups.push({
      subjectName: subject.name,
      subjectColor: subject.color,
      cards: cards.map((c) => ({ question: c.question, answer: c.answer })),
    });
  }

  const payload: SharedDeckFile = {
    type: 'flashcards_share',
    version: 1,
    exportedAt: new Date().toISOString(),
    groups,
  };

  const fileName = `cartes-partagees-${new Date().toISOString().slice(0, 10)}.json`;
  const fileUri = FileSystem.documentDirectory + fileName;

  await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(payload, null, 2), {
    encoding: FileSystem.EncodingType.UTF8,
  });

  const canShare = await Sharing.isAvailableAsync();
  if (!canShare) {
    throw new Error('Le partage de fichiers n\'est pas disponible sur cet appareil.');
  }

  await Sharing.shareAsync(fileUri, {
    mimeType: 'application/json',
    dialogTitle: 'Partager mes cartes',
  });
}

/**
 * Lit et valide un fichier de partage reçu. Ne modifie pas la base :
 * l'écran d'import se charge ensuite de proposer le tri par dossier.
 */
export async function parseSharedDeckFile(fileUri: string): Promise<SharedGroup[]> {
  const content = await FileSystem.readAsStringAsync(fileUri, {
    encoding: FileSystem.EncodingType.UTF8,
  });

  let data: SharedDeckFile;
  try {
    data = JSON.parse(content);
  } catch {
    throw new Error('Ce fichier n\'est pas un fichier de cartes valide.');
  }

  if (data.type !== 'flashcards_share' || !Array.isArray(data.groups)) {
    throw new Error('Ce fichier ne contient pas de cartes partagées reconnaissables.');
  }

  return data.groups;
}
