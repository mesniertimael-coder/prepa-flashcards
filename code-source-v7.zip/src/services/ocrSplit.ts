export interface CardDraft {
  id: string;
  question: string;
  answer: string;
  include: boolean;
}

const QUESTION_MARKER = /^(q\s*[:.)]|question\s*[:.]|Q\d*\s*[:.)]|^\d+[.)]\s*)/i;
const ANSWER_MARKER = /^(r\s*[:.)]|réponse\s*[:.]|reponse\s*[:.]|a\s*[:.)]|answer\s*[:.]|R\d*\s*[:.)])/i;
const BULLET_MARKER = /^[-•*▪]\s*/;
const NUMBERED_MARKER = /^\d+[.)]\s*/;

let draftCounter = 0;
function nextId(prefix: string): string {
  draftCounter += 1;
  return `${prefix}-${draftCounter}`;
}

/**
 * Tente de transformer un bloc de texte brut (issu de l'OCR) en plusieurs
 * cartes Question/Réponse, en essayant plusieurs stratégies par ordre de
 * fiabilité décroissante. Le résultat est toujours éditable par l'utilisateur
 * avant sauvegarde : ce découpage est une aide, pas une vérité absolue.
 */
export function splitOcrTextIntoCards(rawText: string): CardDraft[] {
  const lines = rawText
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length === 0) return [];

  // Stratégie 1 : marqueurs explicites Q:/R: ou Question:/Réponse:
  const explicit = tryExplicitQRPairing(lines);
  if (explicit.length > 0) return explicit;

  // Stratégie 2 : liste à puces ou numérotée -> une carte par ligne
  // (question = ligne, réponse à compléter par l'utilisateur)
  const listLikeCount = lines.filter(
    (l) => BULLET_MARKER.test(l) || NUMBERED_MARKER.test(l)
  ).length;
  if (listLikeCount >= Math.max(2, Math.ceil(lines.length / 2))) {
    return lines.map((l) => ({
      id: nextId('list'),
      question: l.replace(BULLET_MARKER, '').replace(NUMBERED_MARKER, '').trim(),
      answer: '',
      include: true,
    }));
  }

  // Stratégie 3 (repli) : associe les lignes deux par deux
  // (ligne 1 = question, ligne 2 = réponse, etc.)
  const paired: CardDraft[] = [];
  for (let i = 0; i < lines.length; i += 2) {
    paired.push({
      id: nextId('pair'),
      question: lines[i],
      answer: lines[i + 1] ?? '',
      include: true,
    });
  }
  return paired;
}

function tryExplicitQRPairing(lines: string[]): CardDraft[] {
  const cards: CardDraft[] = [];
  let currentQuestion: string | null = null;

  for (const line of lines) {
    if (QUESTION_MARKER.test(line) && !ANSWER_MARKER.test(line)) {
      currentQuestion = line.replace(QUESTION_MARKER, '').trim();
    } else if (ANSWER_MARKER.test(line) && currentQuestion) {
      const answer = line.replace(ANSWER_MARKER, '').trim();
      cards.push({ id: nextId('qr'), question: currentQuestion, answer, include: true });
      currentQuestion = null;
    }
  }

  return cards;
}
