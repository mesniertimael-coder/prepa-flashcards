import { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';

interface MathTextProps {
  content: string;
  fontSize?: number;
  color?: string;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/**
 * Affiche du texte, avec rendu des formules LaTeX si le contenu contient
 * des délimiteurs $...$ (inline) ou $$...$$ (bloc). Sinon, affiche un
 * simple <Text> React Native (plus léger, pas de WebView inutile).
 */
export default function MathText({ content, fontSize = 18, color = '#111827' }: MathTextProps) {
  const [height, setHeight] = useState(30);

  const hasMath = content.includes('$');

  if (!hasMath) {
    return (
      <Text style={{ fontSize, color, lineHeight: fontSize * 1.4 }}>{content}</Text>
    );
  }

  const safeContent = escapeHtml(content).replace(/\n/g, '<br/>');

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/contrib/auto-render.min.js"></script>
  <style>
    * { -webkit-touch-callout: none; -webkit-user-select: none; user-select: none; }
    html, body {
      margin: 0;
      padding: 0;
      background: transparent;
    }
    body {
      font-family: -apple-system, Roboto, sans-serif;
      font-size: ${fontSize}px;
      color: ${color};
      line-height: 1.45;
      word-wrap: break-word;
      padding: 2px 0;
    }
  </style>
</head>
<body>
  <div id="content">${safeContent}</div>
  <script>
    function reportHeight() {
      var h = document.body.scrollHeight;
      window.ReactNativeWebView.postMessage(String(h));
    }
    document.addEventListener('DOMContentLoaded', function () {
      try {
        renderMathInElement(document.getElementById('content'), {
          delimiters: [
            { left: '$$', right: '$$', display: true },
            { left: '$', right: '$', display: false }
          ],
          throwOnError: false
        });
      } catch (e) {}
      setTimeout(reportHeight, 60);
      setTimeout(reportHeight, 300);
    });
  </script>
</body>
</html>`;

  return (
    <View style={[styles.webviewWrapper, { height, width: '100%' }]}>
      <WebView
        originWhitelist={['*']}
        source={{ html }}
        onMessage={(e) => {
          const h = Number(e.nativeEvent.data);
          if (!isNaN(h) && h > 0 && Math.abs(h - height) > 2) setHeight(h);
        }}
        scrollEnabled={false}
        style={styles.webview}
        javaScriptEnabled
      />
    </View>
  );
}

const styles = StyleSheet.create({
  webviewWrapper: { backgroundColor: 'transparent' },
  webview: { backgroundColor: 'transparent' },
});
