import { forwardRef, useImperativeHandle, useRef } from 'react';
import { View, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';
import { convertSpokenMathToLatex } from '../utils/speechToLatex';

export interface VoiceInputHandle {
  start: () => void;
  stop: () => void;
}

interface Props {
  onResult: (text: string) => void;
  onEnd: () => void;
  onError: (error: string) => void;
}

const HTML = `<!DOCTYPE html>
<html><body>
<script>
  var recognition = null;

  function startRec(lang) {
    try {
      var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SpeechRecognition) {
        window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'error', error: 'not_supported' }));
        return;
      }
      recognition = new SpeechRecognition();
      recognition.lang = lang;
      recognition.interimResults = true;
      recognition.continuous = false;

      recognition.onresult = function (event) {
        var text = '';
        for (var i = 0; i < event.results.length; i++) {
          text += event.results[i][0].transcript;
        }
        window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'result', text: text }));
      };
      recognition.onerror = function (event) {
        window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'error', error: event.error }));
      };
      recognition.onend = function () {
        window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'end' }));
      };
      recognition.start();
    } catch (e) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'error', error: String(e) }));
    }
  }

  function stopRec() {
    if (recognition) {
      try { recognition.stop(); } catch (e) {}
    }
  }
</script>
</body></html>`;

/**
 * Reconnaissance vocale via l'API Web Speech du navigateur intégré
 * (WebView), sans dépendance native — évite les problèmes de compilation
 * Android que posent certaines librairies de reconnaissance vocale natives.
 */
const VoiceInputWebView = forwardRef<VoiceInputHandle, Props>(
  ({ onResult, onEnd, onError }, ref) => {
    const webviewRef = useRef<WebView>(null);

    useImperativeHandle(ref, () => ({
      start: () => {
        webviewRef.current?.injectJavaScript('startRec("fr-FR"); true;');
      },
      stop: () => {
        webviewRef.current?.injectJavaScript('stopRec(); true;');
      },
    }));

    return (
      <View style={styles.hidden}>
        <WebView
          ref={webviewRef}
          originWhitelist={['*']}
          source={{ html: HTML }}
          javaScriptEnabled
          mediaCapturePermissionGrantType="grant"
          onPermissionRequest={(request) => request.grant(request.resources)}
          onMessage={(e) => {
            try {
              const data = JSON.parse(e.nativeEvent.data);
              // On convertit le vocabulaire mathématique/ponctuation dicté
              // (ex. "x au carré", "pi", "ouvre parenthèse") en symboles
              // spéciaux et en LaTeX ($...$) avant de renvoyer le texte,
              // pour que la dictée produise directement des caractères
              // spéciaux et des formules exploitables par MathText.
              if (data.type === 'result') onResult(convertSpokenMathToLatex(data.text));
              else if (data.type === 'end') onEnd();
              else if (data.type === 'error') onError(data.error);
            } catch {
              onError('invalid_message');
            }
          }}
        />
      </View>
    );
  }
);

export default VoiceInputWebView;

const styles = StyleSheet.create({
  hidden: { width: 1, height: 1, opacity: 0, position: 'absolute' },
});
