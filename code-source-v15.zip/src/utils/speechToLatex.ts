/**
 * Convertit une transcription vocale brute (français) en texte enrichi de
 * symboles spéciaux et, quand c'est pertinent, en LaTeX compatible avec le
 * rendu MathText (délimiteurs $...$), sur le même principe que la saisie
 * manuelle ("entoure tes formules de $").
 *
 * Le moteur de reconnaissance vocale ne renvoie que des mots simples : il ne
 * sait pas dicter "²", "√" ou "\frac{}{}" directement. Cette fonction repère
 * le vocabulaire mathématique/ponctuation courant prononcé à l'oral et le
 * transforme, puis n'entoure de $...$ que les portions réellement
 * mathématiques de la phrase (pas le texte français autour).
 *
 * Ce n'est pas un analyseur exhaustif : c'est une conversion par
 * reconnaissance de motifs, volontairement prudente pour éviter de casser
 * des mots français courants ("plus", "point"... ne sont convertis que dans
 * des contextes sans ambiguïté ou en dernier recours).
 */

// --- Petits alphabets ------------------------------------------------------

const GREEK_LETTERS: [RegExp, string][] = [
  [/\balpha\b/gi, '\\alpha'],
  [/\bb[êe]ta\b/gi, '\\beta'],
  [/\bgamma\b/gi, '\\gamma'],
  [/\bdelta\b/gi, '\\delta'],
  [/\bepsilon\b/gi, '\\epsilon'],
  [/\bz[êe]ta\b/gi, '\\zeta'],
  [/(?<![a-zA-Z0-9])[êe]ta\b/gi, '\\eta'],
  [/\bth[êe]ta\b/gi, '\\theta'],
  [/\biota\b/gi, '\\iota'],
  [/\bkappa\b/gi, '\\kappa'],
  [/\blambda\b/gi, '\\lambda'],
  [/\bmu\b/gi, '\\mu'],
  [/\bnu\b/gi, '\\nu'],
  [/\bxi\b/gi, '\\xi'],
  [/\brho\b/gi, '\\rho'],
  [/\bsigma\b/gi, '\\sigma'],
  [/\btau\b/gi, '\\tau'],
  [/\bupsilon\b/gi, '\\upsilon'],
  [/\bphi\b/gi, '\\phi'],
  [/\b(khi|chi)\b/gi, '\\chi'],
  [/\bpsi\b/gi, '\\psi'],
  [/\bom[ée]ga\b/gi, '\\omega'],
];

const NUMBER_WORDS: Record<string, string> = {
  'zéro': '0', 'zero': '0',
  'un': '1', 'une': '1',
  'deux': '2',
  'trois': '3',
  'quatre': '4',
  'cinq': '5',
  'six': '6',
  'sept': '7',
  'huit': '8',
  'neuf': '9',
  'dix': '10',
};

/** Ordre important : motifs les plus longs / spécifiques en premier. */
function buildRules(): [RegExp, string | ((...args: string[]) => string)][] {
  return [
    // Nombres décimaux dictés ("3 virgule 14" -> "3,14")
    [/(\d+)\s*virgule\s*(\d+)/gi, '$1,$2'],

    // Fractions ("1 sur 2" / "fraction 1 sur 2" -> "\frac{1}{2}")
    [/\bfraction\s+(\d+)\s+sur\s+(\d+)\b/gi, '\\frac{$1}{$2}'],
    [/\b(\d+)\s+sur\s+(\d+)\b/gi, '\\frac{$1}{$2}'],

    // Racines
    [/racine\s+carr[ée]e?\s+de\s+([a-zA-Z0-9]+)/gi, '\\sqrt{$1}'],
    [/racine\s+cubique\s+de\s+([a-zA-Z0-9]+)/gi, '\\sqrt[3]{$1}'],

    // Puissances / exposants, attachés à la variable ou au nombre qui précède
    [/([a-zA-Z0-9)\]])\s+au\s+carr[ée](?![a-zA-Z0-9])/gi, '$1^2'],
    [/([a-zA-Z0-9)\]])\s+au\s+cube\b/gi, '$1^3'],
    [
      /([a-zA-Z0-9)\]])\s+puissance\s+(\d+|[a-zéèêà]+)(?![a-zA-Z0-9])/gi,
      (_m: string, base: string, exp: string) => {
        const digit = /^\d+$/.test(exp) ? exp : NUMBER_WORDS[exp.toLowerCase()] ?? exp;
        return `${base}^{${digit}}`;
      },
    ],

    // Comparaisons (du plus spécifique au plus général)
    [/inf[ée]rieur\s+ou\s+[ée]gale?\s+[àa]/gi, '\\leq'],
    [/sup[ée]rieur\s+ou\s+[ée]gale?\s+[àa]/gi, '\\geq'],
    [/strictement\s+inf[ée]rieur\s+[àa]/gi, '<'],
    [/strictement\s+sup[ée]rieur\s+[àa]/gi, '>'],
    [/inf[ée]rieur\s+[àa]/gi, '<'],
    [/sup[ée]rieur\s+[àa]/gi, '>'],
    [/diff[ée]rent\s+de/gi, '\\neq'],
    [/(?:environ|approximativement)\s+[ée]gale?\s+[àa]/gi, '\\approx'],
    [/(?:est\s+)?[ée]gale?\s+[àa]/gi, '='],
    [/(?<![a-zA-Z0-9])[ée]gale?(?![a-zA-Z0-9])/gi, '='],

    // Ensembles / logique
    [/n.appartient\s+pas\s+[àa]/gi, '\\notin'],
    [/appartient\s+[àa]/gi, '\\in'],
    [/inclus\s+dans/gi, '\\subset'],
    [/pour\s+tout/gi, '\\forall'],
    [/il\s+existe/gi, '\\exists'],
    [/plus\s+ou\s+moins/gi, '\\pm'],

    // Opérateurs de base
    [/multipli[ée]e?\s+par/gi, '\\times'],
    [/divis[ée]e?\s+par/gi, '\\div'],
    [/\bfois\b/gi, '\\times'],
    [/\bplus\b/gi, '+'],
    [/\bmoins\b/gi, '-'],

    // Constantes
    [/\bpi\b/gi, '\\pi'],
    [/\binfini\b/gi, '\\infty'],
    ...GREEK_LETTERS,

    // Vocabulaire d'analyse / calcul
    [/vecteur\s+([a-zA-Z])\b/gi, '\\vec{$1}'],
    [/\bsomme\b/gi, '\\sum'],
    [/\bproduit\b/gi, '\\prod'],
    [/\bint[ée]grale\b/gi, '\\int'],
    [/\blimite\b/gi, '\\lim'],

    // Ponctuation et symboles dictés
    [/ouvre(?:\s+la)?\s+parenth[èe]se/gi, '('],
    [/ferme(?:\s+la)?\s+parenth[èe]se/gi, ')'],
    [/ouvre\s+crochet/gi, '['],
    [/ferme\s+crochet/gi, ']'],
    [/deux\s+points/gi, ':'],
    [/point\s+virgule/gi, ';'],
    [/point\s+d.interrogation/gi, '?'],
    [/point\s+d.exclamation/gi, '!'],
    [/point\s+final/gi, '.'],
    [/\bpourcent\b/gi, '%'],
    [/\bvirgule\b/gi, ','],
    [/nouvelle\s+ligne/gi, '\n'],
    [/nouveau\s+paragraphe/gi, '\n\n'],
  ];
}

/** Applique toutes les règles de substitution, dans l'ordre. */
function applyVocabulary(input: string): string {
  let text = input;
  for (const [pattern, replacement] of buildRules()) {
    text = text.replace(pattern, replacement as any);
  }
  return text;
}

// Symboles qui n'apparaissent jamais dans un mot français ordinaire : leur
// seule présence dans le token suffit à le considérer mathématique.
const HARD_MATH_CHARS = /[\\^_=<>≤≥≠±∈∉⊂∞]/;
// "+"/"-"/"×"/"÷" ne sont traités comme "durs" que si le token EST le
// symbole (et rien d'autre) — sinon un simple mot avec trait d'union
// ("peut-être") serait à tort considéré comme mathématique.
const HARD_STANDALONE = new Set(['+', '-', '×', '÷', '±']);
const SOFT_SINGLE_LETTER = /^[a-zA-Zα-ωΑ-Ω]$/;
const SOFT_NUMBER = /^-?\d+([.,]\d+)?$/;
const SOFT_PAREN = new Set(['(', ')', '[', ']']);

interface Token {
  text: string;
  isSpace: boolean;
  kind: 'hard' | 'soft' | 'plain';
  inRun: boolean;
}

/** N'entoure de $...$ que les portions mathématiques d'une phrase. */
function wrapMathSpans(text: string): string {
  const rawTokens = text.split(/(\s+)/).filter((t) => t.length > 0);

  const tokens: Token[] = rawTokens.map((t) => {
    const isSpace = /^\s+$/.test(t);
    if (isSpace) return { text: t, isSpace, kind: 'plain', inRun: false };
    const bare = t.replace(/[?!.,;:]+$/, '');
    let kind: Token['kind'] = 'plain';
    if (HARD_MATH_CHARS.test(t) || HARD_STANDALONE.has(bare)) kind = 'hard';
    else if (SOFT_SINGLE_LETTER.test(bare) || SOFT_NUMBER.test(bare) || SOFT_PAREN.has(bare))
      kind = 'soft';
    return { text: t, isSpace, kind, inRun: kind === 'hard' };
  });

  // Propage l'appartenance à une "zone mathématique" aux tokens "soft"
  // directement voisins d'un token "hard" (en ignorant les espaces).
  for (let round = 0; round < 2; round++) {
    for (let i = 0; i < tokens.length; i++) {
      const tok = tokens[i];
      if (tok.isSpace || tok.kind !== 'soft' || tok.inRun) continue;
      const prev = tokens
        .slice(0, i)
        .reverse()
        .find((t) => !t.isSpace);
      const next = tokens.slice(i + 1).find((t) => !t.isSpace);
      if ((prev && prev.inRun) || (next && next.inRun)) {
        tok.inRun = true;
      }
    }
  }

  let out = '';
  let i = 0;
  while (i < tokens.length) {
    if (!tokens[i].isSpace && tokens[i].inRun) {
      let j = i;
      let end = i;
      while (j < tokens.length && (tokens[j].isSpace || tokens[j].inRun)) {
        if (!tokens[j].isSpace) end = j;
        j++;
      }
      const run = tokens
        .slice(i, end + 1)
        .map((t) => t.text)
        .join('');
      out += `$${run.trim()}$`;
      i = end + 1;
    } else {
      out += tokens[i].text;
      i++;
    }
  }
  return out;
}

/**
 * Point d'entrée : à appeler sur chaque transcription reçue du moteur de
 * reconnaissance vocale avant de l'insérer dans le champ question/réponse.
 */
export function convertSpokenMathToLatex(raw: string): string {
  if (!raw || !raw.trim()) return raw;
  const withVocabulary = applyVocabulary(raw);
  return wrapMathSpans(withVocabulary);
}
