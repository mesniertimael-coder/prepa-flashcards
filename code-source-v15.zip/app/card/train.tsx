import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { getCardsBySubject, getAllCards } from '../../src/db/queries/cards';
import { getSubjectById } from '../../src/db/queries/subjects';
import { Flashcard } from '../../src/types/models';
import { shuffleArray } from '../../src/utils/shuffle';
import MathText from '../../src/components/MathText';

/**
 * Mode entraînement libre : cartes mélangées, à l'infini, sans jamais
 * toucher aux boîtes de Leitner ni à la date de prochaine révision.
 * Purement pour du bachotage / mémorisation à la demande.
 */
export default function TrainScreen() {
  const { subjectId } = useLocalSearchParams<{ subjectId?: string }>();
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [subjectName, setSubjectName] = useState<string | null>(null);
  const [allCards, setAllCards] = useState<Flashcard[]>([]);
  const [queue, setQueue] = useState<Flashcard[]>([]);
  const [showAnswer, setShowAnswer] = useState(false);
  const [seenCount, setSeenCount] = useState(0);
  const [lap, setLap] = useState(1);

  useEffect(() => {
    (async () => {
      setLoading(true);
      let cards: Flashcard[];
      if (subjectId) {
        cards = await getCardsBySubject(Number(subjectId));
        const s = await getSubjectById(Number(subjectId));
        setSubjectName(s?.name ?? null);
      } else {
        cards = await getAllCards();
        setSubjectName(null);
      }
      setAllCards(cards);
      setQueue(shuffleArray(cards));
      setLoading(false);
    })();
  }, [subjectId]);

  const currentCard = queue[0];

  const handleNext = () => {
    setSeenCount((c) => c + 1);
    const remaining = queue.slice(1);
    if (remaining.length === 0) {
      // Fin d'un tour : on remélange et on recommence, à l'infini
      setQueue(shuffleArray(allCards));
      setLap((l) => l + 1);
    } else {
      setQueue(remaining);
    }
    setShowAnswer(false);
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  if (allCards.length === 0) {
    return (
      <View style={styles.center}>
        <Stack.Screen options={{ title: 'Entraînement', headerShown: true }} />
        <Text style={styles.emptyText}>
          {subjectName ? `Aucune carte dans ${subjectName}.` : 'Aucune carte pour le moment.'}
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: subjectName ? `Entraînement · ${subjectName}` : 'Entraînement libre',
          headerShown: true,
        }}
      />

      <View style={styles.header}>
        <Text style={styles.headerText}>
          Tour {lap} · {seenCount} carte{seenCount !== 1 ? 's' : ''} vue{seenCount !== 1 ? 's' : ''}
        </Text>
      </View>

      <View style={styles.cardArea}>
        <View style={styles.card}>
          <Text style={styles.cardLabel}>Question</Text>
          <MathText content={currentCard.question} fontSize={18} />

          {showAnswer && (
            <>
              <View style={styles.divider} />
              <Text style={styles.cardLabel}>Réponse</Text>
              <MathText content={currentCard.answer} fontSize={18} />
            </>
          )}
        </View>

        {!showAnswer ? (
          <TouchableOpacity style={styles.revealButton} onPress={() => setShowAnswer(true)}>
            <Text style={styles.revealButtonText}>Afficher la réponse</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
            <Text style={styles.nextButtonText}>Carte suivante →</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  emptyText: { color: '#6B7280', fontSize: 14, textAlign: 'center' },
  header: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 4 },
  headerText: { textAlign: 'center', color: '#6B7280', fontSize: 13, fontWeight: '600' },
  cardArea: { flex: 1, padding: 20, justifyContent: 'center' },
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    minHeight: 200,
    justifyContent: 'center',
    elevation: 2,
    marginBottom: 24,
  },
  cardLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#9CA3AF',
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 20 },
  revealButton: {
    backgroundColor: '#111827',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  revealButtonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  nextButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  nextButtonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
