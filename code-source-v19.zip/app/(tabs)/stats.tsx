import { useCallback, useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useFocusEffect } from 'expo-router';
import {
  getCardCountByBox,
  getNextReviewDateByBox,
  getReviewStatsByDay,
  getUpcomingReviewCounts,
  DailyReviewStat,
  UpcomingReviewCount,
} from '../../src/db/queries/cards';
import { getAllSubjects, getCardCountsBySubject } from '../../src/db/queries/subjects';
import { BOX_LABELS, MAX_BOX } from '../../src/constants/leitner';
import { Subject } from '../../src/types/models';
import { formatReviewDate, formatShortDay } from '../../src/utils/date';
import SimpleBarChart from '../../src/components/SimpleBarChart';
import { useTheme } from '../../src/theme/useTheme';
import { ThemeColors } from '../../src/theme/colors';

const BOX_COLORS_LIGHT: Record<number, string> = {
  1: '#EF4444',
  2: '#F59E0B',
  3: '#EAB308',
  4: '#84CC16',
  5: '#10B981',
};
const BOX_COLORS_DARK: Record<number, string> = {
  1: '#F87171',
  2: '#FBBF24',
  3: '#FDE047',
  4: '#A3E635',
  5: '#34D399',
};

export default function StatsScreen() {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const boxColors = theme.mode === 'dark' ? BOX_COLORS_DARK : BOX_COLORS_LIGHT;

  const [counts, setCounts] = useState<Record<number, number>>({});
  const [nextDates, setNextDates] = useState<Record<number, string>>({});
  const [subjects, setSubjects] = useState<(Subject & { cardCount: number })[]>([]);
  const [dailyStats, setDailyStats] = useState<DailyReviewStat[]>([]);
  const [upcoming, setUpcoming] = useState<UpcomingReviewCount[]>([]);

  const load = useCallback(async () => {
    const [byBox, byBoxDates, allSubjects, cardCounts, daily, next7Days] = await Promise.all([
      getCardCountByBox(),
      getNextReviewDateByBox(),
      getAllSubjects(),
      getCardCountsBySubject(),
      getReviewStatsByDay(7),
      getUpcomingReviewCounts(7),
    ]);
    setCounts(byBox);
    setNextDates(byBoxDates);
    const withCounts = allSubjects.map((s) => ({ ...s, cardCount: cardCounts[s.id] ?? 0 }));
    setSubjects(withCounts);
    setDailyStats(daily);
    setUpcoming(next7Days);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const totalCards = Object.values(counts).reduce((a, b) => a + b, 0);
  const mastered = counts[MAX_BOX] ?? 0;
  const masteredPercent = totalCards > 0 ? Math.round((mastered / totalCards) * 100) : 0;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <View style={styles.summaryCard}>
        <Text style={styles.summaryNumber}>{masteredPercent}%</Text>
        <Text style={styles.summaryLabel}>
          de tes {totalCards} carte{totalCards !== 1 ? 's' : ''} sont maîtrisées (boîte 5)
        </Text>
      </View>

      <Text style={styles.sectionTitle}>Répartition par boîte</Text>
      <View style={styles.card}>
        {Object.entries(BOX_LABELS).map(([box, label]) => {
          const boxNum = Number(box);
          const count = counts[boxNum] ?? 0;
          const percent = totalCards > 0 ? (count / totalCards) * 100 : 0;
          return (
            <View key={box} style={styles.boxRow}>
              <View style={styles.boxRowHeader}>
                <Text style={styles.boxLabel}>{label}</Text>
                <Text style={styles.boxValue}>{count}</Text>
              </View>
              <View style={styles.barTrack}>
                <View
                  style={[
                    styles.barFill,
                    { width: `${percent}%`, backgroundColor: boxColors[boxNum] },
                  ]}
                />
              </View>
              {count > 0 && nextDates[boxNum] && (
                <Text style={styles.boxDate}>
                  Prochaine ouverture : {formatReviewDate(nextDates[boxNum])}
                </Text>
              )}
            </View>
          );
        })}
      </View>

      <Text style={styles.sectionTitle}>Progression (7 derniers jours)</Text>
      <View style={styles.card}>
        <SimpleBarChart
          items={dailyStats.map((d) => {
            const total = d.success + d.fail;
            const rate = total > 0 ? d.success / total : 0;
            const color =
              total === 0
                ? theme.border
                : rate >= 0.8
                ? theme.success
                : rate >= 0.5
                ? theme.warningLabel
                : theme.danger;
            return { label: formatShortDay(d.date), value: total, color };
          })}
          emptyLabel="Aucune révision sur les 7 derniers jours."
        />
      </View>

      <Text style={styles.sectionTitle}>Planning des 7 prochains jours</Text>
      <View style={styles.card}>
        <SimpleBarChart
          items={upcoming.map((u) => ({ label: formatShortDay(u.date), value: u.count }))}
          defaultColor={theme.accentText}
          emptyLabel="Rien de prévu pour les prochains jours."
        />
      </View>

      <Text style={styles.sectionTitle}>Par matière</Text>
      <View style={styles.card}>
        {subjects.map((s) => (
          <View key={s.id} style={styles.subjectRow}>
            <View style={[styles.subjectDot, { backgroundColor: s.color }]} />
            <Text style={styles.subjectName}>{s.name}</Text>
            <Text style={styles.subjectCount}>{s.cardCount}</Text>
          </View>
        ))}
        {subjects.length === 0 && (
          <Text style={styles.empty}>Aucune matière pour le moment.</Text>
        )}
      </View>
    </ScrollView>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: c.background },
    summaryCard: {
      backgroundColor: c.accent,
      borderRadius: 16,
      padding: 24,
      alignItems: 'center',
      marginBottom: 24,
    },
    summaryNumber: { fontSize: 40, fontWeight: '800', color: c.onAccent },
    summaryLabel: { fontSize: 13, color: c.onAccent, opacity: 0.85, textAlign: 'center', marginTop: 6 },
    sectionTitle: {
      fontSize: 13,
      fontWeight: '700',
      color: c.textMuted,
      textTransform: 'uppercase',
      marginBottom: 8,
    },
    card: {
      backgroundColor: c.surface,
      borderRadius: 12,
      padding: 16,
      marginBottom: 24,
      elevation: 1,
    },
    boxRow: { marginBottom: 14 },
    boxRowHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
    boxLabel: { fontSize: 13, color: c.text, fontWeight: '500' },
    boxValue: { fontSize: 13, color: c.text, fontWeight: '700' },
    barTrack: {
      height: 8,
      backgroundColor: c.surfaceAlt,
      borderRadius: 4,
      overflow: 'hidden',
    },
    barFill: { height: '100%', borderRadius: 4 },
    boxDate: { fontSize: 11, color: c.textFaint, marginTop: 4 },
    subjectRow: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 10,
      borderBottomWidth: 1,
      borderBottomColor: c.surfaceAlt,
    },
    subjectDot: { width: 10, height: 10, borderRadius: 5, marginRight: 10 },
    subjectName: { flex: 1, fontSize: 14, color: c.text },
    subjectCount: { fontSize: 14, color: c.textMuted, fontWeight: '600' },
    empty: { textAlign: 'center', color: c.textMuted, paddingVertical: 12 },
  });
}
