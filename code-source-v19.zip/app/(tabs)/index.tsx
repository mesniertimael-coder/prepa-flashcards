import { useMemo, useState, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import {
  getAllSubjects,
  getCardCountsBySubject,
  createSubject,
} from '../../src/db/queries/subjects';
import { Subject } from '../../src/types/models';
import { useTheme } from '../../src/theme/useTheme';
import { ThemeColors } from '../../src/theme/colors';
import { haptics } from '../../src/utils/haptics';

interface SubjectWithCount extends Subject {
  cardCount: number;
}

type SortMode = 'name' | 'count' | 'recent';

const SORT_LABELS: Record<SortMode, string> = {
  name: 'Nom',
  count: 'Nb de cartes',
  recent: 'Récentes',
};

const COLOR_PALETTE = [
  '#4F46E5', '#0EA5E9', '#10B981', '#F59E0B',
  '#EF4444', '#8B5CF6', '#EC4899', '#14B8A6',
];

export default function SubjectsScreen() {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);

  const [subjects, setSubjects] = useState<SubjectWithCount[]>([]);
  const [sortMode, setSortMode] = useState<SortMode>('name');
  const [modalVisible, setModalVisible] = useState(false);
  const [actionMenuVisible, setActionMenuVisible] = useState(false);
  const [newName, setNewName] = useState('');
  const [newColor, setNewColor] = useState(COLOR_PALETTE[0]);
  const [saving, setSaving] = useState(false);
  const router = useRouter();

  const load = useCallback(async () => {
    const [data, counts] = await Promise.all([getAllSubjects(), getCardCountsBySubject()]);
    const withCounts = data.map((s) => ({
      ...s,
      cardCount: counts[s.id] ?? 0,
    }));
    setSubjects(withCounts);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const sortedSubjects = useMemo(() => {
    const list = [...subjects];
    switch (sortMode) {
      case 'count':
        return list.sort((a, b) => b.cardCount - a.cardCount);
      case 'recent':
        return list.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
      case 'name':
      default:
        return list.sort((a, b) => a.name.localeCompare(b.name));
    }
  }, [subjects, sortMode]);

  const cycleSortMode = () => {
    haptics.selection();
    setSortMode((prev) => {
      if (prev === 'name') return 'count';
      if (prev === 'count') return 'recent';
      return 'name';
    });
  };

  const openAddModal = () => {
    setNewName('');
    setNewColor(COLOR_PALETTE[Math.floor(Math.random() * COLOR_PALETTE.length)]);
    setModalVisible(true);
  };

  const handleCreateSubject = async () => {
    if (!newName.trim()) {
      Alert.alert('Nom requis', 'Donne un nom à la matière.');
      return;
    }
    try {
      setSaving(true);
      await createSubject(newName, newColor);
      haptics.success();
      setModalVisible(false);
      load();
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', 'Cette matière existe peut-être déjà.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={sortedSubjects}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 16, paddingBottom: 110 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.card, { borderLeftColor: item.color }]}
            onPress={() => router.push(`/subject/${item.id}`)}
          >
            <Text style={styles.cardTitle}>{item.name}</Text>
            <Text style={styles.cardCount}>
              {item.cardCount} carte{item.cardCount !== 1 ? 's' : ''}
            </Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <Text style={styles.empty}>Aucune matière pour le moment.</Text>
        }
        ListHeaderComponent={
          <View>
            <TouchableOpacity style={styles.addSubjectButton} onPress={openAddModal}>
              <Text style={styles.addSubjectButtonText}>+ Ajouter une matière</Text>
            </TouchableOpacity>
            {subjects.length > 1 && (
              <TouchableOpacity style={styles.sortButton} onPress={cycleSortMode}>
                <Text style={styles.sortButtonText}>
                  ↕️ Trier par : {SORT_LABELS[sortMode]}
                </Text>
              </TouchableOpacity>
            )}
          </View>
        }
      />

      <View style={styles.fabRow}>
        <TouchableOpacity style={styles.fab} onPress={() => setActionMenuVisible(true)}>
          <Text style={styles.fabText}>+ Nouvelle carte</Text>
        </TouchableOpacity>
      </View>

      <Modal visible={actionMenuVisible} animationType="fade" transparent>
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setActionMenuVisible(false)}
        >
          <View style={styles.actionMenuBox}>
            <TouchableOpacity
              style={styles.actionMenuItem}
              onPress={() => {
                setActionMenuVisible(false);
                router.push('/card/create');
              }}
            >
              <Text style={styles.actionMenuIcon}>✏️</Text>
              <View style={styles.actionMenuTextBlock}>
                <Text style={styles.actionMenuTitle}>Saisir manuellement</Text>
                <Text style={styles.actionMenuSubtitle}>Écrire une question/réponse toi-même</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionMenuItem}
              onPress={() => {
                setActionMenuVisible(false);
                router.push('/card/ocr-capture');
              }}
            >
              <Text style={styles.actionMenuIcon}>📷</Text>
              <View style={styles.actionMenuTextBlock}>
                <Text style={styles.actionMenuTitle}>Scanner une photo</Text>
                <Text style={styles.actionMenuSubtitle}>Cours manuscrit ou imprimé</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionMenuItem}
              onPress={() => {
                setActionMenuVisible(false);
                router.push('/card/voice-create');
              }}
            >
              <Text style={styles.actionMenuIcon}>🎙️</Text>
              <View style={styles.actionMenuTextBlock}>
                <Text style={styles.actionMenuTitle}>Créer par la voix</Text>
                <Text style={styles.actionMenuSubtitle}>Dicter la question et la réponse</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionMenuItem}
              onPress={() => {
                setActionMenuVisible(false);
                router.push('/card/import-document');
              }}
            >
              <Text style={styles.actionMenuIcon}>📄</Text>
              <View style={styles.actionMenuTextBlock}>
                <Text style={styles.actionMenuTitle}>Importer un document</Text>
                <Text style={styles.actionMenuSubtitle}>Fichier PDF, Word ou texte</Text>
              </View>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Nouvelle matière</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Ex : SVT"
              placeholderTextColor={theme.textFaint}
              value={newName}
              onChangeText={setNewName}
              autoFocus
            />
            <Text style={styles.modalLabel}>Couleur</Text>
            <View style={styles.colorRow}>
              {COLOR_PALETTE.map((c) => (
                <TouchableOpacity
                  key={c}
                  style={[
                    styles.colorSwatch,
                    { backgroundColor: c },
                    newColor === c && styles.colorSwatchSelected,
                  ]}
                  onPress={() => setNewColor(c)}
                />
              ))}
            </View>
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.modalCancelText}>Annuler</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalSaveButton, saving && { opacity: 0.6 }]}
                onPress={handleCreateSubject}
                disabled={saving}
              >
                <Text style={styles.modalSaveText}>Créer</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: c.background },
    card: {
      backgroundColor: c.surface,
      borderRadius: 10,
      padding: 16,
      marginBottom: 10,
      borderLeftWidth: 5,
      elevation: 1,
    },
    cardTitle: { fontSize: 16, fontWeight: '600', color: c.text },
    cardCount: { fontSize: 13, color: c.textMuted, marginTop: 4 },
    empty: { textAlign: 'center', marginTop: 40, color: c.textMuted },
    addSubjectButton: {
      borderWidth: 1.5,
      borderColor: c.accent,
      borderStyle: 'dashed',
      borderRadius: 10,
      padding: 14,
      alignItems: 'center',
      marginBottom: 10,
    },
    addSubjectButtonText: { color: c.accentText, fontWeight: '600' },
    sortButton: { alignSelf: 'flex-end', paddingVertical: 6, marginBottom: 8 },
    sortButtonText: { color: c.textMuted, fontSize: 12, fontWeight: '600' },
    fabRow: {
      position: 'absolute',
      bottom: 24,
      right: 24,
      left: 24,
      flexDirection: 'row',
      justifyContent: 'flex-end',
    },
    fab: {
      backgroundColor: c.accent,
      paddingHorizontal: 20,
      paddingVertical: 14,
      borderRadius: 30,
      elevation: 3,
      marginLeft: 10,
    },
    fabText: { color: c.onAccent, fontWeight: '600' },
    actionMenuBox: {
      position: 'absolute',
      bottom: 90,
      right: 24,
      left: 24,
      backgroundColor: c.surface,
      borderRadius: 16,
      paddingVertical: 8,
      elevation: 6,
    },
    actionMenuItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 14,
      paddingHorizontal: 16,
    },
    actionMenuIcon: { fontSize: 24, marginRight: 14 },
    actionMenuTextBlock: { flex: 1 },
    actionMenuTitle: { fontSize: 15, fontWeight: '600', color: c.text },
    actionMenuSubtitle: { fontSize: 12, color: c.textMuted, marginTop: 2 },
    modalOverlay: {
      flex: 1,
      backgroundColor: c.overlay,
      justifyContent: 'flex-end',
    },
    modalBox: {
      backgroundColor: c.surface,
      borderTopLeftRadius: 20,
      borderTopRightRadius: 20,
      padding: 24,
    },
    modalTitle: { fontSize: 18, fontWeight: '700', color: c.text, marginBottom: 16 },
    modalInput: {
      borderWidth: 1,
      borderColor: c.border,
      borderRadius: 10,
      padding: 12,
      fontSize: 15,
      marginBottom: 16,
      color: c.text,
      backgroundColor: c.surfaceAlt,
    },
    modalLabel: { fontSize: 13, fontWeight: '600', color: c.textMuted, marginBottom: 10 },
    colorRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 24 },
    colorSwatch: {
      width: 36,
      height: 36,
      borderRadius: 18,
      marginRight: 10,
      marginBottom: 10,
    },
    colorSwatchSelected: { borderWidth: 3, borderColor: c.text },
    modalActions: { flexDirection: 'row', justifyContent: 'flex-end' },
    modalCancelButton: { paddingVertical: 12, paddingHorizontal: 16 },
    modalCancelText: { color: c.textMuted, fontWeight: '600' },
    modalSaveButton: {
      backgroundColor: c.accent,
      borderRadius: 10,
      paddingVertical: 12,
      paddingHorizontal: 20,
    },
    modalSaveText: { color: c.onAccent, fontWeight: '700' },
  });
}
