import { useCallback, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { getDueCards } from '../../src/db/queries/cards';
import { getAllSubjects } from '../../src/db/queries/subjects';
import { applyReviewResult } from '../../src/db/queries/leitner';
import { Flashcard, Subject } from '../../src/types/models';
import { BOX_LABELS } from '../../src/constants/leitner';
import MathText from '../../src/components/MathText';
import SubjectFilterBar from '../../src/components/SubjectFilterBar';
import { shuffleArray } from '../../src/utils/shuffle';
import { getSetting } from '../../src/db/queries/settings';
import { useTheme } from '../../src/theme/useTheme';
import { ThemeColors } from '../../src/theme/colors';
import { haptics } from '../../src/utils/haptics';

interface SessionStats {
  success: number;
  fail: number;
  total: number;
}

export default function RevisionScreen() {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [dueCountsBySubject, setDueCountsBySubject] = useState<Record<number, number>>({});
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);
  const [queue, setQueue] = useState<Flashcard[]>([]);
  const [showAnswer, setShowAnswer] = useState(false);
  const [sessionStats, setSessionStats] = useState<SessionStats>({
    success: 0,
    fail: 0,
    total: 0,
  });
  const [finished, setFinished] = useState(false);

  const loadDueCards = useCallback(async (subjectId: number | null) => {
    setLoading(true);
    const allSubjects = await getAllSubjects();
    setSubjects(allSubjects);

    // Compte les cartes dues par matière pour afficher un badge sur chaque filtre
    const allDue = await getDueCards();
    const counts: Record<number, number> = {};
    for (const c of allDue) {
      counts[c.subjectId] = (counts[c.subjectId] ?? 0) + 1;
    }
    setDueCountsBySubject(counts);

    const cards = subjectId
      ? allDue.filter((c) => c.subjectId === subjectId)
      : allDue;

    const randomSetting = await getSetting('random_review_order');
    const isRandom = randomSetting !== 'false'; // activé par défaut
    const finalCards = isRandom ? shuffleArray(cards) : cards;

    setQueue(finalCards);
    setSessionStats({ success: 0, fail: 0, total: finalCards.length });
    setFinished(finalCards.length === 0);
    setShowAnswer(false);
    setLoading(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadDueCards(selectedSubjectId);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedSubjectId])
  );

  const currentCard = queue[0];
  const totalDue = Object.values(dueCountsBySubject).reduce((a, b) => a + b, 0);

  const handleAnswer = async (wasSuccess: boolean) => {
    if (!currentCard) return;

    await applyReviewResult(currentCard.id, wasSuccess);
    wasSuccess ? haptics.success() : haptics.failure();

    setSessionStats((s) => ({
      ...s,
      success: s.success + (wasSuccess ? 1 : 0),
      fail: s.fail + (wasSuccess ? 0 : 1),
    }));

    const remaining = queue.slice(1);
    setQueue(remaining);
    setShowAnswer(false);
    if (remaining.length === 0) setFinished(true);
  };

  const SubjectFilter = (
    <View style={styles.filterWrapper}>
      <SubjectFilterBar
        subjects={subjects}
        selectedSubjectId={selectedSubjectId}
        onSelect={(id) => {
          haptics.selection();
          setSelectedSubjectId(id);
        }}
        countsBySubject={dueCountsBySubject}
        totalCount={totalDue}
      />
      <TouchableOpacity
        style={styles.trainLink}
        onPress={() =>
          router.push(
            selectedSubjectId
              ? `/train?subjectId=${selectedSubjectId}`
              : '/train'
          )
        }
      >
        <Text style={styles.trainLinkText}>
          🎯 Mode entraînement libre (illimité, sans effet sur les boîtes)
        </Text>
      </TouchableOpacity>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={theme.accent} />
      </View>
    );
  }

  if (finished) {
    const { success, fail, total } = sessionStats;
    return (
      <View style={styles.container}>
        {SubjectFilter}
        <View style={styles.center}>
          <Text style={styles.finishedTitle}>
            {total === 0 ? "Rien à réviser ici aujourd'hui 🎉" : 'Session terminée 🎉'}
          </Text>
          {total > 0 && (
            <Text style={styles.finishedStats}>
              {success} réussie{success > 1 ? 's' : ''} · {fail} échouée
              {fail > 1 ? 's' : ''} sur {total}
            </Text>
          )}
          <TouchableOpacity
            style={styles.reloadButton}
            onPress={() => loadDueCards(selectedSubjectId)}
          >
            <Text style={styles.reloadButtonText}>Actualiser</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const progress = sessionStats.total - queue.length + 1;

  return (
    <View style={styles.container}>
      {SubjectFilter}

      <ScrollView
        style={styles.sessionScroll}
        contentContainerStyle={styles.sessionArea}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={styles.progress}>
          Carte {progress} / {sessionStats.total}
        </Text>
        <Text style={styles.boxTag}>{BOX_LABELS[currentCard.box]}</Text>

        <View style={styles.card}>
          <Text style={styles.cardLabel}>Question</Text>
          <MathText content={currentCard.question} fontSize={18} color={theme.text} />

          {showAnswer && (
            <>
              <View style={styles.divider} />
              <Text style={styles.cardLabel}>Réponse</Text>
              <MathText content={currentCard.answer} fontSize={18} color={theme.text} />

              {currentCard.notes && (
                <View style={styles.notesBox}>
                  <Text style={styles.notesLabel}>📝 Note</Text>
                  <Text style={styles.notesText}>{currentCard.notes}</Text>
                </View>
              )}
            </>
          )}
        </View>

        {!showAnswer ? (
          <TouchableOpacity
            style={styles.revealButton}
            onPress={() => setShowAnswer(true)}
          >
            <Text style={styles.revealButtonText}>Afficher la réponse</Text>
          </TouchableOpacity>
        ) : (
          <View style={styles.answerButtons}>
            <TouchableOpacity
              style={[styles.answerButton, styles.failButton]}
              onPress={() => handleAnswer(false)}
            >
              <Text style={styles.answerButtonText}>❌ Échoué</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.answerButton, styles.successButton]}
              onPress={() => handleAnswer(true)}
            >
              <Text style={styles.answerButtonText}>✅ Réussi</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: c.background },
    sessionScroll: { flex: 1 },
    sessionArea: { padding: 20, paddingBottom: 40, flexGrow: 1 },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24, backgroundColor: c.background },
    filterWrapper: { paddingBottom: 4 },
    trainLink: { paddingHorizontal: 16, paddingTop: 6, paddingBottom: 2 },
    trainLinkText: { fontSize: 12, color: c.accentText, fontWeight: '600' },
    progress: { textAlign: 'center', color: c.textMuted, fontSize: 13, marginBottom: 4 },
    boxTag: {
      textAlign: 'center',
      color: c.accentText,
      fontSize: 12,
      fontWeight: '700',
      marginBottom: 16,
    },
    card: {
      backgroundColor: c.surface,
      borderRadius: 16,
      padding: 24,
      minHeight: 180,
      justifyContent: 'center',
      elevation: 2,
      marginBottom: 24,
    },
    cardLabel: {
      fontSize: 12,
      fontWeight: '700',
      color: c.textFaint,
      marginBottom: 8,
      textTransform: 'uppercase',
    },
    divider: { height: 1, backgroundColor: c.border, marginVertical: 20 },
    notesBox: {
      backgroundColor: c.warningSoft,
      borderRadius: 10,
      padding: 12,
      marginTop: 16,
      borderWidth: 1,
      borderColor: c.warningBorder,
    },
    notesLabel: { fontSize: 11, fontWeight: '700', color: c.warningLabel, marginBottom: 4 },
    notesText: { fontSize: 14, color: c.warningText },
    revealButton: {
      backgroundColor: c.text,
      borderRadius: 12,
      padding: 16,
      alignItems: 'center',
    },
    revealButtonText: { color: c.background, fontWeight: '700', fontSize: 15 },
    answerButtons: { flexDirection: 'row', marginHorizontal: -6 },
    answerButton: {
      flex: 1,
      borderRadius: 12,
      padding: 16,
      alignItems: 'center',
      marginHorizontal: 6,
    },
    failButton: { backgroundColor: c.dangerSoft },
    successButton: { backgroundColor: c.successSoft },
    answerButtonText: { fontWeight: '700', fontSize: 15, color: c.text },
    finishedTitle: {
      fontSize: 20,
      fontWeight: '700',
      color: c.text,
      marginBottom: 12,
      textAlign: 'center',
    },
    finishedStats: { fontSize: 15, color: c.textMuted, marginBottom: 24 },
    reloadButton: {
      backgroundColor: c.accent,
      borderRadius: 10,
      paddingHorizontal: 24,
      paddingVertical: 12,
    },
    reloadButtonText: { color: c.onAccent, fontWeight: '600' },
  });
}
