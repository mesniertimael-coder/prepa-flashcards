import { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useFocusEffect, useLocalSearchParams } from 'expo-router';
import { getCardsBySubject, getAllCards } from '../../src/db/queries/cards';
import { getAllSubjects } from '../../src/db/queries/subjects';
import { Flashcard, Subject } from '../../src/types/models';
import { shuffleArray, shuffleByWeakness } from '../../src/utils/shuffle';
import { getSetting, setSetting } from '../../src/db/queries/settings';
import MathText from '../../src/components/MathText';
import SubjectFilterBar from '../../src/components/SubjectFilterBar';
import { useTheme } from '../../src/theme/useTheme';
import { ThemeColors } from '../../src/theme/colors';
import { haptics } from '../../src/utils/haptics';

/**
 * Mode entraînement libre : cartes mélangées, à l'infini, sans jamais
 * toucher aux boîtes de Leitner ni à la date de prochaine révision.
 * Purement pour du bachotage / mémorisation à la demande.
 *
 * Cet écran est un onglet à part entière (et non plus un écran empilé sur
 * la pile de navigation) : le va-et-vient entre Révision et Entraînement se
 * faisait auparavant via router.push()/back() sur la pile racine, ce qui a
 * introduit le blocage de la liste horizontale de matières après un aller-
 * retour (l'écran de Révision se met en veille/reprend et son ScrollView/
 * FlatList récupère alors des dimensions obsolètes). En restant dans le
 * même navigateur d'onglets, on évite complètement ce cycle.
 */
export default function TrainScreen() {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const { subjectId: subjectIdParam } = useLocalSearchParams<{ subjectId?: string }>();

  const [initialized, setInitialized] = useState(false);
  const [loading, setLoading] = useState(true);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);
  const [allCards, setAllCards] = useState<Flashcard[]>([]);
  const [queue, setQueue] = useState<Flashcard[]>([]);
  const [showAnswer, setShowAnswer] = useState(false);
  const [seenCount, setSeenCount] = useState(0);
  const [lap, setLap] = useState(1);
  const [prioritizeWeak, setPrioritizeWeak] = useState(false);

  // Prend en compte le paramètre ?subjectId=... reçu depuis un lien externe
  // (Révision, fiche matière) une seule fois, sans écraser un choix fait
  // ensuite directement dans cet onglet.
  useEffect(() => {
    (async () => {
      if (!initialized && subjectIdParam) {
        setSelectedSubjectId(Number(subjectIdParam));
      }
      const saved = await getSetting('train_prioritize_weak');
      setPrioritizeWeak(saved === 'true');
      setInitialized(true);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subjectIdParam]);

  const togglePrioritizeWeak = () => {
    haptics.selection();
    setPrioritizeWeak((prev) => {
      const next = !prev;
      setSetting('train_prioritize_weak', next ? 'true' : 'false');
      setQueue((q) => (next ? shuffleByWeakness(q) : shuffleArray(q)));
      return next;
    });
  };

  const loadCards = useCallback(async (subjectId: number | null, weak: boolean) => {
    setLoading(true);
    const allSubjects = await getAllSubjects();
    setSubjects(allSubjects);

    const cards = subjectId ? await getCardsBySubject(subjectId) : await getAllCards();
    setAllCards(cards);
    setQueue(weak ? shuffleByWeakness(cards) : shuffleArray(cards));
    setSeenCount(0);
    setLap(1);
    setShowAnswer(false);
    setLoading(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (initialized) loadCards(selectedSubjectId, prioritizeWeak);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [initialized, selectedSubjectId])
  );

  const currentCard = queue[0];
  const selectedSubjectName = subjects.find((s) => s.id === selectedSubjectId)?.name ?? null;

  const handleNext = () => {
    haptics.tap();
    setSeenCount((c) => c + 1);
    const remaining = queue.slice(1);
    if (remaining.length === 0) {
      // Fin d'un tour : on remélange et on recommence, à l'infini
      setQueue(prioritizeWeak ? shuffleByWeakness(allCards) : shuffleArray(allCards));
      setLap((l) => l + 1);
    } else {
      setQueue(remaining);
    }
    setShowAnswer(false);
  };

  const SubjectFilter = (
    <View>
      <SubjectFilterBar
        subjects={subjects}
        selectedSubjectId={selectedSubjectId}
        onSelect={(id) => {
          haptics.selection();
          setSelectedSubjectId(id);
        }}
      />
      <TouchableOpacity style={styles.priorityToggle} onPress={togglePrioritizeWeak}>
        <Text style={[styles.priorityToggleText, prioritizeWeak && styles.priorityToggleTextActive]}>
          {prioritizeWeak ? '🔥 Cartes fragiles en priorité' : '🔀 Ordre : aléatoire'}
        </Text>
      </TouchableOpacity>
    </View>
  );

  if (!initialized || loading) {
    return (
      <View style={styles.container}>
        {SubjectFilter}
        <View style={styles.center}>
          <ActivityIndicator size="large" color={theme.accent} />
        </View>
      </View>
    );
  }

  if (allCards.length === 0) {
    return (
      <View style={styles.container}>
        {SubjectFilter}
        <View style={styles.center}>
          <Text style={styles.emptyText}>
            {selectedSubjectName
              ? `Aucune carte dans ${selectedSubjectName}.`
              : 'Aucune carte pour le moment.'}
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {SubjectFilter}

      <View style={styles.header}>
        <Text style={styles.headerText}>
          Tour {lap} · {seenCount} carte{seenCount !== 1 ? 's' : ''} vue{seenCount !== 1 ? 's' : ''}
        </Text>
      </View>

      <View style={styles.cardArea}>
        <View style={styles.card}>
          <Text style={styles.cardLabel}>Question</Text>
          <MathText content={currentCard.question} fontSize={18} color={theme.text} />

          {showAnswer && (
            <>
              <View style={styles.divider} />
              <Text style={styles.cardLabel}>Réponse</Text>
              <MathText content={currentCard.answer} fontSize={18} color={theme.text} />

              {currentCard.notes && (
                <View style={styles.notesBox}>
                  <Text style={styles.notesLabel}>📝 Note</Text>
                  <Text style={styles.notesText}>{currentCard.notes}</Text>
                </View>
              )}
            </>
          )}
        </View>

        {!showAnswer ? (
          <TouchableOpacity style={styles.revealButton} onPress={() => { haptics.tap(); setShowAnswer(true); }}>
            <Text style={styles.revealButtonText}>Afficher la réponse</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
            <Text style={styles.nextButtonText}>Carte suivante →</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: c.background },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
    emptyText: { color: c.textMuted, fontSize: 14, textAlign: 'center' },
    header: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 4 },
    headerText: { textAlign: 'center', color: c.textMuted, fontSize: 13, fontWeight: '600' },
    priorityToggle: { paddingHorizontal: 16, paddingBottom: 8 },
    priorityToggleText: { fontSize: 12, color: c.textMuted, fontWeight: '600' },
    priorityToggleTextActive: { color: c.warningLabel },
    cardArea: { flex: 1, padding: 20, justifyContent: 'center' },
    card: {
      backgroundColor: c.surface,
      borderRadius: 16,
      padding: 24,
      minHeight: 200,
      justifyContent: 'center',
      elevation: 2,
      marginBottom: 24,
    },
    cardLabel: {
      fontSize: 12,
      fontWeight: '700',
      color: c.textFaint,
      marginBottom: 8,
      textTransform: 'uppercase',
    },
    divider: { height: 1, backgroundColor: c.border, marginVertical: 20 },
    notesBox: {
      backgroundColor: c.warningSoft,
      borderRadius: 10,
      padding: 12,
      marginTop: 16,
      borderWidth: 1,
      borderColor: c.warningBorder,
    },
    notesLabel: { fontSize: 11, fontWeight: '700', color: c.warningLabel, marginBottom: 4 },
    notesText: { fontSize: 14, color: c.warningText },
    revealButton: {
      backgroundColor: c.text,
      borderRadius: 12,
      padding: 16,
      alignItems: 'center',
    },
    revealButtonText: { color: c.background, fontWeight: '700', fontSize: 15 },
    nextButton: {
      backgroundColor: c.accent,
      borderRadius: 12,
      padding: 16,
      alignItems: 'center',
    },
    nextButtonText: { color: c.onAccent, fontWeight: '700', fontSize: 15 },
  });
}
