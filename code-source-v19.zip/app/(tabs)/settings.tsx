import { useCallback, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Switch,
  Alert,
  ScrollView,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { exportBackup } from '../../src/services/backup';
import {
  isDailyReminderEnabled,
  scheduleDailyReminder,
  cancelDailyReminder,
} from '../../src/services/notifications';
import { getSetting, setSetting } from '../../src/db/queries/settings';
import { useTheme } from '../../src/theme/useTheme';
import { ThemeColors } from '../../src/theme/colors';
import { haptics } from '../../src/utils/haptics';

const HOUR_OPTIONS = [7, 8, 12, 17, 18, 19, 20, 21];

export default function SettingsScreen() {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const router = useRouter();
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [reminderHour, setReminderHour] = useState(18);
  const [exporting, setExporting] = useState(false);
  const [togglingReminder, setTogglingReminder] = useState(false);
  const [randomOrder, setRandomOrder] = useState(true);

  const load = useCallback(async () => {
    const { enabled, hour } = await isDailyReminderEnabled();
    setReminderEnabled(enabled);
    setReminderHour(hour);
    const randomSetting = await getSetting('random_review_order');
    setRandomOrder(randomSetting !== 'false');
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleToggleReminder = async (value: boolean) => {
    haptics.selection();
    try {
      setTogglingReminder(true);
      if (value) {
        await scheduleDailyReminder(reminderHour, 0);
      } else {
        await cancelDailyReminder();
      }
      setReminderEnabled(value);
    } catch (err: any) {
      Alert.alert('Erreur', err?.message ?? 'Impossible de modifier le rappel.');
    } finally {
      setTogglingReminder(false);
    }
  };

  const handleChangeHour = async (hour: number) => {
    haptics.selection();
    setReminderHour(hour);
    if (reminderEnabled) {
      await scheduleDailyReminder(hour, 0);
    }
  };

  const handleToggleRandomOrder = async (value: boolean) => {
    haptics.selection();
    setRandomOrder(value);
    await setSetting('random_review_order', value ? 'true' : 'false');
  };

  const handleExport = async () => {
    try {
      setExporting(true);
      await exportBackup();
      haptics.success();
    } catch (err: any) {
      Alert.alert('Erreur', err?.message ?? "L'export a échoué.");
    } finally {
      setExporting(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.sectionTitle}>Rappel quotidien</Text>
      <View style={styles.card}>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>Activer le rappel</Text>
          <Switch
            value={reminderEnabled}
            onValueChange={handleToggleReminder}
            disabled={togglingReminder}
            trackColor={{ true: theme.accent, false: theme.border }}
          />
        </View>

        {reminderEnabled && (
          <>
            <Text style={styles.subLabel}>Heure du rappel</Text>
            <View style={styles.hourRow}>
              {HOUR_OPTIONS.map((h) => (
                <TouchableOpacity
                  key={h}
                  style={[styles.hourChip, reminderHour === h && styles.hourChipActive]}
                  onPress={() => handleChangeHour(h)}
                >
                  <Text
                    style={[
                      styles.hourChipText,
                      reminderHour === h && styles.hourChipTextActive,
                    ]}
                  >
                    {h}h
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}
      </View>

      <Text style={styles.sectionTitle}>Révision</Text>
      <View style={styles.card}>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>Ordre aléatoire des cartes</Text>
          <Switch
            value={randomOrder}
            onValueChange={handleToggleRandomOrder}
            trackColor={{ true: theme.accent, false: theme.border }}
          />
        </View>
        <Text style={styles.helperTextSmall}>
          Si désactivé, les cartes apparaissent triées par boîte (les plus en
          retard en premier).
        </Text>
      </View>

      <Text style={styles.sectionTitle}>Apparence</Text>
      <View style={styles.card}>
        <Text style={styles.helperTextSmall}>
          L'application suit automatiquement le mode clair/sombre réglé sur ton
          téléphone (Réglages système).
        </Text>
      </View>

      <Text style={styles.sectionTitle}>Partage entre amis</Text>
      <View style={styles.card}>
        <Text style={styles.helperText}>
          Envoie tes cartes d'une ou plusieurs matières à quelqu'un, ou importe
          celles qu'on t'a partagées — tu choisis ensuite dans quelle matière
          les ranger.
        </Text>
        <TouchableOpacity
          style={styles.exportButton}
          onPress={() => router.push('/share/export')}
        >
          <Text style={styles.exportButtonText}>📤 Partager des cartes</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.exportButton, styles.secondaryButton]}
          onPress={() => router.push('/share/import')}
        >
          <Text style={[styles.exportButtonText, styles.secondaryButtonText]}>
            📥 Importer des cartes reçues
          </Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.sectionTitle}>Sauvegarde</Text>
      <View style={styles.card}>
        <Text style={styles.helperText}>
          Exporte toutes tes matières, cartes et leur progression dans un fichier
          que tu peux enregistrer sur Google Drive, t'envoyer par mail, etc.
          Utile avant de changer de téléphone ou de réinstaller l'app.
        </Text>
        <TouchableOpacity
          style={[styles.exportButton, exporting && { opacity: 0.6 }]}
          onPress={handleExport}
          disabled={exporting}
        >
          <Text style={styles.exportButtonText}>
            {exporting ? 'Export en cours…' : '⬇️ Exporter mes données'}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: c.background },
    sectionTitle: {
      fontSize: 13,
      fontWeight: '700',
      color: c.textMuted,
      textTransform: 'uppercase',
      marginBottom: 8,
      marginTop: 8,
    },
    card: {
      backgroundColor: c.surface,
      borderRadius: 12,
      padding: 16,
      marginBottom: 24,
      elevation: 1,
    },
    row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    rowLabel: { fontSize: 15, color: c.text, fontWeight: '500' },
    subLabel: { fontSize: 13, color: c.textMuted, marginTop: 16, marginBottom: 10 },
    hourRow: { flexDirection: 'row', flexWrap: 'wrap' },
    hourChip: {
      borderWidth: 1,
      borderColor: c.border,
      borderRadius: 16,
      paddingHorizontal: 12,
      paddingVertical: 6,
      marginRight: 8,
      marginBottom: 8,
    },
    hourChipActive: { backgroundColor: c.accent, borderColor: c.accent },
    hourChipText: { fontSize: 13, color: c.text },
    hourChipTextActive: { color: c.onAccent, fontWeight: '600' },
    helperText: { fontSize: 13, color: c.textMuted, lineHeight: 19, marginBottom: 16 },
    helperTextSmall: { fontSize: 12, color: c.textFaint, marginTop: 8, lineHeight: 17 },
    exportButton: {
      backgroundColor: c.accent,
      borderRadius: 10,
      padding: 14,
      alignItems: 'center',
    },
    exportButtonText: { color: c.onAccent, fontWeight: '700' },
    secondaryButton: {
      backgroundColor: c.surface,
      borderWidth: 1.5,
      borderColor: c.accent,
      marginTop: 10,
    },
    secondaryButtonText: { color: c.accentText },
  });
}
