import { useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImageManipulator from 'expo-image-manipulator';
import { useRouter, Stack } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { recognizeTextFromImage } from '../../src/services/ocr';
import { useTheme } from '../../src/theme/useTheme';

type Phase = 'camera' | 'preview' | 'processing';

export default function OcrCaptureScreen() {
  const theme = useTheme();
  const [permission, requestPermission] = useCameraPermissions();
  const [phase, setPhase] = useState<Phase>('camera');
  const [flashOn, setFlashOn] = useState(false);
  const [zoom, setZoom] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [previewUri, setPreviewUri] = useState<string | null>(null);
  const [pages, setPages] = useState<string[]>([]); // texte accumulé des pages déjà scannées
  const cameraRef = useRef<CameraView>(null);
  const router = useRouter();

  if (!permission) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <ActivityIndicator color={theme.accent} />
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={[styles.center, { backgroundColor: theme.background }]}>
        <Text style={[styles.permissionText, { color: theme.text }]}>
          L'accès à l'appareil photo est nécessaire pour scanner tes cours.
        </Text>
        <TouchableOpacity style={styles.permissionButton} onPress={requestPermission}>
          <Text style={styles.permissionButtonText}>Autoriser la caméra</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const handleShutterPress = async () => {
    if (!cameraRef.current) return;
    try {
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.9 });
      if (!photo?.uri) throw new Error('Capture échouée');
      setRotation(0);
      setPreviewUri(photo.uri);
      setPhase('preview');
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', 'La capture a échoué. Réessaie.');
    }
  };

  const handleRetake = () => {
    setPreviewUri(null);
    setPhase('camera');
  };

  const runOcrOnPreview = async (): Promise<string | null> => {
    if (!previewUri) return null;

    const actions: any[] = [];
    if (rotation !== 0) actions.push({ rotate: rotation });
    // Redimensionnement : garde une bonne résolution pour la précision OCR
    // tout en restant raisonnable en taille de fichier.
    actions.push({ resize: { width: 1900 } });

    const manipulated = await ImageManipulator.manipulateAsync(previewUri, actions, {
      compress: 0.85,
      format: ImageManipulator.SaveFormat.JPEG,
    });

    const { text } = await recognizeTextFromImage(manipulated.uri);
    return text;
  };

  const handleAddAnotherPage = async () => {
    try {
      setPhase('processing');
      const text = await runOcrOnPreview();
      if (!text) {
        Alert.alert(
          'Aucun texte détecté sur cette page',
          'Cette page ne sera pas ajoutée. Tu peux réessayer ou continuer avec les pages déjà scannées.',
          [{ text: 'OK', onPress: () => { setPreviewUri(null); setPhase('camera'); } }]
        );
        return;
      }
      setPages((prev) => [...prev, text]);
      setPreviewUri(null);
      setPhase('camera');
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', "L'analyse de cette page a échoué. Réessaie.");
      setPhase('preview');
    }
  };

  const handleFinish = async () => {
    try {
      setPhase('processing');
      const text = await runOcrOnPreview();
      const finalPages = text ? [...pages, text] : pages;

      if (finalPages.length === 0) {
        Alert.alert(
          'Aucun texte détecté',
          'Réessaie avec un meilleur éclairage ou un cadrage plus net, sans reflet.',
          [{ text: 'OK', onPress: () => { setPreviewUri(null); setPhase('camera'); } }]
        );
        return;
      }

      router.replace({
        pathname: '/card/ocr-split',
        params: { rawText: finalPages.join('\n\n') },
      });
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', "L'analyse du texte a échoué. Réessaie.");
      setPhase('preview');
    }
  };

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: pages.length > 0 ? `Scanner (page ${pages.length + 1})` : 'Scanner un cours',
          headerShown: true,
          headerStyle: { backgroundColor: '#000' },
          headerTintColor: '#fff',
        }}
      />

      {phase === 'camera' && (
        <>
          <CameraView
            ref={cameraRef}
            style={styles.camera}
            facing="back"
            enableTorch={flashOn}
            zoom={zoom}
          />

          <View pointerEvents="none" style={styles.guideFrame} />

          <TouchableOpacity
            style={styles.flashButton}
            onPress={() => setFlashOn((v) => !v)}
          >
            <Ionicons name={flashOn ? 'flash' : 'flash-off'} size={22} color="#fff" />
          </TouchableOpacity>

          <View style={styles.zoomRow}>
            <TouchableOpacity
              style={styles.zoomButton}
              onPress={() => setZoom((z) => Math.max(0, z - 0.15))}
            >
              <Text style={styles.zoomButtonText}>－</Text>
            </TouchableOpacity>
            <Text style={styles.zoomLabel}>{Math.round(zoom * 100)}%</Text>
            <TouchableOpacity
              style={styles.zoomButton}
              onPress={() => setZoom((z) => Math.min(1, z + 0.15))}
            >
              <Text style={styles.zoomButtonText}>＋</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.controls}>
            {pages.length > 0 && (
              <Text style={styles.pagesHint}>
                {pages.length} page{pages.length !== 1 ? 's' : ''} déjà scannée
                {pages.length !== 1 ? 's' : ''}
              </Text>
            )}
            <TouchableOpacity style={styles.shutterButton} onPress={handleShutterPress}>
              <Ionicons name="camera" size={32} color="#fff" />
            </TouchableOpacity>
            <Text style={styles.hint}>Aligne la page dans le cadre</Text>
          </View>
        </>
      )}

      {phase === 'preview' && previewUri && (
        <>
          <Image
            source={{ uri: previewUri }}
            style={[styles.previewImage, { transform: [{ rotate: `${rotation}deg` }] }]}
            resizeMode="contain"
          />
          <TouchableOpacity
            style={styles.rotateButton}
            onPress={() => setRotation((r) => (r + 90) % 360)}
          >
            <Ionicons name="reload" size={20} color="#fff" />
            <Text style={styles.rotateButtonText}>Pivoter</Text>
          </TouchableOpacity>
          <View style={styles.previewControls}>
            <TouchableOpacity style={styles.retakeButton} onPress={handleRetake}>
              <Text style={styles.retakeButtonText}>↺ Reprendre</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.addPageButton} onPress={handleAddAnotherPage}>
              <Text style={styles.addPageButtonText}>+ Page suivante</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.finishButton} onPress={handleFinish}>
              <Text style={styles.finishButtonText}>✓ Terminer</Text>
            </TouchableOpacity>
          </View>
        </>
      )}

      {phase === 'processing' && (
        <View style={styles.overlay}>
          <ActivityIndicator size="large" color="#fff" />
          <Text style={styles.overlayText}>Extraction du texte…</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  camera: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  permissionText: { textAlign: 'center', marginBottom: 16, color: '#111827' },
  permissionButton: {
    backgroundColor: '#4F46E5',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  permissionButtonText: { color: '#fff', fontWeight: '600' },
  flashButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    backgroundColor: 'rgba(0,0,0,0.5)',
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlayText: { color: '#fff', marginTop: 12, fontSize: 15 },
  controls: {
    position: 'absolute',
    bottom: 40,
    width: '100%',
    alignItems: 'center',
  },
  pagesHint: {
    color: '#A5B4FC',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 10,
  },
  shutterButton: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#4F46E5',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  hint: { color: '#fff', fontSize: 13 },
  guideFrame: {
    position: 'absolute',
    top: '18%',
    left: '6%',
    right: '6%',
    bottom: '28%',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.6)',
    borderStyle: 'dashed',
    borderRadius: 12,
  },
  zoomRow: {
    position: 'absolute',
    bottom: 150,
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 24,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  zoomButton: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  zoomButtonText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  zoomLabel: { color: '#fff', fontSize: 12, fontWeight: '600', marginHorizontal: 6 },
  rotateButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  rotateButtonText: { color: '#fff', fontSize: 12, fontWeight: '600', marginLeft: 6 },
  previewImage: { flex: 1, backgroundColor: '#000' },
  previewControls: {
    position: 'absolute',
    bottom: 30,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  retakeButton: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 10,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginHorizontal: 4,
  },
  retakeButtonText: { color: '#fff', fontWeight: '600', fontSize: 13 },
  addPageButton: {
    backgroundColor: '#0EA5E9',
    borderRadius: 10,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginHorizontal: 4,
  },
  addPageButtonText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  finishButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginHorizontal: 4,
  },
  finishButtonText: { color: '#fff', fontWeight: '700', fontSize: 13 },
});
