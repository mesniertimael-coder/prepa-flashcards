import { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Switch,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { getAllSubjects } from '../../src/db/queries/subjects';
import { createCardsBatch } from '../../src/db/queries/cards';
import { splitOcrTextIntoCards, CardDraft } from '../../src/services/ocrSplit';
import { Subject } from '../../src/types/models';
import { useTheme } from '../../src/theme/useTheme';
import { ThemeColors } from '../../src/theme/colors';
import { haptics } from '../../src/utils/haptics';

export default function OcrSplitScreen() {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const params = useLocalSearchParams<{ rawText?: string; sourceImageUri?: string }>();
  const router = useRouter();

  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);
  const [drafts, setDrafts] = useState<CardDraft[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    getAllSubjects().then((data) => {
      setSubjects(data);
      if (data.length > 0) setSelectedSubjectId(data[0].id);
    });

    const initial = splitOcrTextIntoCards(params.rawText ?? '');
    setDrafts(initial);
  }, []);

  const updateDraft = (id: string, patch: Partial<CardDraft>) => {
    setDrafts((prev) => prev.map((d) => (d.id === id ? { ...d, ...patch } : d)));
  };

  const removeDraft = (id: string) => {
    setDrafts((prev) => prev.filter((d) => d.id !== id));
  };

  const addEmptyDraft = () => {
    setDrafts((prev) => [
      ...prev,
      { id: `manual-${Date.now()}`, question: '', answer: '', include: true },
    ]);
  };

  const includedCount = drafts.filter(
    (d) => d.include && d.question.trim() && d.answer.trim()
  ).length;

  const handleCreateAll = async () => {
    if (!selectedSubjectId) {
      Alert.alert('Matière requise', 'Choisis une matière pour ces cartes.');
      return;
    }
    const toCreate = drafts.filter(
      (d) => d.include && d.question.trim() && d.answer.trim()
    );
    if (toCreate.length === 0) {
      Alert.alert(
        'Aucune carte complète',
        'Renseigne au moins une question et une réponse, ou décoche les cartes incomplètes.'
      );
      return;
    }

    try {
      setSaving(true);
      await createCardsBatch(
        toCreate.map((d) => ({
          subjectId: selectedSubjectId,
          question: d.question,
          answer: d.answer,
          sourceImageUri: params.sourceImageUri ?? null,
        }))
      );
      haptics.success();
      router.push('/');
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', "Les cartes n'ont pas pu être enregistrées.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <Stack.Screen
        options={{
          title: 'Cartes détectées',
          headerShown: true,
          headerStyle: { backgroundColor: theme.surface },
          headerTintColor: theme.text,
          headerShadowVisible: false,
        }}
      />

      <Text style={styles.intro}>
        {drafts.length} carte{drafts.length !== 1 ? 's' : ''} proposée
        {drafts.length !== 1 ? 's' : ''} à partir de ta photo. Vérifie et corrige chaque
        carte avant de valider — le découpage automatique n'est pas toujours parfait.
      </Text>

      <Text style={styles.label}>Matière pour toutes ces cartes</Text>
      <View style={styles.chipRow}>
        {subjects.map((s) => (
          <TouchableOpacity
            key={s.id}
            style={[
              styles.chip,
              { borderColor: s.color },
              selectedSubjectId === s.id && { backgroundColor: s.color },
            ]}
            onPress={() => { haptics.selection(); setSelectedSubjectId(s.id); }}
          >
            <Text
              style={[styles.chipText, selectedSubjectId === s.id && { color: '#fff' }]}
            >
              {s.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {drafts.map((draft, index) => (
        <View key={draft.id} style={[styles.draftCard, !draft.include && styles.draftCardDisabled]}>
          <View style={styles.draftHeader}>
            <Text style={styles.draftTitle}>Carte {index + 1}</Text>
            <View style={styles.draftHeaderActions}>
              <Switch value={draft.include} onValueChange={(v) => updateDraft(draft.id, { include: v })} />
              <TouchableOpacity onPress={() => { haptics.tap(); removeDraft(draft.id); }} style={styles.removeButton}>
                <Text style={styles.removeButtonText}>✕</Text>
              </TouchableOpacity>
            </View>
          </View>

          <TextInput
            style={styles.draftInput}
            placeholder="Question"
            placeholderTextColor={theme.textFaint}
            multiline
            value={draft.question}
            onChangeText={(t) => updateDraft(draft.id, { question: t })}
            editable={draft.include}
          />
          <TextInput
            style={styles.draftInput}
            placeholder="Réponse"
            placeholderTextColor={theme.textFaint}
            multiline
            value={draft.answer}
            onChangeText={(t) => updateDraft(draft.id, { answer: t })}
            editable={draft.include}
          />
        </View>
      ))}

      <TouchableOpacity style={styles.addButton} onPress={addEmptyDraft}>
        <Text style={styles.addButtonText}>+ Ajouter une carte manuellement</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.saveButton, saving && { opacity: 0.6 }]}
        onPress={handleCreateAll}
        disabled={saving}
      >
        <Text style={styles.saveButtonText}>
          {saving ? 'Enregistrement…' : `Créer ${includedCount} carte${includedCount !== 1 ? 's' : ''}`}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: c.background },
    intro: { fontSize: 13, color: c.textMuted, lineHeight: 19, marginBottom: 20 },
    label: { fontSize: 14, fontWeight: '600', color: c.text, marginBottom: 8 },
    chipRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 20 },
    chip: {
      borderWidth: 1.5,
      borderRadius: 20,
      paddingHorizontal: 14,
      paddingVertical: 8,
      marginRight: 8,
      marginBottom: 8,
    },
    chipText: { fontSize: 13, color: c.text, fontWeight: '500' },
    draftCard: {
      backgroundColor: c.surfaceAlt,
      borderRadius: 12,
      padding: 14,
      marginBottom: 14,
      borderWidth: 1,
      borderColor: c.border,
    },
    draftCardDisabled: { opacity: 0.5 },
    draftHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 10,
    },
    draftTitle: { fontSize: 13, fontWeight: '700', color: c.textMuted },
    draftHeaderActions: { flexDirection: 'row', alignItems: 'center' },
    removeButton: { marginLeft: 12, padding: 4 },
    removeButtonText: { fontSize: 16, color: c.danger, fontWeight: '700' },
    draftInput: {
      backgroundColor: c.surface,
      borderWidth: 1,
      borderColor: c.border,
      borderRadius: 8,
      padding: 10,
      fontSize: 14,
      marginBottom: 8,
      minHeight: 44,
      textAlignVertical: 'top',
      color: c.text,
    },
    addButton: {
      borderWidth: 1.5,
      borderColor: c.accent,
      borderStyle: 'dashed',
      borderRadius: 10,
      padding: 14,
      alignItems: 'center',
      marginBottom: 20,
    },
    addButtonText: { color: c.accentText, fontWeight: '600' },
    saveButton: {
      backgroundColor: c.accent,
      borderRadius: 10,
      padding: 16,
      alignItems: 'center',
    },
    saveButtonText: { color: c.onAccent, fontWeight: '700', fontSize: 15 },
  });
}
