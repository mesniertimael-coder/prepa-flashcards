import { useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { useRouter, Stack } from 'expo-router';
import DocumentTextExtractor from '../../src/components/DocumentTextExtractor';
import { useTheme } from '../../src/theme/useTheme';
import { ThemeColors } from '../../src/theme/colors';

type FileKind = 'pdf' | 'docx' | 'txt' | null;

export default function ImportDocumentScreen() {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const router = useRouter();
  const [pickedUri, setPickedUri] = useState<string | null>(null);
  const [fileKind, setFileKind] = useState<FileKind>(null);
  const [fileName, setFileName] = useState('');
  const [extracting, setExtracting] = useState(false);

  const handlePick = async () => {
    const result = await DocumentPicker.getDocumentAsync({
      type: [
        'application/pdf',
        'text/plain',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      ],
      copyToCacheDirectory: true,
    });

    if (result.canceled || !result.assets?.[0]) return;
    const asset = result.assets[0];
    const name = asset.name.toLowerCase();

    let kind: FileKind = null;
    if (name.endsWith('.pdf')) kind = 'pdf';
    else if (name.endsWith('.docx')) kind = 'docx';
    else if (name.endsWith('.txt')) kind = 'txt';

    if (!kind) {
      Alert.alert('Format non supporté', 'Choisis un fichier .pdf, .docx ou .txt.');
      return;
    }

    setFileName(asset.name);
    setPickedUri(asset.uri);
    setFileKind(kind);
    setExtracting(true);

    if (kind === 'txt') {
      try {
        const text = await FileSystem.readAsStringAsync(asset.uri, {
          encoding: FileSystem.EncodingType.UTF8,
        });
        goToSplit(text);
      } catch (err) {
        console.error(err);
        Alert.alert('Erreur', 'Impossible de lire ce fichier texte.');
        setExtracting(false);
      }
    }
    // Pour pdf/docx, le composant DocumentTextExtractor prend le relais (rendu ci-dessous)
  };

  const goToSplit = (text: string) => {
    setExtracting(false);
    if (!text.trim()) {
      Alert.alert('Aucun texte trouvé', 'Ce document ne contient pas de texte extractible.');
      return;
    }
    router.replace({ pathname: '/card/ocr-split', params: { rawText: text } });
  };

  const handleExtractError = (err: string) => {
    console.error(err);
    setExtracting(false);
    Alert.alert(
      'Erreur',
      "L'extraction du texte a échoué pour ce fichier. Réessaie ou choisis un autre document."
    );
  };

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: 'Importer un document',
          headerShown: true,
          headerStyle: { backgroundColor: theme.surface },
          headerTintColor: theme.text,
          headerShadowVisible: false,
        }}
      />

      {!extracting && (
        <>
          <Text style={styles.icon}>📄</Text>
          <Text style={styles.title}>Importer un cours</Text>
          <Text style={styles.subtitle}>
            Choisis un fichier PDF, Word (.docx) ou texte (.txt) déjà présent sur ton
            téléphone (cours téléchargé, notes partagées…).
          </Text>
          <TouchableOpacity style={styles.pickButton} onPress={handlePick}>
            <Text style={styles.pickButtonText}>Choisir un fichier</Text>
          </TouchableOpacity>
        </>
      )}

      {extracting && (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={theme.accent} />
          <Text style={styles.extractingText}>
            Extraction du texte de « {fileName} »…
          </Text>
        </View>
      )}

      {extracting && pickedUri && (fileKind === 'pdf' || fileKind === 'docx') && (
        <DocumentTextExtractor
          fileUri={pickedUri}
          fileType={fileKind}
          onExtracted={goToSplit}
          onError={handleExtractError}
        />
      )}
    </View>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: c.background,
      padding: 24,
      justifyContent: 'center',
      alignItems: 'center',
    },
    icon: { fontSize: 56, marginBottom: 16 },
    title: { fontSize: 20, fontWeight: '700', color: c.text, marginBottom: 8 },
    subtitle: {
      fontSize: 14,
      color: c.textMuted,
      textAlign: 'center',
      marginBottom: 24,
      lineHeight: 20,
    },
    pickButton: {
      backgroundColor: c.accent,
      borderRadius: 10,
      paddingHorizontal: 24,
      paddingVertical: 14,
    },
    pickButtonText: { color: c.onAccent, fontWeight: '700' },
    center: { alignItems: 'center' },
    extractingText: { marginTop: 16, color: c.textMuted, fontSize: 14, textAlign: 'center' },
  });
}
