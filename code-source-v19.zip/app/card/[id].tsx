import { useCallback, useMemo, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useFocusEffect, useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { getCardById, updateCard, deleteCard } from '../../src/db/queries/cards';
import { BOX_LABELS } from '../../src/constants/leitner';
import MathText from '../../src/components/MathText';
import UndoBanner from '../../src/components/UndoBanner';
import { useUndoableAction } from '../../src/hooks/useUndoableAction';
import { formatReviewDate } from '../../src/utils/date';
import { useTheme } from '../../src/theme/useTheme';
import { ThemeColors } from '../../src/theme/colors';
import { haptics } from '../../src/utils/haptics';

export default function EditCardScreen() {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const { id } = useLocalSearchParams<{ id: string }>();
  const cardId = Number(id);
  const router = useRouter();

  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [notes, setNotes] = useState('');
  const [box, setBox] = useState<number | null>(null);
  const [nextReviewDate, setNextReviewDate] = useState<string | null>(null);
  const [successCount, setSuccessCount] = useState(0);
  const [failCount, setFailCount] = useState(0);
  const [saving, setSaving] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const load = useCallback(async () => {
    const card = await getCardById(cardId);
    if (card) {
      setQuestion(card.question);
      setAnswer(card.answer);
      setNotes(card.notes ?? '');
      setBox(card.box);
      setNextReviewDate(card.nextReviewDate);
      setSuccessCount(card.successCount);
      setFailCount(card.failCount);
    }
    setLoaded(true);
  }, [cardId]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleSave = async () => {
    if (!question.trim() || !answer.trim()) {
      Alert.alert('Champs manquants', 'Renseigne la question et la réponse.');
      return;
    }
    try {
      setSaving(true);
      await updateCard(cardId, question, answer, notes);
      haptics.success();
      router.back();
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', "La carte n'a pas pu être mise à jour.");
    } finally {
      setSaving(false);
    }
  };

  const { pendingMessage, scheduleAction, undo } = useUndoableAction();

  const handleDelete = () => {
    Alert.alert(
      'Supprimer cette carte ?',
      'Cette action est définitive.',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: () => {
            haptics.warning();
            // On reste sur l'écran pendant le délai d'annulation ; la
            // navigation en arrière n'a lieu qu'une fois la carte réellement
            // supprimée en base.
            scheduleAction('Carte supprimée', async () => {
              await deleteCard(cardId);
              router.back();
            });
          },
        },
      ]
    );
  };

  if (!loaded) return null;

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scroll} contentContainerStyle={{ padding: 16 }}>
      <Stack.Screen
        options={{
          title: 'Modifier la carte',
          headerShown: true,
          headerStyle: { backgroundColor: theme.surface },
          headerTintColor: theme.text,
          headerShadowVisible: false,
        }}
      />

      {box !== null && (
        <Text style={styles.boxTag}>
          {BOX_LABELS[box]}
          {nextReviewDate ? ` · prochaine révision : ${formatReviewDate(nextReviewDate)}` : ''}
        </Text>
      )}

      <View style={styles.statsRow}>
        <Text style={styles.statText}>✅ {successCount} réussite{successCount !== 1 ? 's' : ''}</Text>
        <Text style={styles.statText}>❌ {failCount} échec{failCount !== 1 ? 's' : ''}</Text>
      </View>

      <Text style={styles.label}>Question</Text>
      <TextInput
        style={styles.input}
        multiline
        value={question}
        onChangeText={setQuestion}
        placeholderTextColor={theme.textFaint}
      />
      {question.includes('$') && (
        <View style={styles.previewBox}>
          <Text style={styles.previewLabel}>Aperçu</Text>
          <MathText content={question} fontSize={15} color={theme.text} />
        </View>
      )}

      <Text style={styles.label}>Réponse</Text>
      <TextInput
        style={styles.input}
        multiline
        value={answer}
        onChangeText={setAnswer}
        placeholderTextColor={theme.textFaint}
      />
      {answer.includes('$') && (
        <View style={styles.previewBox}>
          <Text style={styles.previewLabel}>Aperçu</Text>
          <MathText content={answer} fontSize={15} color={theme.text} />
        </View>
      )}

      <Text style={styles.label}>Note personnelle (optionnel)</Text>
      <TextInput
        style={[styles.input, styles.notesInput]}
        multiline
        value={notes}
        onChangeText={setNotes}
        placeholder="Ex : « piège classique », « à revoir avant le concours »…"
        placeholderTextColor={theme.textFaint}
      />

      <TouchableOpacity
        style={[styles.saveButton, saving && { opacity: 0.6 }]}
        onPress={handleSave}
        disabled={saving}
      >
        <Text style={styles.saveButtonText}>
          {saving ? 'Enregistrement…' : 'Enregistrer les modifications'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.deleteButton} onPress={handleDelete}>
        <Text style={styles.deleteButtonText}>🗑️ Supprimer cette carte</Text>
      </TouchableOpacity>
      </ScrollView>

      <UndoBanner message={pendingMessage} onUndo={() => { haptics.tap(); undo(); }} />
    </View>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: c.background },
    scroll: { flex: 1 },
    boxTag: {
      alignSelf: 'flex-start',
      backgroundColor: c.surfaceAlt,
      color: c.accentText,
      fontSize: 12,
      fontWeight: '700',
      paddingHorizontal: 10,
      paddingVertical: 4,
      borderRadius: 12,
      marginBottom: 8,
    },
    label: { fontSize: 14, fontWeight: '600', color: c.text, marginBottom: 8, marginTop: 16 },
    statsRow: { flexDirection: 'row', marginBottom: 8 },
    statText: { fontSize: 13, color: c.textMuted, marginRight: 16, fontWeight: '600' },
    previewBox: {
      backgroundColor: c.surfaceAlt,
      borderRadius: 8,
      padding: 10,
      marginTop: 8,
      borderWidth: 1,
      borderColor: c.border,
    },
    previewLabel: { fontSize: 11, fontWeight: '700', color: c.textFaint, marginBottom: 4 },
    input: {
      borderWidth: 1,
      borderColor: c.border,
      borderRadius: 10,
      padding: 12,
      fontSize: 15,
      minHeight: 80,
      textAlignVertical: 'top',
      color: c.text,
      backgroundColor: c.surface,
    },
    notesInput: { minHeight: 50 },
    saveButton: {
      backgroundColor: c.accent,
      borderRadius: 10,
      padding: 16,
      alignItems: 'center',
      marginTop: 24,
    },
    saveButtonText: { color: c.onAccent, fontWeight: '700', fontSize: 15 },
    deleteButton: {
      backgroundColor: c.dangerSoft,
      borderRadius: 10,
      padding: 16,
      alignItems: 'center',
      marginTop: 12,
      marginBottom: 40,
    },
    deleteButtonText: { color: c.dangerText, fontWeight: '700', fontSize: 15 },
  });
}
