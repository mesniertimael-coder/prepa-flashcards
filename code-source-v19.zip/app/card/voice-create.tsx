import { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useRouter, useLocalSearchParams, Stack } from 'expo-router';
import { getAllSubjects } from '../../src/db/queries/subjects';
import { createCard } from '../../src/db/queries/cards';
import { Subject } from '../../src/types/models';
import VoiceInputWebView, { VoiceInputHandle } from '../../src/components/VoiceInputWebView';
import MathText from '../../src/components/MathText';
import { useTheme } from '../../src/theme/useTheme';
import { ThemeColors } from '../../src/theme/colors';
import { haptics } from '../../src/utils/haptics';

type ActiveField = 'question' | 'answer' | null;

export default function VoiceCreateScreen() {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const router = useRouter();
  const params = useLocalSearchParams<{ subjectId?: string }>();
  const voiceRef = useRef<VoiceInputHandle>(null);

  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [listening, setListening] = useState(false);
  const [activeField, setActiveField] = useState<ActiveField>(null);
  const [saving, setSaving] = useState(false);

  const activeFieldRef = useRef<ActiveField>(null);
  useEffect(() => {
    activeFieldRef.current = activeField;
  }, [activeField]);

  useEffect(() => {
    getAllSubjects().then((data) => {
      setSubjects(data);
      if (params.subjectId) {
        setSelectedSubjectId(Number(params.subjectId));
      } else if (data.length > 0) {
        setSelectedSubjectId(data[0].id);
      }
    });
  }, []);

  const handleResult = (text: string) => {
    if (activeFieldRef.current === 'question') setQuestion(text);
    else if (activeFieldRef.current === 'answer') setAnswer(text);
  };

  const handleEnd = () => setListening(false);

  const handleError = (error: string) => {
    setListening(false);
    if (error === 'not_supported') {
      Alert.alert('Non disponible', "La reconnaissance vocale n'est pas disponible sur cet appareil.");
    } else if (error === 'not-allowed' || error === 'permission-denied') {
      Alert.alert('Micro refusé', "Autorise le micro pour utiliser la dictée vocale.");
    } else if (error !== 'no-speech' && error !== 'aborted') {
      console.error('Voice error:', error);
    }
  };

  const startListening = (field: ActiveField) => {
    setActiveField(field);
    setListening(true);
    voiceRef.current?.start();
  };

  const stopListening = () => {
    voiceRef.current?.stop();
    setListening(false);
  };

  const handleSave = async () => {
    if (!selectedSubjectId) {
      Alert.alert('Matière requise', 'Choisis une matière pour la carte.');
      return;
    }
    if (!question.trim() || !answer.trim()) {
      Alert.alert('Champs manquants', 'Dicte ou écris la question et la réponse.');
      return;
    }
    try {
      setSaving(true);
      await createCard({ subjectId: selectedSubjectId, question, answer });
      haptics.success();
      router.back();
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', "La carte n'a pas pu être enregistrée.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Stack.Screen
        options={{
          title: 'Créer par la voix',
          headerShown: true,
          headerStyle: { backgroundColor: theme.surface },
          headerTintColor: theme.text,
          headerShadowVisible: false,
        }}
      />

      <VoiceInputWebView
        ref={voiceRef}
        onResult={handleResult}
        onEnd={handleEnd}
        onError={handleError}
      />

      <Text style={styles.label}>Matière</Text>
      <View style={styles.chipRow}>
        {subjects.map((s) => (
          <TouchableOpacity
            key={s.id}
            style={[
              styles.chip,
              { borderColor: s.color },
              selectedSubjectId === s.id && { backgroundColor: s.color },
            ]}
            onPress={() => { haptics.selection(); setSelectedSubjectId(s.id); }}
          >
            <Text
              style={[styles.chipText, selectedSubjectId === s.id && { color: '#fff' }]}
            >
              {s.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Question</Text>
      <Text style={styles.latexHint}>
        Astuce : dicte "x au carré", "pi", "racine carrée de 2", "supérieur ou
        égal à"... ce sera converti automatiquement en symboles/formules.
      </Text>
      <TextInput
        style={styles.input}
        multiline
        value={question}
        onChangeText={setQuestion}
        placeholder="Dicte ou écris la question"
        placeholderTextColor={theme.textFaint}
      />
      {question.includes('$') && (
        <View style={styles.previewBox}>
          <Text style={styles.previewLabel}>Aperçu</Text>
          <MathText content={question} fontSize={15} color={theme.text} />
        </View>
      )}
      <TouchableOpacity
        style={[
          styles.micButton,
          listening && activeField === 'question' && styles.micButtonActive,
        ]}
        onPress={() =>
          listening && activeField === 'question' ? stopListening() : startListening('question')
        }
      >
        <Text style={styles.micButtonText}>
          {listening && activeField === 'question' ? '⏹ Arrêter' : '🎙️ Dicter la question'}
        </Text>
      </TouchableOpacity>

      <Text style={styles.label}>Réponse</Text>
      <TextInput
        style={styles.input}
        multiline
        value={answer}
        onChangeText={setAnswer}
        placeholder="Dicte ou écris la réponse"
        placeholderTextColor={theme.textFaint}
      />
      {answer.includes('$') && (
        <View style={styles.previewBox}>
          <Text style={styles.previewLabel}>Aperçu</Text>
          <MathText content={answer} fontSize={15} color={theme.text} />
        </View>
      )}
      <TouchableOpacity
        style={[
          styles.micButton,
          listening && activeField === 'answer' && styles.micButtonActive,
        ]}
        onPress={() =>
          listening && activeField === 'answer' ? stopListening() : startListening('answer')
        }
      >
        <Text style={styles.micButtonText}>
          {listening && activeField === 'answer' ? '⏹ Arrêter' : '🎙️ Dicter la réponse'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.saveButton, saving && { opacity: 0.6 }]}
        onPress={handleSave}
        disabled={saving}
      >
        <Text style={styles.saveButtonText}>
          {saving ? 'Enregistrement…' : 'Enregistrer la carte'}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: c.background },
    label: { fontSize: 14, fontWeight: '600', color: c.text, marginBottom: 8, marginTop: 16 },
    chipRow: { flexDirection: 'row', flexWrap: 'wrap' },
    chip: {
      borderWidth: 1.5,
      borderRadius: 20,
      paddingHorizontal: 14,
      paddingVertical: 8,
      marginRight: 8,
      marginBottom: 8,
    },
    chipText: { fontSize: 13, color: c.text, fontWeight: '500' },
    latexHint: { fontSize: 11, color: c.textFaint, marginBottom: 6 },
    previewBox: {
      backgroundColor: c.surfaceAlt,
      borderRadius: 8,
      padding: 10,
      marginTop: 8,
      marginBottom: 8,
      borderWidth: 1,
      borderColor: c.border,
    },
    previewLabel: { fontSize: 11, fontWeight: '700', color: c.textFaint, marginBottom: 4 },
    input: {
      borderWidth: 1,
      borderColor: c.border,
      borderRadius: 10,
      padding: 12,
      fontSize: 15,
      minHeight: 70,
      textAlignVertical: 'top',
      marginBottom: 8,
      color: c.text,
      backgroundColor: c.surface,
    },
    micButton: {
      backgroundColor: c.mode === 'dark' ? c.surfaceAlt : '#EEF2FF',
      borderRadius: 10,
      padding: 12,
      alignItems: 'center',
    },
    micButtonActive: { backgroundColor: c.dangerSoft },
    micButtonText: { color: c.accentText, fontWeight: '700', fontSize: 13 },
    saveButton: {
      backgroundColor: c.accent,
      borderRadius: 10,
      padding: 16,
      alignItems: 'center',
      marginTop: 24,
      marginBottom: 40,
    },
    saveButtonText: { color: c.onAccent, fontWeight: '700', fontSize: 15 },
  });
}
