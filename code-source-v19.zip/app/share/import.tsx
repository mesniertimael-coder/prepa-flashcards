import { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  TextInput,
  Switch,
} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { useRouter, Stack } from 'expo-router';
import { parseSharedDeckFile, SharedGroup } from '../../src/services/shareCards';
import { getAllSubjects, createSubject } from '../../src/db/queries/subjects';
import { createCardsBatch } from '../../src/db/queries/cards';
import { Subject } from '../../src/types/models';
import { useTheme } from '../../src/theme/useTheme';
import { ThemeColors } from '../../src/theme/colors';
import { haptics } from '../../src/utils/haptics';

const COLOR_PALETTE = [
  '#4F46E5', '#0EA5E9', '#10B981', '#F59E0B',
  '#EF4444', '#8B5CF6', '#EC4899', '#14B8A6',
];

interface CardState {
  question: string;
  answer: string;
  include: boolean;
}

interface GroupState {
  originalName: string;
  originalColor: string;
  groupInclude: boolean;
  destinationMode: 'existing' | 'new';
  destinationSubjectId: number | null;
  newSubjectName: string;
  newSubjectColor: string;
  cards: CardState[];
  expanded: boolean;
}

export default function ShareImportScreen() {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const router = useRouter();
  const [localSubjects, setLocalSubjects] = useState<Subject[]>([]);
  const [groups, setGroups] = useState<GroupState[]>([]);
  const [phase, setPhase] = useState<'pick' | 'review'>('pick');
  const [importing, setImporting] = useState(false);

  const buildGroupState = (g: SharedGroup, existing: Subject[]): GroupState => {
    const match = existing.find(
      (s) => s.name.trim().toLowerCase() === g.subjectName.trim().toLowerCase()
    );
    return {
      originalName: g.subjectName,
      originalColor: g.subjectColor,
      groupInclude: true,
      destinationMode: match ? 'existing' : 'new',
      destinationSubjectId: match ? match.id : null,
      newSubjectName: g.subjectName,
      newSubjectColor: g.subjectColor,
      cards: g.cards.map((c) => ({ question: c.question, answer: c.answer, include: true })),
      expanded: false,
    };
  };

  const handlePickFile = async () => {
    const result = await DocumentPicker.getDocumentAsync({
      type: ['application/json', '*/*'],
      copyToCacheDirectory: true,
    });
    if (result.canceled || !result.assets?.[0]) return;

    try {
      const sharedGroups = await parseSharedDeckFile(result.assets[0].uri);
      const existing = await getAllSubjects();
      setLocalSubjects(existing);
      setGroups(sharedGroups.map((g) => buildGroupState(g, existing)));
      setPhase('review');
    } catch (err: any) {
      Alert.alert('Fichier invalide', err?.message ?? 'Impossible de lire ce fichier.');
    }
  };

  const updateGroup = (index: number, patch: Partial<GroupState>) => {
    setGroups((prev) => prev.map((g, i) => (i === index ? { ...g, ...patch } : g)));
  };

  const updateCard = (groupIndex: number, cardIndex: number, include: boolean) => {
    setGroups((prev) =>
      prev.map((g, i) => {
        if (i !== groupIndex) return g;
        const cards = g.cards.map((c, ci) => (ci === cardIndex ? { ...c, include } : c));
        return { ...g, cards };
      })
    );
  };

  const totalToImport = groups
    .filter((g) => g.groupInclude)
    .reduce((sum, g) => sum + g.cards.filter((c) => c.include).length, 0);

  const handleImport = async () => {
    const activeGroups = groups.filter(
      (g) => g.groupInclude && g.cards.some((c) => c.include)
    );

    if (activeGroups.length === 0) {
      Alert.alert('Rien à importer', 'Sélectionne au moins une carte.');
      return;
    }

    for (const g of activeGroups) {
      if (g.destinationMode === 'new' && !g.newSubjectName.trim()) {
        Alert.alert('Nom manquant', `Donne un nom à la nouvelle matière pour "${g.originalName}".`);
        return;
      }
      if (g.destinationMode === 'existing' && !g.destinationSubjectId) {
        Alert.alert('Matière manquante', `Choisis une matière de destination pour "${g.originalName}".`);
        return;
      }
    }

    try {
      setImporting(true);
      const batch: { subjectId: number; question: string; answer: string }[] = [];

      for (const g of activeGroups) {
        let targetSubjectId: number;
        if (g.destinationMode === 'new') {
          targetSubjectId = await createSubject(g.newSubjectName, g.newSubjectColor);
        } else {
          targetSubjectId = g.destinationSubjectId!;
        }

        for (const c of g.cards) {
          if (c.include) {
            batch.push({ subjectId: targetSubjectId, question: c.question, answer: c.answer });
          }
        }
      }

      await createCardsBatch(batch);
      haptics.success();
      router.push('/');
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', "L'import a échoué.");
    } finally {
      setImporting(false);
    }
  };

  if (phase === 'pick') {
    return (
      <View style={styles.pickContainer}>
        <Stack.Screen
          options={{
            title: 'Importer des cartes reçues',
            headerShown: true,
            headerStyle: { backgroundColor: theme.surface },
            headerTintColor: theme.text,
            headerShadowVisible: false,
          }}
        />
        <Text style={styles.icon}>📥</Text>
        <Text style={styles.title}>Importer des cartes partagées</Text>
        <Text style={styles.subtitle}>
          Choisis le fichier de cartes que quelqu'un t'a envoyé (WhatsApp, mail,
          Drive…). Tu pourras ensuite choisir où ranger chaque dossier avant de
          valider.
        </Text>
        <TouchableOpacity style={styles.pickButton} onPress={handlePickFile}>
          <Text style={styles.pickButtonText}>Choisir le fichier reçu</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <Stack.Screen
        options={{
          title: 'Trier les cartes reçues',
          headerShown: true,
          headerStyle: { backgroundColor: theme.surface },
          headerTintColor: theme.text,
          headerShadowVisible: false,
        }}
      />

      <Text style={styles.intro}>
        {groups.length} dossier{groups.length !== 1 ? 's' : ''} reçu{groups.length !== 1 ? 's' : ''}.
        Choisis où ranger chaque dossier, et décoche les cartes que tu ne veux pas garder.
      </Text>

      {groups.map((g, gi) => (
        <View key={gi} style={[styles.groupCard, !g.groupInclude && styles.groupCardDisabled]}>
          <View style={styles.groupHeader}>
            <View style={[styles.dot, { backgroundColor: g.originalColor }]} />
            <Text style={styles.groupTitle}>{g.originalName}</Text>
            <Text style={styles.groupCount}>
              {g.cards.filter((c) => c.include).length}/{g.cards.length}
            </Text>
            <Switch value={g.groupInclude} onValueChange={(v) => updateGroup(gi, { groupInclude: v })} />
          </View>

          {g.groupInclude && (
            <>
              <Text style={styles.destLabel}>Ranger dans :</Text>
              <View style={styles.chipRow}>
                {localSubjects.map((s) => (
                  <TouchableOpacity
                    key={s.id}
                    style={[
                      styles.chip,
                      { borderColor: s.color },
                      g.destinationMode === 'existing' &&
                        g.destinationSubjectId === s.id && { backgroundColor: s.color },
                    ]}
                    onPress={() => {
                      haptics.selection();
                      updateGroup(gi, { destinationMode: 'existing', destinationSubjectId: s.id });
                    }}
                  >
                    <Text
                      style={[
                        styles.chipText,
                        g.destinationMode === 'existing' &&
                          g.destinationSubjectId === s.id && { color: '#fff' },
                      ]}
                    >
                      {s.name}
                    </Text>
                  </TouchableOpacity>
                ))}
                <TouchableOpacity
                  style={[
                    styles.chip,
                    styles.newChip,
                    g.destinationMode === 'new' && styles.newChipActive,
                  ]}
                  onPress={() => { haptics.selection(); updateGroup(gi, { destinationMode: 'new' }); }}
                >
                  <Text
                    style={[styles.chipText, g.destinationMode === 'new' && { color: '#fff' }]}
                  >
                    + Nouvelle matière
                  </Text>
                </TouchableOpacity>
              </View>

              {g.destinationMode === 'new' && (
                <View style={styles.newSubjectBox}>
                  <TextInput
                    style={styles.newSubjectInput}
                    value={g.newSubjectName}
                    onChangeText={(t) => updateGroup(gi, { newSubjectName: t })}
                    placeholder="Nom de la matière"
                    placeholderTextColor={theme.textFaint}
                  />
                  <View style={styles.colorRow}>
                    {COLOR_PALETTE.map((c) => (
                      <TouchableOpacity
                        key={c}
                        style={[
                          styles.colorSwatch,
                          { backgroundColor: c },
                          g.newSubjectColor === c && styles.colorSwatchSelected,
                        ]}
                        onPress={() => updateGroup(gi, { newSubjectColor: c })}
                      />
                    ))}
                  </View>
                </View>
              )}

              <TouchableOpacity
                onPress={() => updateGroup(gi, { expanded: !g.expanded })}
                style={styles.expandButton}
              >
                <Text style={styles.expandButtonText}>
                  {g.expanded ? '▲ Masquer les cartes' : '▼ Voir/décocher les cartes'}
                </Text>
              </TouchableOpacity>

              {g.expanded &&
                g.cards.map((c, ci) => (
                  <View key={ci} style={styles.cardRow}>
                    <Switch
                      value={c.include}
                      onValueChange={(v) => updateCard(gi, ci, v)}
                    />
                    <Text style={styles.cardRowText} numberOfLines={2}>
                      {c.question}
                    </Text>
                  </View>
                ))}
            </>
          )}
        </View>
      ))}

      <TouchableOpacity
        style={[styles.importButton, (importing || totalToImport === 0) && { opacity: 0.6 }]}
        onPress={handleImport}
        disabled={importing || totalToImport === 0}
      >
        <Text style={styles.importButtonText}>
          {importing
            ? 'Import en cours…'
            : `Importer ${totalToImport} carte${totalToImport !== 1 ? 's' : ''}`}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: c.background },
    pickContainer: {
      flex: 1,
      backgroundColor: c.background,
      padding: 24,
      justifyContent: 'center',
      alignItems: 'center',
    },
    icon: { fontSize: 56, marginBottom: 16 },
    title: { fontSize: 20, fontWeight: '700', color: c.text, marginBottom: 8 },
    subtitle: {
      fontSize: 14,
      color: c.textMuted,
      textAlign: 'center',
      marginBottom: 24,
      lineHeight: 20,
    },
    pickButton: {
      backgroundColor: c.accent,
      borderRadius: 10,
      paddingHorizontal: 24,
      paddingVertical: 14,
    },
    pickButtonText: { color: c.onAccent, fontWeight: '700' },
    intro: { fontSize: 13, color: c.textMuted, lineHeight: 19, marginBottom: 20 },
    groupCard: {
      backgroundColor: c.surfaceAlt,
      borderRadius: 12,
      padding: 14,
      marginBottom: 14,
      borderWidth: 1,
      borderColor: c.border,
    },
    groupCardDisabled: { opacity: 0.5 },
    groupHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
    dot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
    groupTitle: { flex: 1, fontSize: 15, fontWeight: '700', color: c.text },
    groupCount: { fontSize: 12, color: c.textMuted, marginRight: 10, fontWeight: '600' },
    destLabel: { fontSize: 12, color: c.textMuted, fontWeight: '600', marginBottom: 8 },
    chipRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 },
    chip: {
      borderWidth: 1.5,
      borderColor: c.border,
      borderRadius: 16,
      paddingHorizontal: 12,
      paddingVertical: 6,
      marginRight: 8,
      marginBottom: 8,
    },
    chipText: { fontSize: 12, color: c.text, fontWeight: '500' },
    newChip: { borderColor: c.accent, borderStyle: 'dashed' },
    newChipActive: { backgroundColor: c.accent, borderColor: c.accent },
    newSubjectBox: { marginTop: 4, marginBottom: 8 },
    newSubjectInput: {
      borderWidth: 1,
      borderColor: c.border,
      borderRadius: 8,
      padding: 10,
      fontSize: 14,
      marginBottom: 8,
      backgroundColor: c.surface,
      color: c.text,
    },
    colorRow: { flexDirection: 'row', flexWrap: 'wrap' },
    colorSwatch: { width: 28, height: 28, borderRadius: 14, marginRight: 8, marginBottom: 8 },
    colorSwatchSelected: { borderWidth: 3, borderColor: c.text },
    expandButton: { paddingVertical: 8 },
    expandButtonText: { fontSize: 12, color: c.accentText, fontWeight: '600' },
    cardRow: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: c.surface,
      borderRadius: 8,
      padding: 10,
      marginTop: 6,
    },
    cardRowText: { flex: 1, marginLeft: 10, fontSize: 13, color: c.text },
    importButton: {
      backgroundColor: c.accent,
      borderRadius: 10,
      padding: 16,
      alignItems: 'center',
      marginTop: 8,
    },
    importButtonText: { color: c.onAccent, fontWeight: '700', fontSize: 15 },
  });
}
