import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { getDatabase } from '../db/database';

interface BackupSubject {
  id: number;
  name: string;
  color?: string;
}

interface BackupFlashcard {
  subject_id: number;
  question: string;
  answer: string;
  box?: number;
  next_review_date?: string;
  source_image_uri?: string | null;
}

interface BackupData {
  exportedAt: string;
  version: 1;
  subjects: BackupSubject[];
  flashcards: BackupFlashcard[];
  review_logs: any[];
  settings: any[];
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

/**
 * Valide et nettoie le contenu brut d'un fichier de sauvegarde avant toute
 * écriture en base : un JSON malformé, un fichier d'une autre application,
 * ou une sauvegarde partiellement corrompue ne doivent jamais provoquer un
 * plantage silencieux ni insérer des lignes incomplètes en base (ex. carte
 * sans question à cause d'une contrainte NOT NULL non vérifiée).
 * Les entrées individuellement invalides sont ignorées plutôt que de faire
 * échouer tout l'import.
 */
function validateBackupData(raw: unknown): { data: BackupData; skippedSubjects: number; skippedCards: number } {
  if (!raw || typeof raw !== 'object') {
    throw new Error('Ce fichier ne contient pas une sauvegarde reconnaissable.');
  }

  const candidate = raw as Record<string, unknown>;

  if (!Array.isArray(candidate.subjects) || !Array.isArray(candidate.flashcards)) {
    throw new Error(
      'Le fichier de sauvegarde est incomplet : la liste des matières ou des cartes est manquante.'
    );
  }

  const rawSubjects = candidate.subjects as unknown[];
  const subjects: BackupSubject[] = rawSubjects.filter(
    (s): s is BackupSubject =>
      !!s &&
      typeof s === 'object' &&
      typeof (s as any).id === 'number' &&
      isNonEmptyString((s as any).name)
  );

  const rawCards = candidate.flashcards as unknown[];
  const flashcards: BackupFlashcard[] = rawCards.filter(
    (c): c is BackupFlashcard =>
      !!c &&
      typeof c === 'object' &&
      typeof (c as any).subject_id === 'number' &&
      isNonEmptyString((c as any).question) &&
      isNonEmptyString((c as any).answer)
  );

  if (subjects.length === 0 && flashcards.length === 0) {
    throw new Error('Aucune matière ni carte exploitable trouvée dans ce fichier.');
  }

  return {
    data: {
      exportedAt: isNonEmptyString(candidate.exportedAt) ? (candidate.exportedAt as string) : '',
      version: 1,
      subjects,
      flashcards,
      review_logs: Array.isArray(candidate.review_logs) ? candidate.review_logs : [],
      settings: Array.isArray(candidate.settings) ? candidate.settings : [],
    },
    skippedSubjects: rawSubjects.length - subjects.length,
    skippedCards: rawCards.length - flashcards.length,
  };
}

/**
 * Exporte toutes les données de l'application (matières, cartes, historique,
 * réglages) dans un fichier JSON, et ouvre le menu de partage natif pour
 * que l'utilisateur puisse l'enregistrer (Drive, mail, fichiers locaux...).
 */
export async function exportBackup(): Promise<void> {
  const db = await getDatabase();

  const [subjects, flashcards, review_logs, settings] = await Promise.all([
    db.getAllAsync('SELECT * FROM subjects'),
    db.getAllAsync('SELECT * FROM flashcards'),
    db.getAllAsync('SELECT * FROM review_logs'),
    db.getAllAsync('SELECT * FROM settings'),
  ]);

  const backup: BackupData = {
    exportedAt: new Date().toISOString(),
    version: 1,
    subjects,
    flashcards,
    review_logs,
    settings,
  };

  const fileName = `prepa-flashcards-backup-${new Date()
    .toISOString()
    .slice(0, 10)}.json`;
  const fileUri = FileSystem.documentDirectory + fileName;

  await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(backup, null, 2), {
    encoding: FileSystem.EncodingType.UTF8,
  });

  const canShare = await Sharing.isAvailableAsync();
  if (canShare) {
    await Sharing.shareAsync(fileUri, {
      mimeType: 'application/json',
      dialogTitle: 'Sauvegarder mes flashcards',
    });
  } else {
    throw new Error('Le partage de fichiers n\'est pas disponible sur cet appareil.');
  }
}

/**
 * Restaure une sauvegarde JSON précédemment exportée.
 * Les données existantes sont conservées ; les entrées importées s'ajoutent
 * (les ids d'origine ne sont pas réutilisés pour éviter les collisions).
 */
export async function importBackup(
  jsonContent: string
): Promise<{ subjectsAdded: number; cardsAdded: number; skippedSubjects: number; skippedCards: number }> {
  let raw: unknown;
  try {
    raw = JSON.parse(jsonContent);
  } catch {
    throw new Error(
      "Ce fichier n'est pas lisible : il est peut-être corrompu, incomplet, ou ce n'est pas une sauvegarde de l'application."
    );
  }

  const { data, skippedSubjects, skippedCards } = validateBackupData(raw);

  const db = await getDatabase();
  const subjectIdMap = new Map<number, number>();

  await db.withTransactionAsync(async () => {
    for (const s of data.subjects) {
      const result = await db.runAsync(
        `INSERT INTO subjects (name, color) VALUES (?, ?)
         ON CONFLICT(name) DO UPDATE SET name = excluded.name
         RETURNING id`,
        s.name,
        s.color ?? '#4F46E5'
      );
      // Récupère l'id (nouveau ou existant) pour remapper les cartes
      const row = await db.getFirstAsync<{ id: number }>(
        'SELECT id FROM subjects WHERE name = ?',
        s.name
      );
      if (row) subjectIdMap.set(s.id, row.id);
    }

    for (const c of data.flashcards) {
      const newSubjectId = subjectIdMap.get(c.subject_id);
      if (!newSubjectId) continue;
      await db.runAsync(
        `INSERT INTO flashcards
          (subject_id, question, answer, box, next_review_date, source_image_uri)
         VALUES (?, ?, ?, ?, ?, ?)`,
        newSubjectId,
        c.question,
        c.answer,
        c.box ?? 1,
        c.next_review_date ?? new Date().toISOString().slice(0, 10),
        c.source_image_uri ?? null
      );
    }
  });

  return {
    subjectsAdded: data.subjects.length,
    cardsAdded: data.flashcards.length,
    skippedSubjects,
    skippedCards,
  };
}
