export interface Subject {
  id: number;
  name: string;
  color: string;
  createdAt: string;
}

export interface Flashcard {
  id: number;
  subjectId: number;
  question: string;
  answer: string;
  box: number; // 1 à 5
  nextReviewDate: string; // ISO date
  createdAt: string;
  lastReviewedAt: string | null;
  successCount: number;
  failCount: number;
  sourceImageUri: string | null; // photo OCR d'origine, optionnel
  notes: string | null; // note personnelle libre (ex. "piège classique")
}

export interface ReviewLog {
  id: number;
  cardId: number;
  reviewedAt: string;
  wasSuccess: boolean;
  boxBefore: number;
  boxAfter: number;
}

// Type brut tel que renvoyé par SQLite (snake_case) avant mapping
export interface FlashcardRow {
  id: number;
  subject_id: number;
  question: string;
  answer: string;
  box: number;
  next_review_date: string;
  created_at: string;
  last_reviewed_at: string | null;
  success_count: number;
  fail_count: number;
  source_image_uri: string | null;
  notes: string | null;
}

export interface SubjectRow {
  id: number;
  name: string;
  color: string;
  created_at: string;
}
