import { useMemo } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '../theme/useTheme';
import { ThemeColors } from '../theme/colors';

interface BarChartItem {
  label: string;
  value: number;
  color?: string;
}

interface SimpleBarChartProps {
  items: BarChartItem[];
  maxHeight?: number;
  defaultColor?: string;
  emptyLabel?: string;
}

/**
 * Graphique en barres minimal, construit avec de simples View pour éviter
 * d'ajouter une dépendance de charting juste pour quelques barres. Chaque
 * barre est proportionnelle à la valeur maximale du jeu de données.
 */
export default function SimpleBarChart({
  items,
  maxHeight = 100,
  defaultColor,
  emptyLabel = 'Pas encore de données.',
}: SimpleBarChartProps) {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const barColor = defaultColor ?? theme.accent;

  const maxValue = Math.max(1, ...items.map((i) => i.value));
  const hasData = items.some((i) => i.value > 0);

  if (!hasData) {
    return <Text style={styles.emptyText}>{emptyLabel}</Text>;
  }

  return (
    <View style={styles.row}>
      {items.map((item, index) => {
        const barHeight = Math.max(3, (item.value / maxValue) * maxHeight);
        return (
          <View key={index} style={styles.column}>
            <Text style={styles.value}>{item.value > 0 ? item.value : ''}</Text>
            <View
              style={[
                styles.bar,
                { height: barHeight, backgroundColor: item.color ?? barColor },
              ]}
            />
            <Text style={styles.label} numberOfLines={1}>
              {item.label}
            </Text>
          </View>
        );
      })}
    </View>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    row: {
      flexDirection: 'row',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
    },
    column: { flex: 1, alignItems: 'center' },
    value: { fontSize: 10, color: c.textMuted, marginBottom: 2, fontWeight: '600' },
    bar: { width: '60%', borderRadius: 4, minHeight: 3 },
    label: { fontSize: 10, color: c.textFaint, marginTop: 6 },
    emptyText: { color: c.textFaint, fontSize: 13, textAlign: 'center', paddingVertical: 20 },
  });
}
