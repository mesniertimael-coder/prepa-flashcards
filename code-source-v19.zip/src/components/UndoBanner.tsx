import { useMemo } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useTheme } from '../theme/useTheme';
import { ThemeColors } from '../theme/colors';

interface UndoBannerProps {
  message: string | null;
  onUndo: () => void;
}

export default function UndoBanner({ message, onUndo }: UndoBannerProps) {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);

  if (!message) return null;

  return (
    <View style={styles.banner}>
      <Text style={styles.text} numberOfLines={2}>
        {message}
      </Text>
      <TouchableOpacity onPress={onUndo} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <Text style={styles.undo}>Annuler</Text>
      </TouchableOpacity>
    </View>
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    banner: {
      position: 'absolute',
      left: 16,
      right: 16,
      bottom: 16,
      backgroundColor: c.mode === 'dark' ? c.surfaceAlt : '#111827',
      borderRadius: 12,
      paddingVertical: 12,
      paddingHorizontal: 16,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      elevation: 4,
      borderWidth: c.mode === 'dark' ? 1 : 0,
      borderColor: c.border,
    },
    text: { color: '#fff', fontSize: 13, flex: 1, marginRight: 12 },
    undo: { color: c.mode === 'dark' ? c.accentText : '#818CF8', fontWeight: '700', fontSize: 13 },
  });
}
