import { useEffect, useMemo, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList } from 'react-native';
import { Subject } from '../types/models';
import { useTheme } from '../theme/useTheme';
import { ThemeColors } from '../theme/colors';

interface FilterItem {
  key: string;
  subjectId: number | null;
  label: string;
  count: number;
  color?: string;
}

interface SubjectFilterBarProps {
  subjects: Subject[];
  selectedSubjectId: number | null;
  onSelect: (subjectId: number | null) => void;
  countsBySubject?: Record<number, number>;
  totalCount?: number;
  allLabel?: string;
}

/**
 * Barre de filtre horizontale par matière, utilisée dans l'onglet Révision
 * et l'onglet Entraînement.
 *
 * Implémentée avec FlatList plutôt que ScrollView : un ScrollView horizontal
 * dont le contenu change de taille après le premier rendu (ex. chargement
 * asynchrone des matières) peut, sur certaines versions de React Native,
 * mal recalculer sa zone de défilement maximale et rester bloqué avant
 * d'atteindre le début de la liste. FlatList gère ce cas de façon fiable,
 * et on force en plus un retour au début dès que la liste de matières
 * change de taille (ajout/suppression), pour ne jamais rester coincé.
 */
export default function SubjectFilterBar({
  subjects,
  selectedSubjectId,
  onSelect,
  countsBySubject = {},
  totalCount = 0,
  allLabel = 'Toutes',
}: SubjectFilterBarProps) {
  const theme = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const listRef = useRef<FlatList<FilterItem>>(null);

  const data: FilterItem[] = [
    { key: 'all', subjectId: null, label: allLabel, count: totalCount },
    ...subjects.map((s) => ({
      key: String(s.id),
      subjectId: s.id,
      label: s.name,
      count: countsBySubject[s.id] ?? 0,
      color: s.color,
    })),
  ];

  useEffect(() => {
    listRef.current?.scrollToOffset({ offset: 0, animated: false });
  }, [subjects.length]);

  return (
    <FlatList
      ref={listRef}
      horizontal
      data={data}
      keyExtractor={(item) => item.key}
      showsHorizontalScrollIndicator={false}
      removeClippedSubviews={false}
      directionalLockEnabled
      bounces
      alwaysBounceHorizontal
      style={styles.scrollRow}
      contentContainerStyle={styles.filterRow}
      renderItem={({ item }) => {
        const isActive = selectedSubjectId === item.subjectId;
        return (
          <TouchableOpacity
            style={[
              styles.filterChip,
              item.color ? { borderColor: item.color } : null,
              isActive &&
                (item.color
                  ? { backgroundColor: item.color, borderColor: item.color }
                  : styles.filterChipActive),
            ]}
            onPress={() => onSelect(item.subjectId)}
            accessibilityRole="button"
            accessibilityState={{ selected: isActive }}
          >
            <Text style={[styles.filterChipText, isActive && styles.filterChipTextActive]}>
              {item.label}
              {item.count > 0 ? ` (${item.count})` : ''}
            </Text>
          </TouchableOpacity>
        );
      }}
    />
  );
}

function createStyles(c: ThemeColors) {
  return StyleSheet.create({
    scrollRow: { height: 56, justifyContent: 'center' },
    filterRow: { flexDirection: 'row', paddingHorizontal: 16 },
    filterChip: {
      borderWidth: 1.5,
      borderColor: c.border,
      borderRadius: 20,
      paddingHorizontal: 14,
      paddingVertical: 8,
      marginRight: 8,
      alignSelf: 'center',
    },
    filterChipActive: { backgroundColor: c.text, borderColor: c.text },
    filterChipText: { fontSize: 13, color: c.textMuted, fontWeight: '500' },
    filterChipTextActive: { color: c.background },
  });
}
