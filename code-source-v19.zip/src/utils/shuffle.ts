/** Mélange un tableau (Fisher-Yates) sans modifier l'original. */
export function shuffleArray<T>(array: T[]): T[] {
  const result = [...array];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

/**
 * Mélange en priorisant les cartes les plus fragiles (boîte basse) : elles
 * apparaissent plus tôt et plus souvent dans l'ordre de passage, tout en
 * gardant un peu d'aléatoire au sein de chaque boîte pour ne pas être
 * complètement prévisible. Utile en entraînement libre pour bachoter en
 * priorité ce qui n'est pas encore acquis.
 */
export function shuffleByWeakness<T extends { box: number }>(array: T[]): T[] {
  const byBox = new Map<number, T[]>();
  for (const item of array) {
    const list = byBox.get(item.box) ?? [];
    list.push(item);
    byBox.set(item.box, list);
  }

  const boxes = [...byBox.keys()].sort((a, b) => a - b);
  return boxes.flatMap((box) => shuffleArray(byBox.get(box)!));
}
