import * as Haptics from 'expo-haptics';

/**
 * Centralise les retours haptiques pour rester cohérent dans toute l'app,
 * et pour ne jamais faire planter un écran si l'API n'est pas disponible
 * sur l'appareil (simulateur, tablette sans vibreur...).
 */
function safe(fn: () => Promise<void>) {
  fn().catch(() => {
    // Pas grave si le retour haptique échoue : ce n'est jamais bloquant.
  });
}

export const haptics = {
  /** Réponse correcte en révision/entraînement, carte ou matière créée */
  success: () => safe(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)),
  /** Réponse ratée en révision */
  failure: () => safe(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning)),
  /** Suppression confirmée, action destructive */
  warning: () => safe(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning)),
  /** Sélection dans une liste, changement de filtre, bascule d'un réglage */
  selection: () => safe(() => Haptics.selectionAsync()),
  /** Appui sur un bouton d'action léger */
  tap: () => safe(() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)),
};
