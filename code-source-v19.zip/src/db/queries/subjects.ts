import { getDatabase } from '../database';
import { Subject, SubjectRow } from '../../types/models';

function mapRow(row: SubjectRow): Subject {
  return {
    id: row.id,
    name: row.name,
    color: row.color,
    createdAt: row.created_at,
  };
}

export async function getAllSubjects(): Promise<Subject[]> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<SubjectRow>(
    'SELECT * FROM subjects ORDER BY name ASC'
  );
  return rows.map(mapRow);
}

export async function getSubjectById(id: number): Promise<Subject | null> {
  const db = await getDatabase();
  const row = await db.getFirstAsync<SubjectRow>(
    'SELECT * FROM subjects WHERE id = ?',
    id
  );
  return row ? mapRow(row) : null;
}

export async function createSubject(
  name: string,
  color: string = '#4F46E5'
): Promise<number> {
  const db = await getDatabase();
  const result = await db.runAsync(
    'INSERT INTO subjects (name, color) VALUES (?, ?)',
    name.trim(),
    color
  );
  return result.lastInsertRowId;
}

export async function updateSubject(
  id: number,
  name: string,
  color: string
): Promise<void> {
  const db = await getDatabase();
  await db.runAsync(
    'UPDATE subjects SET name = ?, color = ? WHERE id = ?',
    name.trim(),
    color,
    id
  );
}

export async function deleteSubject(id: number): Promise<void> {
  const db = await getDatabase();
  // ON DELETE CASCADE supprime aussi les flashcards liées
  await db.runAsync('DELETE FROM subjects WHERE id = ?', id);
}

export async function getSubjectCardCount(subjectId: number): Promise<number> {
  const db = await getDatabase();
  const row = await db.getFirstAsync<{ total: number }>(
    'SELECT COUNT(*) as total FROM flashcards WHERE subject_id = ?',
    subjectId
  );
  return row?.total ?? 0;
}

/**
 * Nombre de cartes pour toutes les matières en une seule requête groupée,
 * à utiliser à la place d'un appel à getSubjectCardCount() par matière
 * (qui déclenche une requête SQL par matière, coûteux dès que la liste
 * s'allonge).
 */
export async function getCardCountsBySubject(): Promise<Record<number, number>> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<{ subject_id: number; total: number }>(
    'SELECT subject_id, COUNT(*) as total FROM flashcards GROUP BY subject_id'
  );
  const result: Record<number, number> = {};
  for (const row of rows) {
    result[row.subject_id] = row.total;
  }
  return result;
}
