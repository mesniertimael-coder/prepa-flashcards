import { getDatabase } from '../database';
import { Flashcard, FlashcardRow } from '../../types/models';

function mapRow(row: FlashcardRow): Flashcard {
  return {
    id: row.id,
    subjectId: row.subject_id,
    question: row.question,
    answer: row.answer,
    box: row.box,
    nextReviewDate: row.next_review_date,
    createdAt: row.created_at,
    lastReviewedAt: row.last_reviewed_at,
    successCount: row.success_count,
    failCount: row.fail_count,
    sourceImageUri: row.source_image_uri,
    notes: row.notes,
  };
}

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

export async function getAllCards(): Promise<Flashcard[]> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<FlashcardRow>(
    'SELECT * FROM flashcards ORDER BY created_at DESC'
  );
  return rows.map(mapRow);
}

export async function getCardsBySubject(subjectId: number): Promise<Flashcard[]> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<FlashcardRow>(
    'SELECT * FROM flashcards WHERE subject_id = ? ORDER BY created_at DESC',
    subjectId
  );
  return rows.map(mapRow);
}

export async function getCardById(id: number): Promise<Flashcard | null> {
  const db = await getDatabase();
  const row = await db.getFirstAsync<FlashcardRow>(
    'SELECT * FROM flashcards WHERE id = ?',
    id
  );
  return row ? mapRow(row) : null;
}

/** Cartes dont la date de révision est aujourd'hui ou dépassée */
export async function getDueCards(subjectId?: number): Promise<Flashcard[]> {
  const db = await getDatabase();
  const today = todayIso();

  const rows = subjectId
    ? await db.getAllAsync<FlashcardRow>(
        `SELECT * FROM flashcards
         WHERE subject_id = ? AND date(next_review_date) <= date(?)
         ORDER BY box ASC, next_review_date ASC`,
        subjectId,
        today
      )
    : await db.getAllAsync<FlashcardRow>(
        `SELECT * FROM flashcards
         WHERE date(next_review_date) <= date(?)
         ORDER BY box ASC, next_review_date ASC`,
        today
      );

  return rows.map(mapRow);
}

export interface CreateCardInput {
  subjectId: number;
  question: string;
  answer: string;
  sourceImageUri?: string | null;
  notes?: string | null;
}

export async function createCard(input: CreateCardInput): Promise<number> {
  const db = await getDatabase();
  const today = todayIso(); // nouvelle carte => révisable dès aujourd'hui, boîte 1

  const result = await db.runAsync(
    `INSERT INTO flashcards
      (subject_id, question, answer, box, next_review_date, source_image_uri, notes)
     VALUES (?, ?, ?, 1, ?, ?, ?)`,
    input.subjectId,
    input.question.trim(),
    input.answer.trim(),
    today,
    input.sourceImageUri ?? null,
    input.notes?.trim() || null
  );

  return result.lastInsertRowId;
}

/** Insertion multiple, utile après une extraction OCR découpée en plusieurs cartes */
export async function createCardsBatch(inputs: CreateCardInput[]): Promise<void> {
  const db = await getDatabase();
  const today = todayIso();

  await db.withTransactionAsync(async () => {
    for (const input of inputs) {
      await db.runAsync(
        `INSERT INTO flashcards
          (subject_id, question, answer, box, next_review_date, source_image_uri, notes)
         VALUES (?, ?, ?, 1, ?, ?, ?)`,
        input.subjectId,
        input.question.trim(),
        input.answer.trim(),
        today,
        input.sourceImageUri ?? null,
        input.notes?.trim() || null
      );
    }
  });
}

export async function updateCard(
  id: number,
  question: string,
  answer: string,
  notes?: string | null
): Promise<void> {
  const db = await getDatabase();
  await db.runAsync(
    'UPDATE flashcards SET question = ?, answer = ?, notes = ? WHERE id = ?',
    question.trim(),
    answer.trim(),
    notes?.trim() || null,
    id
  );
}

export async function deleteCard(id: number): Promise<void> {
  const db = await getDatabase();
  await db.runAsync('DELETE FROM flashcards WHERE id = ?', id);
}

/** Compte des cartes par boîte, pour un tableau de bord */
export async function getCardCountByBox(): Promise<Record<number, number>> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<{ box: number; total: number }>(
    'SELECT box, COUNT(*) as total FROM flashcards GROUP BY box'
  );
  const result: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  for (const row of rows) {
    result[row.box] = row.total;
  }
  return result;
}

/** Date de prochaine révision la plus proche, pour chaque boîte non vide */
export async function getNextReviewDateByBox(): Promise<Record<number, string>> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<{ box: number; nextDate: string }>(
    'SELECT box, MIN(next_review_date) as nextDate FROM flashcards GROUP BY box'
  );
  const result: Record<number, string> = {};
  for (const row of rows) {
    result[row.box] = row.nextDate;
  }
  return result;
}

export interface DailyReviewStat {
  date: string; // YYYY-MM-DD
  success: number;
  fail: number;
}

/**
 * Nombre de révisions réussies/échouées par jour, sur les `days` derniers
 * jours (aujourd'hui inclus). Les jours sans révision apparaissent à 0,
 * pour un graphique régulier.
 */
export async function getReviewStatsByDay(days: number): Promise<DailyReviewStat[]> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<{ day: string; success: number; fail: number }>(
    `SELECT
       date(reviewed_at) as day,
       SUM(CASE WHEN was_success = 1 THEN 1 ELSE 0 END) as success,
       SUM(CASE WHEN was_success = 0 THEN 1 ELSE 0 END) as fail
     FROM review_logs
     WHERE date(reviewed_at) >= date('now', ?)
     GROUP BY day`,
    `-${days - 1} days`
  );

  const byDay = new Map(rows.map((r) => [r.day, { success: r.success, fail: r.fail }]));

  const result: DailyReviewStat[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const iso = d.toISOString().slice(0, 10);
    const stat = byDay.get(iso);
    result.push({ date: iso, success: stat?.success ?? 0, fail: stat?.fail ?? 0 });
  }
  return result;
}

export interface UpcomingReviewCount {
  date: string; // YYYY-MM-DD
  count: number;
}

/**
 * Nombre de cartes dont la prochaine révision tombe sur chacun des `days`
 * prochains jours (aujourd'hui inclus), pour anticiper la charge de travail.
 * Les cartes déjà en retard (avant aujourd'hui) sont comptées dans le jour 0.
 */
export async function getUpcomingReviewCounts(days: number): Promise<UpcomingReviewCount[]> {
  const db = await getDatabase();
  const today = todayIso();
  const rows = await db.getAllAsync<{ day: string; total: number }>(
    `SELECT
       CASE WHEN date(next_review_date) < date(?) THEN date(?) ELSE date(next_review_date) END as day,
       COUNT(*) as total
     FROM flashcards
     WHERE date(next_review_date) <= date(?, ?)
     GROUP BY day`,
    today,
    today,
    today,
    `+${days - 1} days`
  );

  const byDay = new Map(rows.map((r) => [r.day, r.total]));

  const result: UpcomingReviewCount[] = [];
  for (let i = 0; i < days; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const iso = d.toISOString().slice(0, 10);
    result.push({ date: iso, count: byDay.get(iso) ?? 0 });
  }
  return result;
}
