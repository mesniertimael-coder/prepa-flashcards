import { useCallback, useEffect, useRef, useState } from 'react';

const UNDO_DELAY_MS = 4000;

/**
 * Permet de différer l'exécution réelle d'une action destructive (suppression
 * d'une carte, d'une matière...) de quelques secondes, pendant lesquelles
 * l'utilisateur peut annuler. Contrairement à une simple boîte de dialogue
 * de confirmation, cela laisse un vrai filet de rattrapage en cas de faux
 * geste, sans avoir à reconstruire les données supprimées (rien n'est
 * réellement effacé tant que le délai n'est pas écoulé).
 */
export function useUndoableAction() {
  const [pendingMessage, setPendingMessage] = useState<string | null>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cancelledRef = useRef(false);

  useEffect(() => {
    return () => {
      // Si l'écran se démonte avant la fin du délai (navigation rapide),
      // on exécute l'action tout de suite plutôt que de la perdre silencieusement.
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  const scheduleAction = useCallback((message: string, action: () => Promise<void> | void) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    cancelledRef.current = false;
    setPendingMessage(message);

    timeoutRef.current = setTimeout(async () => {
      if (!cancelledRef.current) {
        await action();
      }
      setPendingMessage(null);
      timeoutRef.current = null;
    }, UNDO_DELAY_MS);
  }, []);

  const undo = useCallback(() => {
    cancelledRef.current = true;
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setPendingMessage(null);
  }, []);

  return { pendingMessage, scheduleAction, undo };
}
