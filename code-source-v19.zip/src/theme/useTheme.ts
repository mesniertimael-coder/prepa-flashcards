import { useColorScheme } from 'react-native';
import { lightColors, darkColors, ThemeColors } from './colors';

/**
 * Suit automatiquement le mode clair/sombre du système (cohérent avec
 * `userInterfaceStyle: "automatic"` déclaré dans app.json). Pas de bascule
 * manuelle dans l'app pour l'instant : le thème suit uniquement le réglage
 * de l'appareil.
 */
export function useTheme(): ThemeColors {
  const scheme = useColorScheme();
  return scheme === 'dark' ? darkColors : lightColors;
}
