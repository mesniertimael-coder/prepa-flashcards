export interface ThemeColors {
  mode: 'light' | 'dark';
  background: string;
  surface: string;
  surfaceAlt: string; // fond de puce/input
  text: string;
  textMuted: string;
  textFaint: string;
  border: string;
  accent: string; // couleur de marque (boutons pleins)
  accentText: string; // même teinte, utilisée en texte/lien
  onAccent: string; // couleur du texte posé sur un fond `accent`
  danger: string;
  dangerSoft: string;
  dangerText: string;
  success: string;
  successSoft: string;
  warningSoft: string;
  warningBorder: string;
  warningLabel: string;
  warningText: string;
  overlay: string;
}

export const lightColors: ThemeColors = {
  mode: 'light',
  background: '#F9FAFB',
  surface: '#FFFFFF',
  surfaceAlt: '#F3F4F6',
  text: '#111827',
  textMuted: '#6B7280',
  textFaint: '#9CA3AF',
  border: '#E5E7EB',
  accent: '#4F46E5',
  accentText: '#4F46E5',
  onAccent: '#FFFFFF',
  danger: '#EF4444',
  dangerSoft: '#FEE2E2',
  dangerText: '#B91C1C',
  success: '#10B981',
  successSoft: '#D1FAE5',
  warningSoft: '#FFFBEB',
  warningBorder: '#FDE68A',
  warningLabel: '#B45309',
  warningText: '#78350F',
  overlay: 'rgba(0,0,0,0.4)',
};

export const darkColors: ThemeColors = {
  mode: 'dark',
  background: '#0B0F19',
  surface: '#161B26',
  surfaceAlt: '#1F2430',
  text: '#F3F4F6',
  textMuted: '#9CA3AF',
  textFaint: '#6B7280',
  border: '#2D3341',
  accent: '#6366F1',
  accentText: '#A5B4FC',
  onAccent: '#FFFFFF',
  danger: '#F87171',
  dangerSoft: '#3F1D1D',
  dangerText: '#FCA5A5',
  success: '#34D399',
  successSoft: '#0F3D2E',
  warningSoft: '#3A2C0F',
  warningBorder: '#78350F',
  warningLabel: '#FBBF24',
  warningText: '#FDE68A',
  overlay: 'rgba(0,0,0,0.6)',
};
