import { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useRouter, useLocalSearchParams, Stack } from 'expo-router';
import { getAllSubjects } from '../../src/db/queries/subjects';
import { createCard } from '../../src/db/queries/cards';
import { Subject } from '../../src/types/models';
import VoiceInputWebView, { VoiceInputHandle } from '../../src/components/VoiceInputWebView';

type ActiveField = 'question' | 'answer' | null;

export default function VoiceCreateScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ subjectId?: string }>();
  const voiceRef = useRef<VoiceInputHandle>(null);

  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [listening, setListening] = useState(false);
  const [activeField, setActiveField] = useState<ActiveField>(null);
  const [saving, setSaving] = useState(false);

  const activeFieldRef = useRef<ActiveField>(null);
  useEffect(() => {
    activeFieldRef.current = activeField;
  }, [activeField]);

  useEffect(() => {
    getAllSubjects().then((data) => {
      setSubjects(data);
      if (params.subjectId) {
        setSelectedSubjectId(Number(params.subjectId));
      } else if (data.length > 0) {
        setSelectedSubjectId(data[0].id);
      }
    });
  }, []);

  const handleResult = (text: string) => {
    if (activeFieldRef.current === 'question') setQuestion(text);
    else if (activeFieldRef.current === 'answer') setAnswer(text);
  };

  const handleEnd = () => setListening(false);

  const handleError = (error: string) => {
    setListening(false);
    if (error === 'not_supported') {
      Alert.alert('Non disponible', "La reconnaissance vocale n'est pas disponible sur cet appareil.");
    } else if (error === 'not-allowed' || error === 'permission-denied') {
      Alert.alert('Micro refusé', "Autorise le micro pour utiliser la dictée vocale.");
    } else if (error !== 'no-speech' && error !== 'aborted') {
      console.error('Voice error:', error);
    }
  };

  const startListening = (field: ActiveField) => {
    setActiveField(field);
    setListening(true);
    voiceRef.current?.start();
  };

  const stopListening = () => {
    voiceRef.current?.stop();
    setListening(false);
  };

  const handleSave = async () => {
    if (!selectedSubjectId) {
      Alert.alert('Matière requise', 'Choisis une matière pour la carte.');
      return;
    }
    if (!question.trim() || !answer.trim()) {
      Alert.alert('Champs manquants', 'Dicte ou écris la question et la réponse.');
      return;
    }
    try {
      setSaving(true);
      await createCard({ subjectId: selectedSubjectId, question, answer });
      router.back();
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', "La carte n'a pas pu être enregistrée.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Stack.Screen options={{ title: 'Créer par la voix', headerShown: true }} />

      <VoiceInputWebView
        ref={voiceRef}
        onResult={handleResult}
        onEnd={handleEnd}
        onError={handleError}
      />

      <Text style={styles.label}>Matière</Text>
      <View style={styles.chipRow}>
        {subjects.map((s) => (
          <TouchableOpacity
            key={s.id}
            style={[
              styles.chip,
              { borderColor: s.color },
              selectedSubjectId === s.id && { backgroundColor: s.color },
            ]}
            onPress={() => setSelectedSubjectId(s.id)}
          >
            <Text
              style={[styles.chipText, selectedSubjectId === s.id && { color: '#fff' }]}
            >
              {s.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Question</Text>
      <TextInput
        style={styles.input}
        multiline
        value={question}
        onChangeText={setQuestion}
        placeholder="Dicte ou écris la question"
      />
      <TouchableOpacity
        style={[
          styles.micButton,
          listening && activeField === 'question' && styles.micButtonActive,
        ]}
        onPress={() =>
          listening && activeField === 'question' ? stopListening() : startListening('question')
        }
      >
        <Text style={styles.micButtonText}>
          {listening && activeField === 'question' ? '⏹ Arrêter' : '🎙️ Dicter la question'}
        </Text>
      </TouchableOpacity>

      <Text style={styles.label}>Réponse</Text>
      <TextInput
        style={styles.input}
        multiline
        value={answer}
        onChangeText={setAnswer}
        placeholder="Dicte ou écris la réponse"
      />
      <TouchableOpacity
        style={[
          styles.micButton,
          listening && activeField === 'answer' && styles.micButtonActive,
        ]}
        onPress={() =>
          listening && activeField === 'answer' ? stopListening() : startListening('answer')
        }
      >
        <Text style={styles.micButtonText}>
          {listening && activeField === 'answer' ? '⏹ Arrêter' : '🎙️ Dicter la réponse'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.saveButton, saving && { opacity: 0.6 }]}
        onPress={handleSave}
        disabled={saving}
      >
        <Text style={styles.saveButtonText}>
          {saving ? 'Enregistrement…' : 'Enregistrer la carte'}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8, marginTop: 16 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap' },
  chip: {
    borderWidth: 1.5,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginRight: 8,
    marginBottom: 8,
  },
  chipText: { fontSize: 13, color: '#374151', fontWeight: '500' },
  input: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 10,
    padding: 12,
    fontSize: 15,
    minHeight: 70,
    textAlignVertical: 'top',
    marginBottom: 8,
  },
  micButton: {
    backgroundColor: '#EEF2FF',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
  },
  micButtonActive: { backgroundColor: '#FEE2E2' },
  micButtonText: { color: '#4F46E5', fontWeight: '700', fontSize: 13 },
  saveButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 40,
  },
  saveButtonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
