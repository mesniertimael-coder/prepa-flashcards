import { useCallback, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { getCardCountByBox, getNextReviewDateByBox } from '../../src/db/queries/cards';
import { getAllSubjects, getSubjectCardCount } from '../../src/db/queries/subjects';
import { BOX_LABELS, MAX_BOX } from '../../src/constants/leitner';
import { Subject } from '../../src/types/models';
import { formatReviewDate } from '../../src/utils/date';

const BOX_COLORS: Record<number, string> = {
  1: '#EF4444',
  2: '#F59E0B',
  3: '#EAB308',
  4: '#84CC16',
  5: '#10B981',
};

export default function StatsScreen() {
  const [counts, setCounts] = useState<Record<number, number>>({});
  const [nextDates, setNextDates] = useState<Record<number, string>>({});
  const [subjects, setSubjects] = useState<(Subject & { cardCount: number })[]>([]);

  const load = useCallback(async () => {
    const [byBox, byBoxDates, allSubjects] = await Promise.all([
      getCardCountByBox(),
      getNextReviewDateByBox(),
      getAllSubjects(),
    ]);
    setCounts(byBox);
    setNextDates(byBoxDates);
    const withCounts = await Promise.all(
      allSubjects.map(async (s) => ({ ...s, cardCount: await getSubjectCardCount(s.id) }))
    );
    setSubjects(withCounts);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const totalCards = Object.values(counts).reduce((a, b) => a + b, 0);
  const mastered = counts[MAX_BOX] ?? 0;
  const masteredPercent = totalCards > 0 ? Math.round((mastered / totalCards) * 100) : 0;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <View style={styles.summaryCard}>
        <Text style={styles.summaryNumber}>{masteredPercent}%</Text>
        <Text style={styles.summaryLabel}>
          de tes {totalCards} carte{totalCards !== 1 ? 's' : ''} sont maîtrisées (boîte 5)
        </Text>
      </View>

      <Text style={styles.sectionTitle}>Répartition par boîte</Text>
      <View style={styles.card}>
        {Object.entries(BOX_LABELS).map(([box, label]) => {
          const boxNum = Number(box);
          const count = counts[boxNum] ?? 0;
          const percent = totalCards > 0 ? (count / totalCards) * 100 : 0;
          return (
            <View key={box} style={styles.boxRow}>
              <View style={styles.boxRowHeader}>
                <Text style={styles.boxLabel}>{label}</Text>
                <Text style={styles.boxValue}>{count}</Text>
              </View>
              <View style={styles.barTrack}>
                <View
                  style={[
                    styles.barFill,
                    { width: `${percent}%`, backgroundColor: BOX_COLORS[boxNum] },
                  ]}
                />
              </View>
              {count > 0 && nextDates[boxNum] && (
                <Text style={styles.boxDate}>
                  Prochaine ouverture : {formatReviewDate(nextDates[boxNum])}
                </Text>
              )}
            </View>
          );
        })}
      </View>

      <Text style={styles.sectionTitle}>Par matière</Text>
      <View style={styles.card}>
        {subjects.map((s) => (
          <View key={s.id} style={styles.subjectRow}>
            <View style={[styles.subjectDot, { backgroundColor: s.color }]} />
            <Text style={styles.subjectName}>{s.name}</Text>
            <Text style={styles.subjectCount}>{s.cardCount}</Text>
          </View>
        ))}
        {subjects.length === 0 && (
          <Text style={styles.empty}>Aucune matière pour le moment.</Text>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  summaryCard: {
    backgroundColor: '#4F46E5',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
  },
  summaryNumber: { fontSize: 40, fontWeight: '800', color: '#fff' },
  summaryLabel: { fontSize: 13, color: '#E0E7FF', textAlign: 'center', marginTop: 6 },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: '#6B7280',
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    elevation: 1,
  },
  boxRow: { marginBottom: 14 },
  boxRowHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  boxLabel: { fontSize: 13, color: '#374151', fontWeight: '500' },
  boxValue: { fontSize: 13, color: '#111827', fontWeight: '700' },
  barTrack: {
    height: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 4,
    overflow: 'hidden',
  },
  barFill: { height: '100%', borderRadius: 4 },
  boxDate: { fontSize: 11, color: '#9CA3AF', marginTop: 4 },
  subjectRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  subjectDot: { width: 10, height: 10, borderRadius: 5, marginRight: 10 },
  subjectName: { flex: 1, fontSize: 14, color: '#111827' },
  subjectCount: { fontSize: 14, color: '#6B7280', fontWeight: '600' },
  empty: { textAlign: 'center', color: '#6B7280', paddingVertical: 12 },
});
