import { useState, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import {
  getAllSubjects,
  getSubjectCardCount,
  createSubject,
} from '../../src/db/queries/subjects';
import { Subject } from '../../src/types/models';

interface SubjectWithCount extends Subject {
  cardCount: number;
}

const COLOR_PALETTE = [
  '#4F46E5', '#0EA5E9', '#10B981', '#F59E0B',
  '#EF4444', '#8B5CF6', '#EC4899', '#14B8A6',
];

export default function SubjectsScreen() {
  const [subjects, setSubjects] = useState<SubjectWithCount[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [actionMenuVisible, setActionMenuVisible] = useState(false);
  const [newName, setNewName] = useState('');
  const [newColor, setNewColor] = useState(COLOR_PALETTE[0]);
  const [saving, setSaving] = useState(false);
  const router = useRouter();

  const load = useCallback(async () => {
    const data = await getAllSubjects();
    const withCounts = await Promise.all(
      data.map(async (s) => ({
        ...s,
        cardCount: await getSubjectCardCount(s.id),
      }))
    );
    setSubjects(withCounts);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const openAddModal = () => {
    setNewName('');
    setNewColor(COLOR_PALETTE[Math.floor(Math.random() * COLOR_PALETTE.length)]);
    setModalVisible(true);
  };

  const handleCreateSubject = async () => {
    if (!newName.trim()) {
      Alert.alert('Nom requis', 'Donne un nom à la matière.');
      return;
    }
    try {
      setSaving(true);
      await createSubject(newName, newColor);
      setModalVisible(false);
      load();
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', 'Cette matière existe peut-être déjà.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={subjects}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 16, paddingBottom: 110 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.card, { borderLeftColor: item.color }]}
            onPress={() => router.push(`/subject/${item.id}`)}
          >
            <Text style={styles.cardTitle}>{item.name}</Text>
            <Text style={styles.cardCount}>
              {item.cardCount} carte{item.cardCount !== 1 ? 's' : ''}
            </Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <Text style={styles.empty}>Aucune matière pour le moment.</Text>
        }
        ListHeaderComponent={
          <TouchableOpacity style={styles.addSubjectButton} onPress={openAddModal}>
            <Text style={styles.addSubjectButtonText}>+ Ajouter une matière</Text>
          </TouchableOpacity>
        }
      />

      <View style={styles.fabRow}>
        <TouchableOpacity style={styles.fab} onPress={() => setActionMenuVisible(true)}>
          <Text style={styles.fabText}>+ Nouvelle carte</Text>
        </TouchableOpacity>
      </View>

      <Modal visible={actionMenuVisible} animationType="fade" transparent>
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setActionMenuVisible(false)}
        >
          <View style={styles.actionMenuBox}>
            <TouchableOpacity
              style={styles.actionMenuItem}
              onPress={() => {
                setActionMenuVisible(false);
                router.push('/card/create');
              }}
            >
              <Text style={styles.actionMenuIcon}>✏️</Text>
              <View style={styles.actionMenuTextBlock}>
                <Text style={styles.actionMenuTitle}>Saisir manuellement</Text>
                <Text style={styles.actionMenuSubtitle}>Écrire une question/réponse toi-même</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionMenuItem}
              onPress={() => {
                setActionMenuVisible(false);
                router.push('/card/ocr-capture');
              }}
            >
              <Text style={styles.actionMenuIcon}>📷</Text>
              <View style={styles.actionMenuTextBlock}>
                <Text style={styles.actionMenuTitle}>Scanner une photo</Text>
                <Text style={styles.actionMenuSubtitle}>Cours manuscrit ou imprimé</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionMenuItem}
              onPress={() => {
                setActionMenuVisible(false);
                router.push('/card/voice-create');
              }}
            >
              <Text style={styles.actionMenuIcon}>🎙️</Text>
              <View style={styles.actionMenuTextBlock}>
                <Text style={styles.actionMenuTitle}>Créer par la voix</Text>
                <Text style={styles.actionMenuSubtitle}>Dicter la question et la réponse</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionMenuItem}
              onPress={() => {
                setActionMenuVisible(false);
                router.push('/card/import-document');
              }}
            >
              <Text style={styles.actionMenuIcon}>📄</Text>
              <View style={styles.actionMenuTextBlock}>
                <Text style={styles.actionMenuTitle}>Importer un document</Text>
                <Text style={styles.actionMenuSubtitle}>Fichier PDF, Word ou texte</Text>
              </View>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Nouvelle matière</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Ex : SVT"
              value={newName}
              onChangeText={setNewName}
              autoFocus
            />
            <Text style={styles.modalLabel}>Couleur</Text>
            <View style={styles.colorRow}>
              {COLOR_PALETTE.map((c) => (
                <TouchableOpacity
                  key={c}
                  style={[
                    styles.colorSwatch,
                    { backgroundColor: c },
                    newColor === c && styles.colorSwatchSelected,
                  ]}
                  onPress={() => setNewColor(c)}
                />
              ))}
            </View>
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.modalCancelText}>Annuler</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalSaveButton, saving && { opacity: 0.6 }]}
                onPress={handleCreateSubject}
                disabled={saving}
              >
                <Text style={styles.modalSaveText}>Créer</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 16,
    marginBottom: 10,
    borderLeftWidth: 5,
    elevation: 1,
  },
  cardTitle: { fontSize: 16, fontWeight: '600', color: '#111827' },
  cardCount: { fontSize: 13, color: '#6B7280', marginTop: 4 },
  empty: { textAlign: 'center', marginTop: 40, color: '#6B7280' },
  addSubjectButton: {
    borderWidth: 1.5,
    borderColor: '#4F46E5',
    borderStyle: 'dashed',
    borderRadius: 10,
    padding: 14,
    alignItems: 'center',
    marginBottom: 14,
  },
  addSubjectButtonText: { color: '#4F46E5', fontWeight: '600' },
  fabRow: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    left: 24,
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  fab: {
    backgroundColor: '#4F46E5',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 30,
    elevation: 3,
    marginLeft: 10,
  },
  fabSecondary: { backgroundColor: '#0EA5E9' },
  fabText: { color: '#fff', fontWeight: '600' },
  actionMenuBox: {
    position: 'absolute',
    bottom: 90,
    right: 24,
    left: 24,
    backgroundColor: '#fff',
    borderRadius: 16,
    paddingVertical: 8,
    elevation: 6,
  },
  actionMenuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
  },
  actionMenuIcon: { fontSize: 24, marginRight: 14 },
  actionMenuTextBlock: { flex: 1 },
  actionMenuTitle: { fontSize: 15, fontWeight: '600', color: '#111827' },
  actionMenuSubtitle: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'flex-end',
  },
  modalBox: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 24,
  },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#111827', marginBottom: 16 },
  modalInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 10,
    padding: 12,
    fontSize: 15,
    marginBottom: 16,
  },
  modalLabel: { fontSize: 13, fontWeight: '600', color: '#374151', marginBottom: 10 },
  colorRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 24 },
  colorSwatch: {
    width: 36,
    height: 36,
    borderRadius: 18,
    marginRight: 10,
    marginBottom: 10,
  },
  colorSwatchSelected: { borderWidth: 3, borderColor: '#111827' },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end' },
  modalCancelButton: { paddingVertical: 12, paddingHorizontal: 16 },
  modalCancelText: { color: '#6B7280', fontWeight: '600' },
  modalSaveButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 20,
  },
  modalSaveText: { color: '#fff', fontWeight: '700' },
});
