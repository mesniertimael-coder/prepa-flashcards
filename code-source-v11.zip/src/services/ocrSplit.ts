export interface CardDraft {
  id: string;
  question: string;
  answer: string;
  include: boolean;
}

const QUESTION_MARKER = /^(q\s*[:.)]|question\s*[:.]|Q\d*\s*[:.)]|^\d+[.)]\s*)/i;
const ANSWER_MARKER = /^(r\s*[:.)]|réponse\s*[:.]|reponse\s*[:.]|a\s*[:.)]|answer\s*[:.]|R\d*\s*[:.)])/i;
const BULLET_MARKER = /^[-•*▪]\s*/;
const NUMBERED_MARKER = /^\d+[.)]\s*/;

// "Terme : Définition" ou "Terme - Définition" sur une seule ligne
// (format très fréquent dans les notes de cours / listes de vocabulaire).
// Le séparateur doit avoir du texte substantiel des deux côtés pour éviter
// les faux positifs (ex : une heure "14:30" ou un numéro de question "1)").
const TERM_DEFINITION_SEPARATOR = /\s+[:–—-]\s+|\s*:\s+/;

let draftCounter = 0;
function nextId(prefix: string): string {
  draftCounter += 1;
  return `${prefix}-${draftCounter}`;
}

/**
 * Tente de transformer un bloc de texte brut (issu de l'OCR ou d'un document
 * importé) en plusieurs cartes Question/Réponse, en essayant plusieurs
 * stratégies par ordre de fiabilité décroissante. Le résultat est toujours
 * éditable par l'utilisateur avant sauvegarde : ce découpage est une aide,
 * pas une vérité absolue.
 */
export function splitOcrTextIntoCards(rawText: string): CardDraft[] {
  const lines = rawText
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length === 0) return [];

  // Stratégie 1 : marqueurs explicites Q:/R: ou Question:/Réponse:
  const explicit = tryExplicitQRPairing(lines);
  if (explicit.length > 0) return explicit;

  // Stratégie 2 : "Terme : Définition" sur une seule ligne
  const termDefinition = tryTermDefinitionSplit(lines);
  if (termDefinition.length >= Math.max(2, Math.ceil(lines.length / 2))) {
    return termDefinition;
  }

  // Stratégie 3 : liste à puces ou numérotée -> une carte par ligne
  // (question = ligne, réponse à compléter par l'utilisateur)
  const listLikeCount = lines.filter(
    (l) => BULLET_MARKER.test(l) || NUMBERED_MARKER.test(l)
  ).length;
  if (listLikeCount >= Math.max(2, Math.ceil(lines.length / 2))) {
    return lines.map((l) => ({
      id: nextId('list'),
      question: l.replace(BULLET_MARKER, '').replace(NUMBERED_MARKER, '').trim(),
      answer: '',
      include: true,
    }));
  }

  // Stratégie 4 (repli) : associe les lignes deux par deux
  // (ligne 1 = question, ligne 2 = réponse, etc.)
  const paired: CardDraft[] = [];
  for (let i = 0; i < lines.length; i += 2) {
    paired.push({
      id: nextId('pair'),
      question: lines[i],
      answer: lines[i + 1] ?? '',
      include: true,
    });
  }
  return paired;
}

function tryExplicitQRPairing(lines: string[]): CardDraft[] {
  const cards: CardDraft[] = [];
  let currentQuestion: string | null = null;

  for (const line of lines) {
    if (QUESTION_MARKER.test(line) && !ANSWER_MARKER.test(line)) {
      currentQuestion = line.replace(QUESTION_MARKER, '').trim();
    } else if (ANSWER_MARKER.test(line) && currentQuestion) {
      const answer = line.replace(ANSWER_MARKER, '').trim();
      cards.push({ id: nextId('qr'), question: currentQuestion, answer, include: true });
      currentQuestion = null;
    }
  }

  return cards;
}

function tryTermDefinitionSplit(lines: string[]): CardDraft[] {
  const cards: CardDraft[] = [];

  for (const line of lines) {
    // Ignore les lignes ressemblant à une heure (14:30) ou une numérotation (1) / 1.)
    if (/^\d{1,2}:\d{2}/.test(line) || NUMBERED_MARKER.test(line)) continue;

    const match = line.split(TERM_DEFINITION_SEPARATOR);
    if (match.length < 2) continue;

    const term = match[0].trim();
    const definition = match.slice(1).join(' ').trim();

    // Filtre les faux positifs : les deux côtés doivent contenir du texte
    // substantiel (pas juste une lettre ou un chiffre isolé).
    if (term.length >= 2 && definition.length >= 2) {
      cards.push({ id: nextId('td'), question: term, answer: definition, include: true });
    }
  }

  return cards;
}
