/**
 * Formate une date ISO (YYYY-MM-DD) en texte lisible et relatif :
 * "Aujourd'hui", "Demain", ou "12 sept."
 */
export function formatReviewDate(isoDate: string): string {
  const target = new Date(isoDate + 'T00:00:00');
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const diffDays = Math.round((target.getTime() - today.getTime()) / 86400000);

  if (diffDays <= 0) return "Aujourd'hui";
  if (diffDays === 1) return 'Demain';

  const months = [
    'jan.', 'fév.', 'mars', 'avr.', 'mai', 'juin',
    'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.',
  ];
  return `${target.getDate()} ${months[target.getMonth()]}`;
}
