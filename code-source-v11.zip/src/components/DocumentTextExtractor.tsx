import { useEffect, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';
import * as FileSystem from 'expo-file-system/legacy';

interface Props {
  fileUri: string;
  fileType: 'pdf' | 'docx';
  onExtracted: (text: string) => void;
  onError: (error: string) => void;
}

/**
 * Composant invisible : lit un fichier PDF ou DOCX local, l'encode en base64,
 * puis délègue l'extraction du texte à une WebView chargeant pdf.js (PDF)
 * ou mammoth.js (DOCX) depuis un CDN. Le résultat revient via postMessage.
 */
export default function DocumentTextExtractor({
  fileUri,
  fileType,
  onExtracted,
  onError,
}: Props) {
  const [html, setHtml] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const base64 = await FileSystem.readAsStringAsync(fileUri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        if (cancelled) return;
        setHtml(fileType === 'pdf' ? buildPdfHtml(base64) : buildDocxHtml(base64));
      } catch (err) {
        onError(String(err));
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fileUri, fileType]);

  if (!html) return null;

  return (
    <View style={styles.hidden}>
      <WebView
        originWhitelist={['*']}
        source={{ html }}
        javaScriptEnabled
        onMessage={(e) => {
          try {
            const data = JSON.parse(e.nativeEvent.data);
            if (data.ok) onExtracted(data.text);
            else onError(data.error ?? 'Erreur inconnue');
          } catch {
            onError('Réponse invalide du lecteur de document.');
          }
        }}
      />
    </View>
  );
}

function buildPdfHtml(base64: string): string {
  return `<!DOCTYPE html>
<html><head>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
</head><body>
<script>
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  (async function () {
    try {
      var base64 = ${JSON.stringify(base64)};
      var raw = atob(base64);
      var bytes = new Uint8Array(raw.length);
      for (var i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
      var pdf = await pdfjsLib.getDocument({ data: bytes }).promise;
      var fullText = '';
      for (var p = 1; p <= pdf.numPages; p++) {
        var page = await pdf.getPage(p);
        var content = await page.getTextContent();
        var strings = content.items.map(function (it) { return it.str; });
        fullText += strings.join(' ') + '\\n\\n';
      }
      window.ReactNativeWebView.postMessage(JSON.stringify({ ok: true, text: fullText }));
    } catch (e) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ok: false, error: String(e) }));
    }
  })();
</script>
</body></html>`;
}

function buildDocxHtml(base64: string): string {
  return `<!DOCTYPE html>
<html><head>
<script src="https://cdn.jsdelivr.net/npm/mammoth/mammoth.browser.min.js"></script>
</head><body>
<script>
  (async function () {
    try {
      var base64 = ${JSON.stringify(base64)};
      var raw = atob(base64);
      var bytes = new Uint8Array(raw.length);
      for (var i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
      var result = await mammoth.extractRawText({ arrayBuffer: bytes.buffer });
      window.ReactNativeWebView.postMessage(JSON.stringify({ ok: true, text: result.value }));
    } catch (e) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ok: false, error: String(e) }));
    }
  })();
</script>
</body></html>`;
}

const styles = StyleSheet.create({
  hidden: { width: 1, height: 1, opacity: 0, position: 'absolute' },
});
