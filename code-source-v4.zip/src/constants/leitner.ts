// Intervalles en jours pour chaque boîte de Leitner
export const LEITNER_INTERVALS: Record<number, number> = {
  1: 1,
  2: 2,
  3: 5,
  4: 10,
  5: 30,
};

export const MAX_BOX = 5;
export const MIN_BOX = 1;

export const BOX_LABELS: Record<number, string> = {
  1: 'Boîte 1 (J+1)',
  2: 'Boîte 2 (J+2)',
  3: 'Boîte 3 (J+5)',
  4: 'Boîte 4 (J+10)',
  5: 'Boîte 5 (J+30)',
};
