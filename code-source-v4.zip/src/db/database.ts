import * as SQLite from 'expo-sqlite';

const DB_NAME = 'prepa_flashcards.db';

let dbInstance: SQLite.SQLiteDatabase | null = null;

export async function getDatabase(): Promise<SQLite.SQLiteDatabase> {
  if (dbInstance) return dbInstance;
  dbInstance = await SQLite.openDatabaseAsync(DB_NAME);
  return dbInstance;
}

export async function initDatabase(): Promise<void> {
  const db = await getDatabase();

  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      color TEXT NOT NULL DEFAULT '#4F46E5',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS flashcards (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL,
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      box INTEGER NOT NULL DEFAULT 1,
      next_review_date TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      last_reviewed_at TEXT,
      success_count INTEGER NOT NULL DEFAULT 0,
      fail_count INTEGER NOT NULL DEFAULT 0,
      source_image_uri TEXT,
      FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS review_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      card_id INTEGER NOT NULL,
      reviewed_at TEXT NOT NULL DEFAULT (datetime('now')),
      was_success INTEGER NOT NULL,
      box_before INTEGER NOT NULL,
      box_after INTEGER NOT NULL,
      FOREIGN KEY (card_id) REFERENCES flashcards(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_flashcards_next_review ON flashcards(next_review_date);
    CREATE INDEX IF NOT EXISTS idx_flashcards_subject ON flashcards(subject_id);
  `);

  await seedDefaultSubjects(db);
}

async function seedDefaultSubjects(db: SQLite.SQLiteDatabase): Promise<void> {
  const count = await db.getFirstAsync<{ total: number }>(
    'SELECT COUNT(*) as total FROM subjects'
  );
  if (count && count.total > 0) return;

  const defaults = [
    { name: 'Mathématiques', color: '#4F46E5' },
    { name: 'Physique', color: '#0EA5E9' },
    { name: 'Chimie', color: '#10B981' },
    { name: 'Français/Philo', color: '#F59E0B' },
    { name: 'Anglais', color: '#EF4444' },
  ];

  for (const s of defaults) {
    await db.runAsync(
      'INSERT INTO subjects (name, color) VALUES (?, ?)',
      s.name,
      s.color
    );
  }
}

/** Utilitaire : réinitialise complètement la base (dev only) */
export async function resetDatabase(): Promise<void> {
  const db = await getDatabase();
  await db.execAsync(`
    DROP TABLE IF EXISTS review_logs;
    DROP TABLE IF EXISTS flashcards;
    DROP TABLE IF EXISTS subjects;
  `);
  await initDatabase();
}
