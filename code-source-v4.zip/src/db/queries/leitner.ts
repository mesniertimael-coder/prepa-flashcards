import { getDatabase } from '../database';
import { getCardById } from './cards';
import { LEITNER_INTERVALS, MAX_BOX, MIN_BOX } from '../../constants/leitner';

export interface ReviewResult {
  cardId: number;
  boxBefore: number;
  boxAfter: number;
  nextReviewDate: string;
}

function addDaysIso(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10); // format YYYY-MM-DD, comparable en SQL
}

/**
 * Applique le résultat d'une révision selon l'algorithme des boîtes de Leitner :
 * - Succès  -> passage à la boîte N+1 (plafonnée à la boîte 5)
 * - Échec   -> retour immédiat à la boîte 1
 * Met à jour la carte et journalise l'événement dans review_logs.
 */
export async function applyReviewResult(
  cardId: number,
  wasSuccess: boolean
): Promise<ReviewResult> {
  const db = await getDatabase();
  const card = await getCardById(cardId);
  if (!card) {
    throw new Error(`Carte introuvable (id: ${cardId})`);
  }

  const boxBefore = card.box;
  const boxAfter = wasSuccess
    ? Math.min(boxBefore + 1, MAX_BOX)
    : MIN_BOX;

  const interval = LEITNER_INTERVALS[boxAfter];
  const nextReviewDate = addDaysIso(interval);
  const now = new Date().toISOString();

  await db.withTransactionAsync(async () => {
    await db.runAsync(
      `UPDATE flashcards
       SET box = ?,
           next_review_date = ?,
           last_reviewed_at = ?,
           success_count = success_count + ?,
           fail_count = fail_count + ?
       WHERE id = ?`,
      boxAfter,
      nextReviewDate,
      now,
      wasSuccess ? 1 : 0,
      wasSuccess ? 0 : 1,
      cardId
    );

    await db.runAsync(
      `INSERT INTO review_logs (card_id, was_success, box_before, box_after)
       VALUES (?, ?, ?, ?)`,
      cardId,
      wasSuccess ? 1 : 0,
      boxBefore,
      boxAfter
    );
  });

  return { cardId, boxBefore, boxAfter, nextReviewDate };
}

/** Historique des révisions d'une carte donnée, du plus récent au plus ancien */
export async function getCardReviewHistory(cardId: number) {
  const db = await getDatabase();
  return db.getAllAsync(
    `SELECT * FROM review_logs WHERE card_id = ? ORDER BY reviewed_at DESC`,
    cardId
  );
}
