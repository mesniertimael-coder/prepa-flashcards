import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { getDatabase } from '../db/database';

interface BackupData {
  exportedAt: string;
  version: 1;
  subjects: any[];
  flashcards: any[];
  review_logs: any[];
  settings: any[];
}

/**
 * Exporte toutes les données de l'application (matières, cartes, historique,
 * réglages) dans un fichier JSON, et ouvre le menu de partage natif pour
 * que l'utilisateur puisse l'enregistrer (Drive, mail, fichiers locaux...).
 */
export async function exportBackup(): Promise<void> {
  const db = await getDatabase();

  const [subjects, flashcards, review_logs, settings] = await Promise.all([
    db.getAllAsync('SELECT * FROM subjects'),
    db.getAllAsync('SELECT * FROM flashcards'),
    db.getAllAsync('SELECT * FROM review_logs'),
    db.getAllAsync('SELECT * FROM settings'),
  ]);

  const backup: BackupData = {
    exportedAt: new Date().toISOString(),
    version: 1,
    subjects,
    flashcards,
    review_logs,
    settings,
  };

  const fileName = `prepa-flashcards-backup-${new Date()
    .toISOString()
    .slice(0, 10)}.json`;
  const fileUri = FileSystem.documentDirectory + fileName;

  await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(backup, null, 2), {
    encoding: FileSystem.EncodingType.UTF8,
  });

  const canShare = await Sharing.isAvailableAsync();
  if (canShare) {
    await Sharing.shareAsync(fileUri, {
      mimeType: 'application/json',
      dialogTitle: 'Sauvegarder mes flashcards',
    });
  } else {
    throw new Error('Le partage de fichiers n\'est pas disponible sur cet appareil.');
  }
}

/**
 * Restaure une sauvegarde JSON précédemment exportée.
 * Les données existantes sont conservées ; les entrées importées s'ajoutent
 * (les ids d'origine ne sont pas réutilisés pour éviter les collisions).
 */
export async function importBackup(jsonContent: string): Promise<{ subjectsAdded: number; cardsAdded: number }> {
  const data: BackupData = JSON.parse(jsonContent);
  if (!data.subjects || !data.flashcards) {
    throw new Error('Fichier de sauvegarde invalide.');
  }

  const db = await getDatabase();
  const subjectIdMap = new Map<number, number>();

  await db.withTransactionAsync(async () => {
    for (const s of data.subjects) {
      const result = await db.runAsync(
        `INSERT INTO subjects (name, color) VALUES (?, ?)
         ON CONFLICT(name) DO UPDATE SET name = excluded.name
         RETURNING id`,
        s.name,
        s.color
      );
      // Récupère l'id (nouveau ou existant) pour remapper les cartes
      const row = await db.getFirstAsync<{ id: number }>(
        'SELECT id FROM subjects WHERE name = ?',
        s.name
      );
      if (row) subjectIdMap.set(s.id, row.id);
    }

    for (const c of data.flashcards) {
      const newSubjectId = subjectIdMap.get(c.subject_id);
      if (!newSubjectId) continue;
      await db.runAsync(
        `INSERT INTO flashcards
          (subject_id, question, answer, box, next_review_date, source_image_uri)
         VALUES (?, ?, ?, ?, ?, ?)`,
        newSubjectId,
        c.question,
        c.answer,
        c.box ?? 1,
        c.next_review_date ?? new Date().toISOString().slice(0, 10),
        c.source_image_uri ?? null
      );
    }
  });

  return {
    subjectsAdded: data.subjects.length,
    cardsAdded: data.flashcards.length,
  };
}
