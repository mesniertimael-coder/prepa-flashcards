import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { getSetting, setSetting, deleteSetting } from '../db/queries/settings';

const REMINDER_ID_KEY = 'daily_reminder_notification_id';
const REMINDER_HOUR_KEY = 'daily_reminder_hour';
const REMINDER_MINUTE_KEY = 'daily_reminder_minute';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function requestNotificationPermission(): Promise<boolean> {
  const { status: existing } = await Notifications.getPermissionsAsync();
  if (existing === 'granted') return true;

  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

export async function isDailyReminderEnabled(): Promise<{ enabled: boolean; hour: number; minute: number }> {
  const id = await getSetting(REMINDER_ID_KEY);
  const hour = await getSetting(REMINDER_HOUR_KEY);
  const minute = await getSetting(REMINDER_MINUTE_KEY);
  return {
    enabled: !!id,
    hour: hour ? Number(hour) : 18,
    minute: minute ? Number(minute) : 0,
  };
}

export async function scheduleDailyReminder(hour: number, minute: number): Promise<void> {
  const granted = await requestNotificationPermission();
  if (!granted) {
    throw new Error('Permission de notification refusée.');
  }

  // Annule un éventuel rappel déjà programmé avant d'en créer un nouveau
  await cancelDailyReminder();

  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: '📚 C\'est l\'heure de réviser !',
      body: 'Tes flashcards du jour t\'attendent.',
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DAILY,
      hour,
      minute,
    },
  });

  await setSetting(REMINDER_ID_KEY, id);
  await setSetting(REMINDER_HOUR_KEY, String(hour));
  await setSetting(REMINDER_MINUTE_KEY, String(minute));
}

export async function cancelDailyReminder(): Promise<void> {
  const id = await getSetting(REMINDER_ID_KEY);
  if (id) {
    await Notifications.cancelScheduledNotificationAsync(id);
    await deleteSetting(REMINDER_ID_KEY);
  }
}
