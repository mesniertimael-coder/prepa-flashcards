import TextRecognition from '@react-native-ml-kit/text-recognition';

export interface OcrResult {
  text: string;
  blocks: string[];
}

/**
 * Analyse une image locale et retourne le texte détecté.
 * 100% local (Google ML Kit on-device), aucune requête réseau.
 */
export async function recognizeTextFromImage(imageUri: string): Promise<OcrResult> {
  try {
    const result = await TextRecognition.recognize(imageUri);
    const blocks = result.blocks.map((b) => b.text);
    return {
      text: result.text.trim(),
      blocks,
    };
  } catch (error) {
    console.error('OCR error:', error);
    throw new Error("Impossible d'analyser le texte de l'image.");
  }
}
