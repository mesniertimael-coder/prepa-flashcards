import { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { getCardCountByBox } from '../../src/db/queries/cards';
import { BOX_LABELS } from '../../src/constants/leitner';

export default function StatsScreen() {
  const [counts, setCounts] = useState<Record<number, number>>({});

  useEffect(() => {
    getCardCountByBox().then(setCounts);
  }, []);

  return (
    <View style={styles.container}>
      {Object.entries(BOX_LABELS).map(([box, label]) => (
        <View key={box} style={styles.row}>
          <Text style={styles.label}>{label}</Text>
          <Text style={styles.value}>{counts[Number(box)] ?? 0}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#F9FAFB' },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  label: { fontSize: 15, color: '#111827' },
  value: { fontSize: 15, fontWeight: '700', color: '#4F46E5' },
});
