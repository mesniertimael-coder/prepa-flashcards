import { useCallback, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Switch,
  Alert,
  ScrollView,
} from 'react-native';
import { useFocusEffect } from 'expo-router';
import { exportBackup } from '../../src/services/backup';
import {
  isDailyReminderEnabled,
  scheduleDailyReminder,
  cancelDailyReminder,
} from '../../src/services/notifications';

const HOUR_OPTIONS = [7, 8, 12, 17, 18, 19, 20, 21];

export default function SettingsScreen() {
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [reminderHour, setReminderHour] = useState(18);
  const [exporting, setExporting] = useState(false);
  const [togglingReminder, setTogglingReminder] = useState(false);

  const load = useCallback(async () => {
    const { enabled, hour } = await isDailyReminderEnabled();
    setReminderEnabled(enabled);
    setReminderHour(hour);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleToggleReminder = async (value: boolean) => {
    try {
      setTogglingReminder(true);
      if (value) {
        await scheduleDailyReminder(reminderHour, 0);
      } else {
        await cancelDailyReminder();
      }
      setReminderEnabled(value);
    } catch (err: any) {
      Alert.alert('Erreur', err?.message ?? 'Impossible de modifier le rappel.');
    } finally {
      setTogglingReminder(false);
    }
  };

  const handleChangeHour = async (hour: number) => {
    setReminderHour(hour);
    if (reminderEnabled) {
      await scheduleDailyReminder(hour, 0);
    }
  };

  const handleExport = async () => {
    try {
      setExporting(true);
      await exportBackup();
    } catch (err: any) {
      Alert.alert('Erreur', err?.message ?? "L'export a échoué.");
    } finally {
      setExporting(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.sectionTitle}>Rappel quotidien</Text>
      <View style={styles.card}>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>Activer le rappel</Text>
          <Switch
            value={reminderEnabled}
            onValueChange={handleToggleReminder}
            disabled={togglingReminder}
          />
        </View>

        {reminderEnabled && (
          <>
            <Text style={styles.subLabel}>Heure du rappel</Text>
            <View style={styles.hourRow}>
              {HOUR_OPTIONS.map((h) => (
                <TouchableOpacity
                  key={h}
                  style={[styles.hourChip, reminderHour === h && styles.hourChipActive]}
                  onPress={() => handleChangeHour(h)}
                >
                  <Text
                    style={[
                      styles.hourChipText,
                      reminderHour === h && styles.hourChipTextActive,
                    ]}
                  >
                    {h}h
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}
      </View>

      <Text style={styles.sectionTitle}>Sauvegarde</Text>
      <View style={styles.card}>
        <Text style={styles.helperText}>
          Exporte toutes tes matières, cartes et leur progression dans un fichier
          que tu peux enregistrer sur Google Drive, t'envoyer par mail, etc.
          Utile avant de changer de téléphone ou de réinstaller l'app.
        </Text>
        <TouchableOpacity
          style={[styles.exportButton, exporting && { opacity: 0.6 }]}
          onPress={handleExport}
          disabled={exporting}
        >
          <Text style={styles.exportButtonText}>
            {exporting ? 'Export en cours…' : '⬇️ Exporter mes données'}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: '#6B7280',
    textTransform: 'uppercase',
    marginBottom: 8,
    marginTop: 8,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    elevation: 1,
  },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  rowLabel: { fontSize: 15, color: '#111827', fontWeight: '500' },
  subLabel: { fontSize: 13, color: '#6B7280', marginTop: 16, marginBottom: 10 },
  hourRow: { flexDirection: 'row', flexWrap: 'wrap' },
  hourChip: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginRight: 8,
    marginBottom: 8,
  },
  hourChipActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  hourChipText: { fontSize: 13, color: '#374151' },
  hourChipTextActive: { color: '#fff', fontWeight: '600' },
  helperText: { fontSize: 13, color: '#6B7280', lineHeight: 19, marginBottom: 16 },
  exportButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    padding: 14,
    alignItems: 'center',
  },
  exportButtonText: { color: '#fff', fontWeight: '700' },
});
