import { useCallback, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useFocusEffect, useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { getCardById, updateCard, deleteCard } from '../../src/db/queries/cards';
import { BOX_LABELS } from '../../src/constants/leitner';

export default function EditCardScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const cardId = Number(id);
  const router = useRouter();

  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [box, setBox] = useState<number | null>(null);
  const [successCount, setSuccessCount] = useState(0);
  const [failCount, setFailCount] = useState(0);
  const [saving, setSaving] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const load = useCallback(async () => {
    const card = await getCardById(cardId);
    if (card) {
      setQuestion(card.question);
      setAnswer(card.answer);
      setBox(card.box);
      setSuccessCount(card.successCount);
      setFailCount(card.failCount);
    }
    setLoaded(true);
  }, [cardId]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const handleSave = async () => {
    if (!question.trim() || !answer.trim()) {
      Alert.alert('Champs manquants', 'Renseigne la question et la réponse.');
      return;
    }
    try {
      setSaving(true);
      await updateCard(cardId, question, answer);
      router.back();
    } catch (err) {
      console.error(err);
      Alert.alert('Erreur', "La carte n'a pas pu être mise à jour.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = () => {
    Alert.alert(
      'Supprimer cette carte ?',
      'Cette action est définitive.',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: async () => {
            await deleteCard(cardId);
            router.back();
          },
        },
      ]
    );
  };

  if (!loaded) return null;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Stack.Screen options={{ title: 'Modifier la carte', headerShown: true }} />

      {box !== null && <Text style={styles.boxTag}>{BOX_LABELS[box]}</Text>}

      <View style={styles.statsRow}>
        <Text style={styles.statText}>✅ {successCount} réussite{successCount !== 1 ? 's' : ''}</Text>
        <Text style={styles.statText}>❌ {failCount} échec{failCount !== 1 ? 's' : ''}</Text>
      </View>

      <Text style={styles.label}>Question</Text>
      <TextInput
        style={styles.input}
        multiline
        value={question}
        onChangeText={setQuestion}
      />

      <Text style={styles.label}>Réponse</Text>
      <TextInput
        style={styles.input}
        multiline
        value={answer}
        onChangeText={setAnswer}
      />

      <TouchableOpacity
        style={[styles.saveButton, saving && { opacity: 0.6 }]}
        onPress={handleSave}
        disabled={saving}
      >
        <Text style={styles.saveButtonText}>
          {saving ? 'Enregistrement…' : 'Enregistrer les modifications'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.deleteButton} onPress={handleDelete}>
        <Text style={styles.deleteButtonText}>🗑️ Supprimer cette carte</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  boxTag: {
    alignSelf: 'flex-start',
    backgroundColor: '#EEF2FF',
    color: '#4F46E5',
    fontSize: 12,
    fontWeight: '700',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 8,
  },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8, marginTop: 16 },
  statsRow: { flexDirection: 'row', marginBottom: 8 },
  statText: { fontSize: 13, color: '#6B7280', marginRight: 16, fontWeight: '600' },
  input: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 10,
    padding: 12,
    fontSize: 15,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  saveButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginTop: 24,
  },
  saveButtonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  deleteButton: {
    backgroundColor: '#FEE2E2',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 40,
  },
  deleteButtonText: { color: '#B91C1C', fontWeight: '700', fontSize: 15 },
});
